package enums;

public enum Platform {
	Windows,
	OSX, 
	Ubuntu,
	iOS,
	Android 
}
