package stepDefinitions;

import org.openqa.selenium.WebDriver;

import pageObjectsModule.PO_LoginPage;
import pageObjectsModule.PO_MenuDashboard;
import webDriver.Driver;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;

public class LoginPage {

//	TestBaseSetup setUp;
	static WebDriver driver=Driver.getCurrentDriver();
	PO_LoginPage login = new PO_LoginPage();
	PO_MenuDashboard dashboard = new PO_MenuDashboard();
	
	@Given("^I Login to BAU i-banking with valid \"([^\"]*)\"$")
	public void i_Login_to_BAU_i_banking_with_valid(String userProfile)
			throws Throwable {
		login.enterUserCredentials(userProfile);
	}

	@Then("^I navigate \"([^\"]*)\"$")
	public void i_navigate(String subMenu) throws Throwable {
		dashboard = new PO_MenuDashboard();
		dashboard.navigateToOFXSubMenu(subMenu);
	}

	
}
