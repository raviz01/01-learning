package stepDefinitions;

import pageObjectsModule.PO_OFX_AddBene;
import cucumber.api.java.en.Given;

public class AddBene {
	
//	static WebDriver driver = Driver.getCurrentDriver();
	PO_OFX_AddBene addBene = new PO_OFX_AddBene();
	
	@Given("^I add the \"([^\"]*)\" Bene in CSL Manage Payee Page$")
	public void i_add_the_Bene_in_CSL_Manage_Payee_Page(String payeeType) throws Throwable {
		addBene.add_payee(payeeType);
	}

}
