package stepDefinitions;

import java.io.FileNotFoundException;
import java.io.IOException;

import lib.FileRead;
import lib.WebDriverFactory;
import testRunner.TestRunner;
import webDriver.Driver;
import cucumber.api.Scenario;
import cucumber.api.java.After;
import cucumber.api.java.Before;

public class Hooks {

	public static boolean once = false;

	@Before
	public void loadAllFile() throws IOException, FileNotFoundException,
			InterruptedException {
		if (!once) {
			TestRunner.config = FileRead.readProperties();
		}
	}
	
	@Before
	public void beforeScenario(Scenario scenario) {
		TestRunner.scenario = scenario;
		System.out.println("Capture Scenario Description: "+scenario.getName());
	}
	
	@After
	public void afterScenario(Scenario scenario) throws IOException{
		if (scenario.isFailed()) {
			Driver.takeScreenshot("./screenshot/Fail/");
			Driver.embedScreenshot();
			WebDriverFactory.tearDown();
		} else {
			System.out.println("Scenario is Successfully Executed");
			Driver.takeScreenshot("./screenshot/Pass/");
			Driver.embedScreenshot();
			WebDriverFactory.tearDown();
		}
			
	}
}
