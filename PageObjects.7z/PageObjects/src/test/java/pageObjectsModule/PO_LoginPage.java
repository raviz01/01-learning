package pageObjectsModule;

import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import commonModules.UserProfile;
import testRunner.TestRunner;
import webDriver.Driver;

public class PO_LoginPage {

	private static By str_userName = By.id("j_username");
	private static By str_passWord = By.id("j_password");
	private static By btn_singIn = By.id("login-btn");
	private static By online_intro = By.className("intro-slide-wrapper");
	private static By close_into = By.className("sc-close-btn");
	
	static WebDriver driver;
	
	public PO_LoginPage(){
		driver=Driver.getCurrentDriver();
		
	}
	
	public void enterUserCredentials(String userProfile) throws IOException {
		
		if ((TestRunner.config.get("Direct_SSO") != Boolean.TRUE.toString()) && (TestRunner.config.get("HTML_Direct_SSO") != Boolean.TRUE.toString())) {
			System.out.println("Enter User Credentials..");
			System.out.println("User Login Profile:" + UserProfile.getUserName(userProfile)+" || "+UserProfile.getEBID(userProfile));
			driver.findElement(str_userName).sendKeys(UserProfile.getUserName(userProfile));
			driver.findElement(str_passWord).sendKeys(UserProfile.getPassword(userProfile));
			driver.findElement(btn_singIn).click();
			try {
				if (driver.findElement(online_intro).isDisplayed()){
					driver.findElement(close_into).click();
				}
			} catch (Exception e) {
				System.out.println("Online Banking Intro is Not Displayed ..");
			}
		}
	}

}