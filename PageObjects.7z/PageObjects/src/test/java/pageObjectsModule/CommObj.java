package pageObjectsModule;

import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.List;
import java.util.Random;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.gargoylesoftware.htmlunit.ElementNotFoundException;

import cucumber.api.Scenario;
import webDriver.Driver;

public class CommObj {

	static WebDriver driver = Driver.getCurrentDriver();
	static WebDriverWait wait = new WebDriverWait(driver, 30);
	public static Random rand = new Random();
	private static final SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddHHmmss");
	static Timestamp timestamp = new Timestamp(System.currentTimeMillis());

	public static By btn_next = By.xpath("//*[contains(text(),'Next')]");
	public static By btn_confirm = By.xpath("//*[contains(text(),'Confirm')]");
	public static By tbl_referenceInfo = By.xpath("//*[@class='grid container-fluid']");
	public static By tbl_refRowSize = By.xpath("//*[@class='grid container-fluid']/div");
	public static By str_alertDangerMsg = By.xpath("//*/div[@class='alert alert-danger ng-scope']//div[@class='message ng-binding']");

	public static int randNum(int size) {
		return rand.nextInt(size);
	}

	public static String sg_randAccountNumber() {
		String acctNum = sdf.format(timestamp);
		return acctNum;

	}

	public static void captureReferenceInfo() throws ElementNotFoundException,InterruptedException {
		try {
			Thread.sleep(10000);
			List<WebElement> row_count = null;
			wait.until(ExpectedConditions.visibilityOfElementLocated(tbl_referenceInfo)).isDisplayed();
			WebElement refRows = driver.findElement(tbl_referenceInfo);
			row_count = refRows.findElements(By.xpath("div[starts-with(@class,'row')]"));
			
			for (int i = 1; i <= row_count.size(); i++) {
				String row_key = driver.findElement(By.xpath("//*[@class='grid container-fluid']/div["+i+"]/div[1]")).getText();
				String row_value = driver.findElement(By.xpath("//*[@class='grid container-fluid']/div["+i+"]/div[2]")).getText();
				System.out.println(row_key + " : " + row_value);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	// public static void main(String args[]){
	// sg_randAccountNumber();
	// }

}
