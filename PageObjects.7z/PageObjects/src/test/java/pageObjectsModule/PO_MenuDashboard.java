package pageObjectsModule;

import junit.framework.Assert;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import webDriver.Driver;

@SuppressWarnings("deprecation")
public class PO_MenuDashboard {

	private Actions actions;
	private WebDriverWait wait;
	protected WebDriver driver;

	private static By dashBoardMenu = By.id("menu");

	public PO_MenuDashboard() {
		driver = Driver.getCurrentDriver();
	}

	public void navigateToOFXSubMenu(String module) {
		System.out.println("User Navigated to Dashboard Summary UI");
		wait = new WebDriverWait(driver, 40);
		actions = new Actions(driver);
		if (driver.findElement(dashBoardMenu).isEnabled()) {
			WebElement menu = wait.until(ExpectedConditions.elementToBeClickable(dashBoardMenu));
			actions.moveToElement(menu);
			WebElement subMenu = driver.findElement(By.xpath("//*[@class='menu-item']/div[@class='child-item']/*[@title='" + module + "']"));
			actions.moveToElement(subMenu);
			actions.click().build().perform();
		} else {
			Assert.fail("ERROR !! !! Unable to navigate to OFX Transfers "+ module);
		}
	}

}
