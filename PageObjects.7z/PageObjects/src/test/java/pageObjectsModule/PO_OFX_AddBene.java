package pageObjectsModule;

import java.util.Arrays;
import java.util.Iterator;
import java.util.List;

import junit.framework.Assert;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import testRunner.TestRunner;
import webDriver.Driver;

public class PO_OFX_AddBene {

	static WebDriver driver;
	static WebDriverWait wait;

	private static By txt_searchPayee = By.className("form-control search-font ng-valid ng-dirty ng-valid-parse ng-empty ng-touched");
	private static By btn_addLocalPayee = By.id("btn-contacts-local");
	private static By btn_addIntPayee = By.id("btn-contacts-intl");

	private static By tbl_localPayee = By.id("table-contacts-local");
	private static By tbl_IntPayee = By.id("table-contacts-international");

	private static By sel_payeeType = By.xpath("//*[@class='ui-selectmenu-text'][contains(text(),'Select Payee Type')]");
	private static By sel_InterBankPayee = By.xpath("//div[@class='ui-menu-item-wrapper'][contains(text(),'Interbank Payee (IBFT)')]");
	private static By sel_SCBPayee = By.xpath("//div[@class='ui-menu-item-wrapper'][contains(text(),'Third Party SCB Payee')]");

	private static By str_PayeeName = By.name("name");
	private static By str_AccountNumber = By.name("accountNumber");

	private static By sel_bankName = By.xpath("//span[@class='ui-selectmenu-text'][contains(text(),'Select Bank')]");
	private static By str_ShortName = By.name("nickname");

	private static By list_BankName = By.cssSelector(".ui-selectmenu-menu.ui-front.ui-selectmenu-open>ul");
	
	private static int is_valid;

	public String frameworkRegion = TestRunner.config.get("region");
	List<String> payeeType = Arrays.asList("TPFT", "IBFT", "IBCC", "INFT","XBT");
	List<String> sg_tpftAccounts = Arrays.asList("0129896535","0107578336","0102700753","4009862865","0105717894","4009988532");
	List<String> ae_tpftAccounts= Arrays.asList("01200398901","01200400501","01200401601","01200402101","01200402201","01200528901","01200026401","01200074901","01200400501");
	
	public PO_OFX_AddBene() {
		driver = Driver.getCurrentDriver();
		wait = new WebDriverWait(driver, 30);
		
	}

	public void add_payee(String type) throws InterruptedException {

		String add_bene_name = "ADD CSL " + type;
		String edit_bene_name = "EDIT CSL " + type;

		if (frameworkRegion.equalsIgnoreCase("SG")) {
			sg_addLocalPayee(add_bene_name, type);
		} else {

		}

	}

	@SuppressWarnings("deprecation")
	public void sg_addLocalPayee(String payeeName, String type) throws InterruptedException {

		wait.until(ExpectedConditions.elementToBeClickable(btn_addLocalPayee)).click();
		wait.until(ExpectedConditions.visibilityOfElementLocated(sel_payeeType)).click();

		// Select Local IBFT Payee
		if (type=="IBFT") {
			driver.findElement(sel_InterBankPayee).click();
		} else {
		// Select TPFT Payee
			driver.findElement(sel_SCBPayee).click();
		}

		Thread.sleep(5000);

		driver.findElement(str_PayeeName).sendKeys(payeeName);
		driver.findElement(str_ShortName).sendKeys(payeeName);
		
		if (type=="IBFT") {
			// Enter Account Details for IBFT Payee
			driver.findElement(str_AccountNumber).clear();
			driver.findElement(str_AccountNumber).sendKeys(CommObj.sg_randAccountNumber());
			wait.until(ExpectedConditions.elementToBeClickable(sel_bankName)).click();
			WebElement objBankList = driver.findElement(list_BankName);
			List<WebElement> getBankList = objBankList.findElements(By.tagName("li"));
			int getListSize = getBankList.size();
			getBankList.get(CommObj.randNum(getListSize)).click();
			driver.findElement(CommObj.btn_next).click();
		} else {
			// Enter Account Details for TPFT Payee
			for (Iterator<String> iterator = sg_tpftAccounts.iterator(); iterator.hasNext();) {
				String accountNumber = (String) iterator.next();
				driver.findElement(str_AccountNumber).clear();
				driver.findElement(str_AccountNumber).sendKeys(accountNumber);
				driver.findElement(CommObj.btn_next).click();
				try {
					if (driver.findElement(CommObj.str_alertDangerMsg).isEnabled()) {
						String str_getError = driver.findElement(CommObj.str_alertDangerMsg).getText();
						System.out.println("Error !! Captured : "+str_getError+" for account number "+accountNumber+" ..");
						is_valid=0;
					}
				} catch (Exception e) {
					System.out.println("Please proceed further by clicking on Confirm Button");
					is_valid=1;
					break;				
				}
			}	
			if (is_valid==0) Assert.fail("Error !! None of the Account Number Entered is Active");
		}
			
		Thread.sleep(5000);
		driver.findElement(CommObj.btn_confirm).click();	
		CommObj.captureReferenceInfo();

	}
}
