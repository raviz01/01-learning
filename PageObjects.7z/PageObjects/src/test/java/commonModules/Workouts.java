package commonModules;




import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;



public class Workouts {
	
	
	
	
	public static void main(String args[]) throws IOException{

		FileInputStream fis = new FileInputStream(new File("src/main/resources/framework.properties"));
		Properties prop = new Properties();
		prop.load(fis);
		System.out.println(prop.get("Direct_SSO"));
		
		if (prop.get("Direct_SSO") != Boolean.TRUE) {
			System.out.println("Success");
			
		}
			
		}
	}

