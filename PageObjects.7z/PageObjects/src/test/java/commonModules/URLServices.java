package commonModules;

import java.io.IOException;

import testRunner.TestRunner;
import lib.FileRead;

import com.jayway.jsonpath.JsonPath;

public class URLServices {
	
	public static String getURL() throws IOException{
		String appURL=JsonPath.read(FileRead.getServiceURL(), "$."+TestRunner.config.get("region")+"."+TestRunner.config.get("environment")+"_url");
		System.out.println(appURL);
		return appURL;
	}
	
	public static String sg_2FA_OTP_URL() throws IOException{
		String str_2FA_OTP_URL = JsonPath.read(FileRead.getServiceURL(), "$."+TestRunner.config.get("region")+"."+"2FA_OTP_URL");
		System.out.println(str_2FA_OTP_URL);
		return str_2FA_OTP_URL;
	}
	
}
