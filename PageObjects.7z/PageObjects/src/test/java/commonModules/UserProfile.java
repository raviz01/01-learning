package commonModules;

import java.io.IOException;

import lib.FileRead;
import testRunner.TestRunner;

import com.jayway.jsonpath.JsonPath;

public class UserProfile {
	
//	static File userProfile = new File("src/main/resources/users.json");
	
	
	public static String getUID(String userID) throws IOException{
//		String uid=JsonPath.read(userProfile, "$.AE"+"."+userID+"."+"UID");
		String uid=JsonPath.read(FileRead.getUserProfile(), "$."+TestRunner.config.get("region")+"."+userID+"."+"UID");
		return uid;
	}
	
	public static String getCID(String userID) throws IOException{
		String cid=JsonPath.read(FileRead.getUserProfile(), "$."+TestRunner.config.get("region")+"."+userID+"."+"CID");
		return cid;
	}
	
	public static String getEBID(String userID) throws IOException{
		String ebid=JsonPath.read(FileRead.getUserProfile(), "$."+TestRunner.config.get("region")+"."+userID+"."+"EBID");
		return ebid;
	}
	
	public static String getCTRY(String userID) throws IOException{
		String ctry=JsonPath.read(FileRead.getUserProfile(), "$."+TestRunner.config.get("region")+"."+userID+"."+"CTRY");
		return ctry;
	}
	
	public static String getLANG(String userID) throws IOException{
		String lang=JsonPath.read(FileRead.getUserProfile(), "$."+TestRunner.config.get("region")+"."+userID+"."+"LANG");
		return lang;
	}
	
	public static String getAPP(String userID) throws IOException{
		String app=JsonPath.read(FileRead.getUserProfile(), "$."+TestRunner.config.get("region")+"."+userID+"."+"APP");
		return app;
	}
	
	public static String get2FAAuth(String userID) throws IOException{
		String is2FAAuthenticated=JsonPath.read(FileRead.getUserProfile(), "$."+TestRunner.config.get("region")+"."+userID+"."+"is2FAAuthenticated");
		return is2FAAuthenticated;
	}
	
	public static String getSegment(String userID) throws IOException{
		String segment=JsonPath.read(FileRead.getUserProfile(), "$."+TestRunner.config.get("region")+"."+userID+"."+"Segment");
		return segment;
	}
	
	public static String getScreenName(String userID) throws IOException{
		String screenName=JsonPath.read(FileRead.getUserProfile(), "$."+TestRunner.config.get("region")+"."+userID+"."+"screen_appear_name");
		return screenName;
	}
	
	public static String getUserName(String userID) throws IOException{
		String username=JsonPath.read(FileRead.getUserProfile(), "$."+TestRunner.config.get("region")+"."+userID+"."+"user_name");
		return username;
	}
	
	public static String getPassword(String userID) throws IOException{
		String password=JsonPath.read(FileRead.getUserProfile(), "$."+TestRunner.config.get("region")+"."+userID+"."+"password");
		return password;
	}

	
	}

