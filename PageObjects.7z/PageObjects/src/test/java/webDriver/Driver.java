package webDriver;

import java.io.File;
import java.io.IOException;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.concurrent.TimeUnit;

import lib.WebDriverFactory;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebDriverException;

import testRunner.TestRunner;

public class Driver {
	
	public static WebDriver webdriver;
	private static SimpleDateFormat sdf = new SimpleDateFormat("yyyy_MM_dd-HH_mm_ss");
	private static Timestamp timestamp = new Timestamp(System.currentTimeMillis());
	
	public synchronized static WebDriver getCurrentDriver() throws WebDriverException {
		if (webdriver == null) {
			try {
				webdriver = WebDriverFactory.initializeTestBaseSetup();
			} catch (IOException e) {
				e.printStackTrace();
			}
			webdriver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		}
		return webdriver;
	}
	
	public static String takeScreenshot(String path) throws IOException {
		String filename = "sel_screenshot-"+sdf.format(timestamp);
		try {
			File file = ((TakesScreenshot) getCurrentDriver()).getScreenshotAs(OutputType.FILE);
			String filePath = (path + filename + ".png");
			FileUtils.copyFile(file, new File(filePath));
			return filePath;
		} catch (WebDriverException somePlatformsDontSupportScreenshots) {
			System.err.println(somePlatformsDontSupportScreenshots.getMessage());
			return null;
		}
	}

	public static void embedScreenshot() {
		try {
			byte[] screenshot = ((TakesScreenshot) getCurrentDriver()).getScreenshotAs(OutputType.BYTES);
			TestRunner.scenario.embed(screenshot, "image/png");
		} catch (WebDriverException somePlatformsDontSupportScreenshots) {
			System.err.println(somePlatformsDontSupportScreenshots.getMessage());
		}
	}

}
