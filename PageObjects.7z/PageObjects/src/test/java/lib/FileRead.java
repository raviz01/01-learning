package lib;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Properties;

public class FileRead {
	
	public static FileInputStream readFile(String file) throws FileNotFoundException, IOException{
		return new FileInputStream(file);	
	}
	
	
	public static HashMap<String, String> readProperties() throws FileNotFoundException, IOException {
		
		Properties prop = new Properties();
		prop.load(readFile("src/main/resources/framework.properties"));
		
		HashMap<String, String> properties = new HashMap<String, String>();
		
		Enumeration<Object> KeyValues = prop.keys();

		while (KeyValues.hasMoreElements()) {
			String key = (String) KeyValues.nextElement();
			String value = prop.getProperty(key);
			properties.put(key, System.getProperty(key, value));
		}
		
		return properties;
	}
	
	public static File getUserProfile() throws FileNotFoundException,IOException {
		File userProfile = new File("src/main/resources/users.json");
		return userProfile;
	}
	
	public static File getServiceURL() throws FileNotFoundException,IOException {
		File serviceURL = new File("src/main/resources/serviceURL.json");
		return serviceURL;
	}

}
