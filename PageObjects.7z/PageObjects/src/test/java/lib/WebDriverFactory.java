package lib;

import java.io.IOException;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebDriverException;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;

import commonModules.URLServices;

import testRunner.TestRunner;

public class WebDriverFactory {
	
	public static WebDriver webdriver;
	
	public static WebDriver initChromeDriver(String appURL) {
		System.out.println("Launching google chrome with new profile..");
		System.setProperty("webdriver.chrome.driver", TestRunner.config.get("driverPath")
				+ "chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.navigate().to(appURL);
		return driver;
	}

	public static WebDriver initIEDriver(String appURL) {
		System.out.println("Launching IE browser..");
		System.setProperty("webdriver.ie.driver", TestRunner.config.get("driverPath")
				+ "IEDriverServer.exe");
		WebDriver driver = new InternetExplorerDriver();
		driver.manage().window().maximize();
		driver.navigate().to(appURL);
		return driver;
	}
	
	public static WebDriver setDriver(String browserType, String appURL) throws IOException {
		switch (browserType) {
		case "chrome":
			webdriver = initChromeDriver(appURL);
			break;
		case "ie":
			webdriver = initIEDriver(appURL);
			break;
		default:
			System.out.println("browser : " + browserType
					+ " is invalid, Launching Firefox as browser of choice..");
			webdriver = initIEDriver(appURL);
		}
		return webdriver;
	}
	
	public static WebDriver initializeTestBaseSetup() throws WebDriverException, IOException {
		String browserType=TestRunner.config.get("browser");
		String appURL=URLServices.getURL();
		try {
			setDriver(browserType, appURL);

		} catch (Exception e) {
			System.out.println("Error....." + e.getStackTrace());
		}
		return webdriver;
	}
	
	public static void tearDown(){
		webdriver.quit();
	}

}
