# module ReportBuilder
#     require 'report_builder'
    

# 	    # Ex 1:
# 	    jsonFileName=File.exist?(Dir.pwd+"/logs/report.json")
		
# 	    ReportBuilder.configure do |config|
# 		    if jsonFileName
# 				if File.exist?(Dir.pwd+"/logs/csl_reports/csl-soft-token.html")
# 					config.report_path = Dir.pwd+'/logs/csl_reports/csl-soft-token.html'
# 					config.report_types = [:html]
# 					config.report_title = 'My Test Results'
# 					config.include_images = false
# 					config.additional_info = {browser: 'Chrome', environment: 'Stage 5'}
# 					ReportBuilder.build_report
# 				else
# 					puts "No Such csl-soft-token.html file"
# 				end
				
# 			else
# 				puts "No Such Report.json file"
# 		    end

# 	    end
# end


#     ReportBuilder.build_report if dirname

# ReportBuilder.configure do |config|
#   config.json_path = config.json_path = {
#       'Group A' => ['../testing/fixtures/json_reports/report.json', '../testing/fixtures/json_reports/report1.json'],
#       'Group B' => ['../testing/fixtures/json_reports/report2.json', '../testing/fixtures/json_reports/report3.json'],
#       'Group C' => ['../testing/fixtures/json_reports/report4.json']}
#   config.report_path = '../sample/group_report'
#   config.report_title = 'My Test Results'
#   config.additional_info = {Browser: 'browser', Environment: 'environment', MoreInfo: 'more info'}
# end

# ReportBuilder.build_report


##################### ORIGINAL ########################

# ReportBuilder.configure do |config|
#   config.json_path = '../testing/fixtures/json_reports'
#   config.report_path = '../sample/report'
#   config.report_title = 'My Test Results'
#   config.additional_info = {Browser: 'browser', Environment: 'environment', MoreInfo: 'more info'}
# end

# ReportBuilder.build_report

# ReportBuilder.configure do |config|
#   config.json_path = config.json_path = {
#       'Group A' => ['../testing/fixtures/json_reports/report.json', '../testing/fixtures/json_reports/report1.json'],
#       'Group B' => ['../testing/fixtures/json_reports/report2.json', '../testing/fixtures/json_reports/report3.json'],
#       'Group C' => ['../testing/fixtures/json_reports/report4.json']}
#   config.report_path = '../sample/group_report'
#   config.report_title = 'My Test Results'
#   config.additional_info = {Browser: 'browser', Environment: 'environment', MoreInfo: 'more info'}
# end

# ReportBuilder.build_report