class GetFXRates
		include Handler
	 	require 'net/http'
	 	require 'uri'
	 	require 'json'

	 # 	@axway_csl_limit_service_url=## Get URL from File ##
	 # 	@axway_csl_limit_path= "/retail/csl/v1/limits/txnty/"
	 #  @uri=URI.parse("http://10.20.234.34:9000/retail/csl/v1/limits/txnty/INFT")
			
	def initalize
	end

	def getCSLHeader(scenario,filePath,user)
		puts "Setting up the generic header"
		# @current_user = YAML.load(fileName+"/csl_get_limits_header.yml")
		@current_user = YAML.load_file(filePath+"/csl_post_fxrates_header.yml")

		@client_context={
			'user'=>{  
		           'uaas2id'=>@current_user[$COUNTRY][user][scenario]["uaas2id"],
		           'relId'=>@current_user[$COUNTRY][user][scenario]["relId"],
		           'country'=>@current_user[$COUNTRY][user][scenario]["country"],
		           'language'=>@current_user[$COUNTRY][user][scenario]["language"],
		           'segCd'=>@current_user[$COUNTRY][user][scenario]["segCd"]
		        },
		        'client'=>{  
		           'clientRequestId'=>"cucumber-req-"+rand.to_s[2..11],
		           'trueClientIP'=>'59.189.232.132',
		           'sessionId'=>'JOlAYX3o6D3pVz12kyiv9Y1',
		           'userAgent'=>'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/47.0.2526.106 Safari/537.36',
		           'channel'=>'IBNK',
		           'deviceTy'=>'IPAD'
		        }
		}
		return @client_context
		
	end

	def fxRatesBody(txnTy,fromCurr,toCurr,txnCurr,txnAmt,fromAcc)
  		@fx_rates_request_body={
	  			'fxrate'=> {
			    'txnTy'=> "#{txnTy}",
			    'fromCurr'=> "#{fromCurr}",
			    'toCurr'=> "#{toCurr}",
			    'txnCurr'=> "#{txnCurr}",
			    'txnAmt'=> "#{txnAmt}",
			    'fromAcc'=> "#{fromAcc}"
					}
			}
	end

 	def postFxRates
 		#@uri=URI.parse("http://10.20.234.34:8188/retail/csl/v1/rates")
 		puts "#{$BASE_URL[:getFXRates]}"
 		@uri=URI.parse($BASE_URL[:getFXRates])
		@header={'Content-Type'=>'application/json', 'Accept'=>'application/json', 'CSL_HEADER'=> @client_context.to_json}

		# Create the HTTP objects
		@http = Net::HTTP.new(@uri.host, @uri.port)
		@request= Net::HTTP::Post.new(@uri.request_uri, @header)
		
		# Set the FX Rates Body Request Parameters
		@request.body = @fx_rates_request_body.to_json

		# puts "Get FX Rates CSL Header Request:\n #{@header}"
		
		# Send the request
		@response = @http.request(@request)
		@http_body_json = JSON.parse @response.body

		if (@http_body_json["statusCd"]=="0000")
			$log.info("GetFXRates-CSL","Get FX Rates Response:\n #{@http_body_json}")
			puts "Get FX Rates Response:\n #{@http_body_json}"
		elsif (@http_body_json["statusCd"]=="0001")
			$log.capture("FX Rate Request Body: \n #{@fx_rates_request_body.to_json}")
			fail "FAILED !!!!! #{@http_body_json["errorDesc"]}"
		end
			
	end

	def errorCodeValidation(err_Cd,err_Desc)
		if (@http_body_json["statusCd"]=="0001")
			case @http_body_json["errorCd"]
			when "2402"
				puts  "Error Code Verified Successfully :::: #{expect(@http_body_json["errorCd"]).to eq(err_Cd)}\n"
				puts  "Error Desc Verified Successfully :::: #{@http_body_json["errorDesc"] == err_Desc}\n"
			else
				fail "FAIL !!! No Such Error Code #{err_Cd} with Error Desc #{err_Desc} available "
			end
		end
	end

end

# expect(customerAccountDetailsHeader.http_response.code).to eq(200)