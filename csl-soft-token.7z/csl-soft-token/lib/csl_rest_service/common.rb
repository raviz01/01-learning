module Handler
	require 'csv'

	def genericHeader(user)
		puts "Setting up the generic header"

		@client_context={
			'user'=>{  
		           'uaas2id'=>"#{$user[$framework["region"]][user]["EBID"]}",
		           'relId'=>"#{$user[$framework["region"]][user]["UID"]}",
		           'country'=>"#{$user[$framework["region"]][user]["CTRY"]}",
		           'language'=>"#{$user[$framework["region"]][user]["LANG"]}",
		           'segCd'=>"#{$user[$framework["region"]][user]["Segment"]}",
		           # 'custId'=>'S0002094Z',    # making it dynamic, if you call setter than you will find
		           # 'custIdType'=>'01'       # making it dynamic, if you call setter than you will find
		        },
		        'client'=>{  
		           'clientRequestId'=>"cucumber-req-"+rand.to_s[2..11],
		           'trueClientIP'=>'59.189.232.132',
		           'sessionId'=>'JOlAYX3o6D3pVz12kyiv9Y1',
		           'userAgent'=>'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/47.0.2526.106 Safari/537.36',
		           'channel'=>'IBNK',
		           'deviceTy'=>'IPAD'
		        }
		}
		return @client_context.to_json
	end

	def read_json(path, filename)
		 file = File.read(path+filename+'.json') 
	end

	def read_csv_file(path, filename)
		file = CSV.read(path+filename+'.csv') 
	end

	def get_hash(hashResponse)
  			hashResponse.each_with_object([]) do |(k,v),keys|      
    		keys << k
    		keys.concat(get_hash(v)) if v.is_a? Hash
  			end
  	end
  	
  	def get_hash_value(hashResponse)
  		hashResponse.each_with_object([]) do |(k,v),values|
  		values << v
  		end	
  	end

end