module GeneralAGWServiceDomain

	def csltransferLimits
		@csltransferLimits ||= TransferLimitsCSLService.new
	end

	def cslFxRates
		@cslFxRates ||= GetFXRates.new
	end

	def log
		@log ||= Log.new
	end
	
end