class TransferLimitsCSLService
		include Handler
	 	require 'net/http'
	 	require 'uri'
	 	require 'json'

	 # 	@axway_csl_limit_service_url=## Get URL from File ##
	 # 	@axway_csl_limit_path= "/retail/csl/v1/limits/txnty/"
	 #  @uri=URI.parse("http://10.20.234.34:9000/retail/csl/v1/limits/txnty/INFT")
			
	def initalize
	end

	def getCSLHeader(scenario,filePath,user)
		puts "Setting up the generic header"
		# @current_user = YAML.load(fileName+"/csl_get_limits_header.yml")
		@current_user = YAML.load_file(filePath+"/csl_get_limits_header.yml")

		@client_context={
			'user'=>{  
		           # 'uaas2id'=>@current_user[$framework["region"]][user][scenario]["uaas2id"],
		           # 'relId'=>@current_user[$framework["region"]][user][scenario]["relId"],
		           # 'country'=>@current_user[$framework["region"]][user][scenario]["country"],
		           # 'language'=>@current_user[$framework["region"]][user][scenario]["language"],
		           # 'segCd'=>@current_user[$framework["region"]][user][scenario]["segCd"]
		           'uaas2id'=>@current_user[$COUNTRY][user][scenario]["uaas2id"],
		           'relId'=>@current_user[$COUNTRY][user][scenario]["relId"],
		           'country'=>@current_user[$COUNTRY][user][scenario]["country"],
		           'language'=>@current_user[$COUNTRY][user][scenario]["language"],
		           'segCd'=>@current_user[$COUNTRY][user][scenario]["segCd"]
		        },
		        'client'=>{  
		           'clientRequestId'=>"cucumber-req-"+rand.to_s[2..11],
		           'trueClientIP'=>'59.189.232.132',
		           'sessionId'=>'JOlAYX3o6D3pVz12kyiv9Y1',
		           'userAgent'=>'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/47.0.2526.106 Safari/537.36',
		           'channel'=>'IBNK',
		           'deviceTy'=>'IPAD'
		        }
		}
		return @client_context
		
	end

 	def getTransferLimit(txnType)
 		@uri=URI.parse($BASE_URL[:getTransactionLimit]+"/#{txnType}")
		@header={'Content-Type'=>'application/json', 'Accept'=>'application/json', 'CSL_HEADER'=> @client_context.to_json}

		# Create the HTTP objects
		@http = Net::HTTP.new(@uri.host, @uri.port)
		@request_header = Net::HTTP::Get.new(@uri.request_uri, @header)
		#request.body = user.to_json

		$log.info("GetFXRates-CSL","Get Transfer Limit CSL Header Request:\n #{@request_header}")
		
		# Send the request
		@response = @http.request(@request_header)
		@http_body_json = JSON.parse @response.body

		if (@http_body_json["statusCd"]=="0000")
			$log.info("GetFXRates-CSL","Get Transfer Limit Response:\n #{@http_body_json}")
			$log.capture("Get FX Rates Response:\n #{@http_body_json}")
		elsif (@http_body_json["statusCd"]=="0001")
			fail "FAILED !!!!! #{@http_body_json["errorDesc"]}"
		end
	end

	def getLimitLength
		if (@http_body_json["statusCd"]=="0000")
			getLimitLength=@http_body_json["limit"]["limitList"].length
			for i in 0...getLimitLength
				if @http_body_json["limit"]["limitList"][i]["lmtCatTy"]=="2FL"
					puts "#{@http_body_json["limit"]["limitList"][i]["amt"]}"
					break
				end
			end
		elsif (@http_body_json["statusCd"]=="0001")
			fail "======= FAILED !! Get Transfer Limit response returned as #{@http_body_json["errorDesc"]}======="
		end
	end

	def errorCodeValidation(err_Cd,err_Desc)
		if (@http_body_json["statusCd"]=="0001")
			case @http_body_json["errorCd"]
			when "2402"
				$log.capture("Error Code Verified Successfully :::: #{expect(@http_body_json["errorCd"]).to eq(err_Cd)}\n")
				$log.capture("Error Desc Verified Successfully :::: #{@http_body_json["errorDesc"] == err_Desc}\n")
			else
				fail "FAIL !!! No Such Error Code #{err_Cd} with Error Desc #{err_Desc} available "
			end
		end
	end

end

# expect(customerAccountDetailsHeader.http_response.code).to eq(200)