class Log
include Singleton


  def initialize()
      if @logger.nil?
        #puts "\n#{Dir::pwd}"
        #puts "\n#{File.dirname(__FILE__)}"
        @logger ||= Logger.new("#{Dir::pwd}/logs/csl-cuke.log", 'daily')
        @logger.level = Logger::DEBUG
        
        @logger.formatter = proc { 
                      |severity, datetime, progname, msg|
                      "[#{datetime.strftime('%Y-%m-%d %H:%M:%S.%L')}][#{severity}][##{Process.pid}][#{sprintf "%-35.35s", progname}] #{msg}\n"
                   }
      end
  end


  def debug(*progName_message)
  	case progName_message.size
    when 0
    	@logger.debug( "...unknown_program_name..." ) { "please stop calling a blank debug()" }
    when 1
    	@logger.debug( "...unknown_program_name..." ) { progName_message[0] }
    when 2
  		@logger.debug( progName_message[0] ) { progName_message[1] }
  	else 
  		@logger.debug( progName_message[0] ) { progName_message[1] }
    end
  end


  def info(*progName_message)
  	  case progName_message.size
    	when 0
      	@logger.info( "...unknown_program_name..." ) { "please stop calling a blank info()" }
      when 1
      	@logger.info( "...unknown_program_name..." ) { progName_message[0] }
      when 2
    		@logger.info( progName_message[0] ) { progName_message[1] }
    	else
    		@logger.info( progName_message[0] ) { progName_message[1] }
      end
  end

  def capture(message)
    @cucumber_world.puts("#{message}")
  end

end