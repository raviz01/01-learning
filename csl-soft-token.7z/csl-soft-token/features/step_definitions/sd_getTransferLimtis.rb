World(GeneralAGWServiceDomain)

Given(/^I set up the CSL Header Request for Customer Transaction Limit to execute "([^"]*)" as per sheet "([^"]*)" for "([^"]*)"$/) do |scenario, path, user|
	csltransferLimits.getCSLHeader(scenario, path, user)
end

Then(/^I execute customer transaction limit for "([^"]*)" transaction type$/) do |txnType|
  csltransferLimits.getTransferLimit(txnType)
end

And(/^I verify the limit length$/) do
	csltransferLimits.getLimitLength
end

And(/^I verify the "([^"]*)" and "([^"]*)"$/) do |errorCode,errorDesc|
	csltransferLimits.errorCodeValidation(errorCode,errorDesc)
end
