World(GeneralAGWServiceDomain)

Given(/^I set up the CSL Header Request for getting the FX Rates to execute "([^"]*)" as per sheet "([^"]*)" for "([^"]*)"$/) do |scenario, filePath, user|
  	cslFxRates.getCSLHeader(scenario,filePath,user)
end

And(/^I fetch FX Rates request body for "([^"]*)" transaction and retrieve rates between "([^"]*)" "([^"]*)" "([^"]*)" "([^"]*)" "([^"]*)"$/) do |txnType, fromCurr, toCurr, txnCurr, txnAmt, acctNum|
	cslFxRates.fxRatesBody(txnType,fromCurr,toCurr,txnCurr,txnAmt,acctNum)
end

Given(/^I execute Post FX Rates Service$/) do
  	cslFxRates.postFxRates
end