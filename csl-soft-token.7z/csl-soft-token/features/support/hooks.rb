require 'report_builder'

# encoding: utf-8
AfterConfiguration do |config|
  #puts "Features dwell in #{config.feature_dirs}"
end

Before do |scenario|
  $log = Log.instance
  $log.instance_variable_set(:@cucumber_world, self)
  @tag_name = ""
    for i in 0...scenario.source_tag_names.length
    tag = scenario.source_tag_names[i]
    if tag != "@wip"
      @tag_name += tag + "  "
    end
  end
  if @tag_name == "" 
    @tag_name = "@NO_TAG_SPECIFIED"
  end
  $log.debug("########## START ##########", "R  D  C  ::: #{@tag_name}")
  $log.info("","Scenario Description: #{scenario.name}\n\n")
  # Do something before each scenario.
  # The +scenario+ argument is optional, but if you use it, you can get the title,
  # description, or name (title + description) of the scenario that is about to be
  # executed
  #
  # e.g
  # put "Starting scenario: #{scenario.title}"
end

After do |scenario|
  # Do something after each scenario.
  # The +scenario+ argument is optional, but
  # if you use it, you can inspect status with
  # the #failed?, #passed? and #exception methods. 
  #
  # e.g
  # if scenario.failed?
  #   do something...
  # end
    if scenario.passed?
      $log.debug("########## END ##########", "#{@tag_name} ::: ** ** ** **   P A S S E D   ** ** ** **")
  
    elsif scenario.failed?
      $log.debug("! ! ! ! ! !! Exception !! ! ! ! ! !", "\n\t#{scenario.exception.message}\n\t#{scenario.exception.backtrace.join("\n\t")}\n\t")
      #$log.debug("Exception BackTrace ::: ", "#{scenario.exception.backtracejoin("\n\t")}")
      $log.debug("########## END ##########", "#{@tag_name} ::: !!  !!  !!!   F A I L E D   !!!  !!  !!")
    end
  
    $log.debug("===================================", "====================================================================================================")
end

AfterStep do |scenario|
  # Do something after each step.
end

at_exit do
        ReportBuilder.configure do |config|
          config.json_path = Dir.pwd+'/logs/test_reports/csl-cuke.json'
          config.report_path = Dir.pwd+'/logs/test_reports/csl-cuke'
          config.report_title = '-- Service Testing CSL Cuke --'
          config.additional_info = {Country: $COUNTRY, Environment: ENV['TEST_ENV'], MoreInfo: '----Set More Info----', UserName: ENV["username"], Date: Time.now.strftime("%d %b %Y - %H:%M:%S")}
        end
        ReportBuilder.build_report
end