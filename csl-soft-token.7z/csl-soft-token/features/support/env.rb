# encoding: utf-8
require 'cucumber'
require 'httparty'
require 'json'
require 'json-schema'
require 'rack/test'
require 'require_all'
require 'logger'
require 'stomp'
require_all 'lib'
require 'pry'
require 'mechanize'
require 'yaml'

$LOAD_PATH << './support'

#$out_file = File.new("failed_fx_rates_#{Time.new.strftime("%Y%m%d%H%M%S")}.txt", "w")
# $out_file = File.new("failed_fx_rates_cases.txt", "w")

$user = YAML.load_file('config/user.yml')
#$framework = YAML.load_file('config/framework.yml')

#$test_data = YAML.load_file('config/data/test_data.yml')

$BASE_URL = YAML.load_file(Dir.pwd+"/config/config.yml")[ENV['TEST_ENV']]
$COUNTRY = YAML.load_file(Dir.pwd+"/config/country.yml")[ENV['REGION']]

$PROCESS = ENV['TEST_ENV_NUMBER']