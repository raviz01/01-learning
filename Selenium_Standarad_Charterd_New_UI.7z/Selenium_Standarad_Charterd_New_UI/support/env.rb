
def on(class_name)
	yield class_name.new
end


def error_mess(mes)
puts "#" * 50 
fail "#{mes}" 
puts "#"* 50
end



$LOAD_PATH << './support'

Dir.mkdir Dir.pwd + '/log' unless Dir.exists?(Dir.pwd + '/log')
Dir.mkdir Dir.pwd + '/log/screenshots' unless Dir.exists?(Dir.pwd + '/log/screenshots')
Dir.mkdir Dir.pwd + '/log/screenshots/pass' unless Dir.exists?(Dir.pwd + '/log/screenshots/pass')
Dir.mkdir Dir.pwd + '/log/screenshots/fail' unless Dir.exists?(Dir.pwd + '/log/screenshots/fail')

require 'selenium-webdriver'
require "capybara"
require 'require_all'
require 'yaml'
require 'awesome_print'
# require 'lib/Framework_Support_Lib/common.rb'
# require 'Handler'


require_all './lib'

$user = YAML.load_file('config/user.yml')
$framework = YAML.load_file('config/framework.yml')
$test_data = YAML.load_file('config/data/test_data.yml')
Capybara.default_wait_time = 60


def show(msg)
  pop_up_message msg
  # puts msg
end

def stop(msg)
   pop_up_message msg 
   fail msg
end



def pop_up_message(msg)
    script = %Q{
    var popup = document.createElement('div');
    popup.style.backgroundColor  = 'yellow';
    popup.style.color = 'black';
    popup.style.position = 'fixed';
    popup.style.left = 0;
    popup.style.top = 0;
    popup.style.fontSize = '20px';
    popup.style.border = '2px solid orange';
    popup.innerText = '#{msg}';
    document.body.appendChild(popup);
    setTimeout(function(){ document.body.removeChild(popup); }, 3000);
    }
    $browser.execute_script(script)
    sleep 3
  end