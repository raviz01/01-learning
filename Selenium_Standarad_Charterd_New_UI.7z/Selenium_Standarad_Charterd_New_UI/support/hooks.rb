
  require 'capybara'
  require 'selenium-webdriver'
  require 'zip'
  require 'require_all' 
  require_all './lib'
  # require 'Handler'
    include Handler

def take_screenshots(scenario = nil)
puts "scenario #{scenario.status}"
  scenario_name = scenario ? scenario.name : "#{@scenario_name}_step_#{@step}"
  if scenario.nil? || scenario.passed?
    sshot_name = "log/screenshots/pass/" + scenario_name.gsub(/[^A-Za-z0-9]/, '')+".png"
  elsif scenario.failed?
    sshot_name = "log/screenshots/fail/" + scenario_name.gsub(/[^A-Za-z0-9]/, '')+".png"
  end
  $browser.save_screenshot(sshot_name)  
  embed(sshot_name, 'image/png')
end


Before do |scenario|  
            ENV['HTTP_PROXY'] = ENV['http_proxy'] = nil   
            Capybara.register_driver :selenium do |app|
               Capybara::Selenium::Driver.new(app, :browser => $framework['browser'].to_sym, :switches => %w[--ignore-certificate-errors --disable-popup-blocking --disable-translate --disable-extensions])
            end
            $browser=Capybara::Session.new(:selenium)
            $browser.driver.browser.manage.window.maximize          
            unless $framework['Direct_SSO'] == true 
              puts ENV[$framework["region"]+"_URL"] 
              show $framework["region"]
              $browser.visit $test_data["#{$framework['region']}_URL"]
              $browser.driver.browser.switch_to.alert.accept  rescue Selenium::WebDriver::Error::NoAlertOpenError
            end                                            
end


After do |scenario|  
   take_screenshots(scenario)   
   $browser.driver.browser.manage.delete_all_cookies if $framework['Delete_cookies'] == true
   $browser.driver.browser.close
end



# at_exit do
#   ENV['ARCHIVE_RESULTS'] = 'no' if ENV['ARCHIVE_RESULTS'].nil?
#   if ENV['ARCHIVE_RESULTS']=="yes"
#     Dir.mkdir("resultsarchive") if Dir["resultsarchive"].empty?
#     folder = Dir.pwd
#     input_filenames = ['cucumber.html']
#     zipfile_name = "#{Date.today}_results.zip"
#     Zip::File.open(zipfile_name, Zip::File::CREATE) do |zipfile|
#       input_filenames.each do |filename|
#         zipfile.add(filename, folder + '/' + filename)
#       end
#     end
#     FileUtils.mv(zipfile_name,"resultsarchive/#{zipfile_name}")
#   end
# end




