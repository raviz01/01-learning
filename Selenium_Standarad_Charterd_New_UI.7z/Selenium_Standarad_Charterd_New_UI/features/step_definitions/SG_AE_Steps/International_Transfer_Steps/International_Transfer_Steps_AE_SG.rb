Then(/^I submit "([^"]*)" "([^"]*)" Transfer$/) do |currency_type, transfer_type|
	on(InftLib) do |page|
     page.inft_xbt_transfer(currency_type, transfer_type)
	end
end

# Then(/^I submit "([^"]*)" "([^"]*)" Transfer with Charges To Be Paid By "([^"]*)"$/) do |currency_type, transfer_type, paid_by|
#   	on(InftLib) do |page|
#      page.inft_xbt_transfer_our_ben_sha(currency_type, transfer_type, paid_by)
# 	end
# end