Given(/^I add the "([^"]*)" to GL account$/) do |gl_number|
  on(Gl_Transfer) do |page|   
    gl_beny_number = $user[$framework["region"]][$current_user_instance]["#{gl_number}"]       
    page.add_GL_account_number(gl_beny_number, $browser)
  end 
end


Then(/^I validate "([^"]*)" global account number in GL page$/) do |global_account|
  on(SsoRequet) do |page|
  page.wait_for_ajax        
                $browser.find(:id, page.find_xpath("menu")).hover #if $browser.find_link(page.find_xpath(dasboard)).visible?
                $browser.find_link('Global Accounts').click if $browser.find_link('Global Accounts').visible? == true            
   end 
  on(Gl_Transfer) do |page| 
          page.wait_for_ajax        
           sleep 8
          global_test_data = $browser.find(:xpath, page.find_xpath("List_of_GL_data")).text if $framework["region"] == "AE"
          global_test_data = $browser.find(:xpath, page.find_xpath("SG_GL_Data")).text if $framework["region"] == "SG"      
          global_data = global_test_data.split(" ")                     
          for global_value in 0...global_data.length                            
                  global_value_data = global_value if global_data[global_value].include? 'HONG'                                               
          end  
          if global_account == 'Linked'                       
              fail "!!!Error!!! There is no HONG KONG test data" if global_value_data.nil?             
              to_account_data_list = global_test_data[global_value_data..global_test_data.length].split(" ")                
              @gl_account_numbers = [];
              for index in 0...to_account_data_list.length                                                                 
                        if  to_account_data_list[index].include? "HKD"                      
                            @gl_account_numbers << to_account_data_list[index-1]  if to_account_data_list[index] == 'HKD'                                                                                         
                        end  
                         page.wait_for_ajax                           
              end  
             puts "gl_account_numbers:: #{@gl_account_numbers}"
          else
             fail "!!!Error!!! HONG KONG test data is present"  if !global_value_data.nil? 
             puts "!!!Perfect!!! HONG KONG test data has successfully got deleted" if global_value_data.nil? 
          end
          puts "#" * 50
  end 
end

Given(/^I delete the "([^"]*)" to GL account$/) do |arg1|
 on(Gl_Transfer) do |page|         
    page.delete_GL_account_number($browser)
  end 
end

Then(/^I should not see deleted GL account details in OAFT page$/) do
  on(SsoRequet) do |page|
  page.wait_for_ajax               
                $browser.find(:id, page.find_xpath("menu")).hover #if $browser.find_link(page.find_xpath(dasboard)).visible?
                # $browser.find_link(transfer_type).click if $browser.find_link(transfer_type).visible? == true                                                                      
   end 
   
  on(Oaft) do |page|         
        page.wait_for_ajax    
        puts "To Account Drown down is displaying" if $browser.has_xpath?(page.find_xpath("oaft_to_account")) 
        sleep 12   
        # $browser.find(:xpath, page.find_xpath("oaft_page")).native.send_keys :tab 
        # page.wait_for_ajax  
        $browser.find(:xpath, page.find_xpath("oaft_to_account")).click
        page.wait_for_ajax  
         to_account_data = $browser.find(:xpath, page.find_xpath("to_account_list")).text                   
          for global_value in 0...to_account_data.length            
                if to_account_data[global_value]== 'H'
                  global_value_data = global_value if to_account_data[global_value+1] == 'o'
                  break if to_account_data[global_value+2]== 'n'                                
                end
          end                   
       fail "!!!Error!!! HONG KONG test data is present"  if !global_value_data.nil?             
  end
end

Then(/^I should see linked GL account details in OAFT page$/) do
  on(SsoRequet) do |page|
  page.wait_for_ajax               
                $browser.find(:id, page.find_xpath("menu")).hover #if $browser.find_link(page.find_xpath(dasboard)).visible?
                # $browser.find_link(transfer_type).click if $browser.find_link(transfer_type).visible? == true                                                                      
   end 
   
  on(Oaft) do |page|         
        page.wait_for_ajax    
        puts "To Account Drown down is displaying" if $browser.has_xpath?(page.find_xpath("oaft_to_account")) 
        sleep 12   
        # $browser.find(:xpath, page.find_xpath("oaft_page")).native.send_keys :tab 
        page.wait_for_ajax  
        $browser.find(:xpath, page.find_xpath("oaft_to_account")).click
        page.wait_for_ajax  
         to_account_data = $browser.find(:xpath, page.find_xpath("to_account_list")).text                   
          for global_value in 0...to_account_data.length            
                if to_account_data[global_value]== 'H'
                  global_value_data = global_value if to_account_data[global_value+1] == 'o'
                  break if to_account_data[global_value+2]== 'n'                                
                end
          end                   
       fail "!!!Error!!! There is no HONG KONG test data" if global_value_data.nil?             
       to_account_data_list = to_account_data[global_value_data..to_account_data.length].split(" ")  
       # puts "to_account_data_list:: #{to_account_data_list}"  
       account_numbers =[] ;                                   
        for index in 0...to_account_data_list.length                                                                 
                  if  to_account_data_list[index].include? "HKD"                      
                      account_numbers << to_account_data_list[index-2]  if to_account_data_list[index] == 'HKD'                       
                      # break if to_account_data_list[index] == 'HKD'                                                 
                  end  
                   page.wait_for_ajax                           
        end  
        puts "account_numbers:: #{account_numbers}"      
       ###### OAFT and GLFT data page validation ######            
               fail "!!!Defect!!! Linked GLFT accounts numbers are not displaying as per global account page data" if @gl_account_numbers[0].include? "#{account_numbers}"
            
    end
   
    
end