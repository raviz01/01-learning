Given(/^I get the limit details for "([^"]*)" navigate "([^"]*)"$/) do |limit_type, transfer_type|
  on(SsoRequet) do |page|
  sleep 5
  $browser.find(:xpath, page.find_xpath("welcome_close_button")).click if $browser.has_xpath?(page.find_xpath("welcome_close_button"))
  p $user[$framework["region"]][$current_user_instance]["screen_appear_name"]
  $browser.find_link($user[$framework["region"]][$current_user_instance]["screen_appear_name"]).hover if $browser.find_link($user[$framework["region"]][$current_user_instance]["screen_appear_name"]).visible?
    # $browser.find_link("XXX").hover if $browser.find_link("XXX").visible?
  payee=limit_type =='IBFT' ? "LOCAL TRANSFER (OUTSIDE THE BANK)" : limit_type == 'TT' ? "INTERNATIONAL TRANSFERS" : limit_type== 'TPFT' ? 'LOCALS TRANSFER (WITHIN THE BANK)' : "TRANSFERS BETWEEN OWN ACCOUNTS"
  puts "payee:: #{payee}"
  if $framework["region"]=="SG"
    $browser.find_link(page.find_xpath("SG_TXL_Limit_check")).click if $browser.has_link?(page.find_xpath("SG_TXL_Limit_check"))
    otp= page.get_otp_and_fill($test_data["SIMCO Singapore"]["simco_environment"], $test_data["SIMCO Singapore"]["simco_country"], @current_user, $test_data["otp_url"])
    $browser.fill_in page.find_xpath("otp_security_token"), :with => otp
    $browser.find(:id, page.find_xpath("submit")).click
    @limit=page.fetch_limit_details(payee,$browser)
    puts "@limit:: #{@limit}"
    @ODL=page.fetch_limit_details("OVERALL DAILY LIMIT(AED)",$browser)
    puts @ODL
    $browser.find(:id, page.find_xpath("menu")).hover #if $browser.find_link(page.find_xpath(dasboard)).visible?
    $browser.find_link(transfer_type).click 
  elsif $framework["region"]=="AE"
    $browser.find_link(page.find_xpath("fund_limits_details_tab")).click if $browser.has_link?(page.find_xpath("fund_limits_details_tab"))
    @limit=page.fetch_limit_details(payee,$browser)
    puts "@limit::  #{@limit}"
    @ODL=page.fetch_limit_details("OVERALL DAILY LIMIT(AED)",$browser)
    @default_limit_AE=page.fetch_limit_details(payee,$browser)
  end
  # if $framework["environment"]=="AE"
  #   if @today_tran_amount!=nil 
  #     stop"Error..!!! Please choose another account this user have exceeded the #{limit_type} TXL Limit - Today's transfer : #{@today_tran_amount} TXL Limit: #{@limit}
  #     "if @today_tran_amount>=@limit && @overall_transfer_amount<@limit
  #   else
  #     show "hey..!!! There is no tranactions performed for the day, So total #{limit_type} limit can be used i.e #{@limit}"
  #   end
  # end
 end
end

Then(/^I validate the 2FL for "([^"]*)"$/) do |transaction_type|
  on(SGAELimits) do |page|
    puts "@limit here #{@limit}"
   page.limit_SG_AE("SGD-SGD", transaction_type, @limit)
  end
end


Then(/^I validate the Transaction limit for "([^"]*)"$/) do |transaction_type|
  on(SGAELimits) do |page|
    $check_limit_error=true
    page.limit_SG_AE("SGD-SGD", transaction_type, $user[$framework["region"]]["Common_limit"][transaction_type])
  end
end

Then(/^I validate the ODL for "([^"]*)"$/) do |transaction_type|
  on(SGAELimits) do |page|
    $check_limit_error=true
    page.limit_SG_AE("SGD-SGD", transaction_type, @ODL)
  end
end


###########################################################################AE##################################################
Then(/^I Validate the "([^"]*)" Transaction limit "([^"]*)"$/) do |currency_type, transaction_type|
on(SGAELimits) do |page|
  page.limit_SG_AE(currency_type, transaction_type, @limit)
end
end