When(/^I Add local payee account with "([^"]*)","([^"]*)"$/) do |beny_number,currency_type|
 on(Add_local_payee) do |page|   
    @ae_account_number = "#{Time.now.strftime("AE"+'000000000%Y%m%d%H%S')}"
    @payee_short_name = "IBFT#{Time.now.strftime("%d%H%S")}"
    page.navigate_to_local_payee    
    expect(page.verify_the_step).to eq "STEP 1 OF 2"
    page.select_payee_type("Other Local Bank Account")
    page.enter_payee_name("IBFT PAYEE with #{currency_type}")
    page.select_payee_country("United Arab Emirates")
    page.enter_address_fields("address1","address2","address3")      
    page.enter_account_number(@ae_account_number)   
    page.get_currency_list('AED')
    page.select_bank_from_list
    page.enter_payee_email("addbene@gmail.com")
    page.enter_payee_short_name(@payee_short_name)
    page.check_radio_button
    page.submit_payee
    page.submit_payee_2
    otp = page.retrieve_otp($user[$framework["region"]][$current_user_instance]["user_name"],@ae_account_number)
    page.enter_otp(otp)
    page.submit_payee_3     
 end 
end


Then(/^I Verify the newly added payee$/) do
  on(Add_local_payee) do |page|
  	expect(page.payee_success_message).to eq "Your new payee has been added successfully."
  	page.click_on_manage_payee
  	payee_data = page.verify_payee_in_list(@payee_short_name)
  	expect(payee_data).to include(@payee_short_name)
  	expect(payee_data).to include(@ae_account_number)    
  end
end



When(/^I Add local payee account with invalid iban account "([^"]*)","([^"]*)"$/) do |account_number, currency_type|
   on(Add_local_payee) do |page|   
    @ae_account_number = account_number
    @payee_short_name = "IBFT#{Time.now.strftime("%d%H%S")}"
    page.navigate_to_local_payee    
    expect(page.verify_the_step).to eq "STEP 1 OF 2"
    page.select_payee_type("Other Local Bank Account")
    page.enter_payee_name("IBFT PAYEE with #{currency_type}")
    page.select_payee_country("United Arab Emirates")
    page.enter_address_fields("address1","address2","address3") 
    page.enter_account_number(@ae_account_number)   
    page.get_currency_list('AED')
    page.select_bank_from_list
    page.enter_payee_email("addbene@gmail.com")
    page.enter_payee_short_name(@payee_short_name)
    page.check_radio_button
 end 
end

Then(/^I should see "([^"]*)" error message$/) do |error_message|
  on(Add_local_payee) do |page| 
  acutal_error = page.error_messages(1)
  expect(error_message).to eq acutal_error
  end
end


#--------------------------@RDC16569 @RDC17043 ------------------------------------------------
When(/^I Add TPFT payee with "([^"]*)","([^"]*)"$/) do |account_number, currency_type|
  on(Add_local_payee) do |page|   
    @ae_account_number = account_number
    @payee_short_name = "TPFT#{Time.now.strftime("%d%H%S")}"
    page.navigate_to_local_payee    
    expect(page.verify_the_step).to eq "STEP 1 OF 2"
    page.select_payee_type("Standard Chartered Account")
    page.enter_payee_name("TPFT PAYEE with #{currency_type}")
    page.enter_account_number(@ae_account_number)   
    page.tpft_get_currency_list('AED')
    page.enter_payee_email("addbene@gmail.com")
    page.enter_payee_short_name(@payee_short_name)
    page.check_radio_button
    page.submit_payee
    page.tpft_button2
    otp = page.retrieve_otp($user[$framework["region"]][$current_user_instance]["user_name"],@ae_account_number)
    page.enter_otp(otp)
    page.tpft_button3     
  end 
end



When(/^I Add  TPFT payee with existing "([^"]*)"$/) do |account_number|
  on(Add_local_payee) do |page|   
    @ae_account_number = account_number
    @payee_short_name = "TPFT#{Time.now.strftime("%d%H%S")}"
    page.navigate_to_local_payee    
    expect(page.verify_the_step).to eq "STEP 1 OF 2"
    page.select_payee_type("Standard Chartered Account")
    page.enter_payee_name("TPFT PAYEE")
    page.enter_account_number(@ae_account_number)   
    page.tpft_get_currency_list('AED')
    page.enter_payee_email("addbene@gmail.com")
    page.enter_payee_short_name(@payee_short_name)
    page.check_radio_button
    page.submit_payee
  end
end

Then(/^I Should see "([^"]*)" error message$/) do |error|
  on(Add_local_payee) do |page|  
    acutal_error = page.duplicate_bene_error
    expect(error).to eq acutal_error
  end
end

