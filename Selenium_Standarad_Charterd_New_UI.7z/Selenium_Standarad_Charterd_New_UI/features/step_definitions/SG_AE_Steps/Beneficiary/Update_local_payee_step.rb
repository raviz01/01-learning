# Update_local_payee.rb
When(/^I update local payee account with "([^"]*)","([^"]*)"$/) do |beny_number,currency_type|
 on(Add_local_payee) do |page|   
    @payee_short_name = "IBFT Updated"
    page.navigate_to_edit_payee    
    expect(page.verify_the_step).to eq "STEP 1 OF 2"
    page.select_edit_payee_country("Singapore")
    page.edit_address_fields("address1 Update","address2 Update","address3 Update")      
    page.edit_payee_email("updatebene@gmail.com")
    page.edit_payee_short_name(@payee_short_name)
    page.edit_submit_payee
    page.edit_submit_payee_2    
 end 
end

Then(/^I Verify the updated payee$/) do
  on(Add_local_payee) do |page|
    expect(page.payee_success_message).to eq "Payee detail has been updated successfully."
    page.click_on_manage_payee
    payee_data = page.verify_payee_in_list(@payee_short_name)
    expect(payee_data).to include(@payee_short_name)
    binding.pry
  end
end