Then(/^I submit "([^"]*)" IBFT Transfer by selecting different POP's:$/) do |type, table|
  on(TransactionLibrary) do |page|
      page.pop_validation(type, page.scrap_hash_data(table.hashes,"POP"))
  end
end


Then(/^I validate the POP's list:$/) do |table|
  on(TransactionLibrary) do |page|
      page.pop_list_validation(page.scrap_hash_data(table.hashes,"POP"))
  end
end