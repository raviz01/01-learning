Then(/^I validate the payment initation for "([^"]*)" using credit card$/) do |currency_type|
   on(Creditcard) do |page|
      if currency_type == 'same'
          page.cash_in_advance_OAFT($browser, currency_type) 
           puts "!!!Successfully navigated to transaction submition page!!!" if $browser.has_xpath?(page.find_xpath("finish_close_button")) 
            puts "#" * 50
            puts "!!!Reference Number::::#{$browser.find(:xpath, page.find_xpath("reference_number")).text} !!!" 
            puts "!!!To_Account_Number::::#{$browser.find(:xpath, page.find_xpath("account_to_be_transfered")).text} !!!"    
            puts "!!!From_Account_Number::::#{$browser.find(:xpath, page.find_xpath("account_to_be_transfered_from")).text} !!!"   
            puts "!!!Currency_Value::::#{$browser.find(:xpath, page.find_xpath("currency_amount")).text} !!!"   
            puts "#" * 50 
      else 
      page.global_account($browser, currency_type) 
      end  
   end
end

When(/^I select credit card account from account list\tfor "([^"]*)"$/) do |transaction_type|
   on(TransactionLibrary) do |page|
    page.payee_selection(transaction_type)
    page.wait_for_ajax   
    page.credit_card_selection(transaction_type)
    page.wait_for_ajax
  end 
end


Given(/^I select credit card account To account list for "([^"]*)"$/) do |transaction_type|
 on(TransactionLibrary) do |page|   
    page.wait_for_ajax 
    page.ibcc_selection(transaction_type)        
  end 
end

Then(/^I validate the payment initation for IBCC transaction$/) do
  step 'I validate the payment initation for cash in advance'
end

Then(/^I validate the payment initation for cash in advance$/) do
on(TransactionLibrary) do |page|  
    page.review_the_transaction
    page.wait_for_ajax   
    page.conformation_of_transaction
 puts "#"*50    
  end  
end

Then(/^I validate credit card account should not display from account list for "([^"]*)"$/) do |transaction_type|
 on(TransactionLibrary) do |page|
    page.payee_selection(transaction_type)
    page.wait_for_ajax   
    page.credit_card_selection(transaction_type)
    page.wait_for_ajax
  end 
end

Then(/^I validate the payment initation for cash in advance for "([^"]*)"$/) do |arg1|
  on(Creditcard) do |page|    
    page.credit_card_inft($browser)
    page.wait_for_ajax      
  end 
end