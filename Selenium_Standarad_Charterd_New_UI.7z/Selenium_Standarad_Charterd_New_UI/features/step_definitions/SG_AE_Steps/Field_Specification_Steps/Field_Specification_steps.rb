Then(/^I Select the "([^"]*)" Selection local account$/) do |staranderad_screen|
on(TransactionLibrary) do |page|
   page.wait_for_ajax
         begin
        $browser.find(:xpath, page.find_xpath("local_transfer_table_data")).text 
         rescue Exception => e 
         puts @error= e.message
         puts "error #{@error}"
        end
        raise e if  !@error.include? "Ambiguous match,"
       payee_data_length=@error.split(" ").map(&:to_i).compact
   end
       
end

Then(/^I validate whether the Payee is data is displaying$/) do
	on(TransactionLibrary) do |page|
       page.wait_for_ajax
        begin
        $browser.find(:xpath, page.find_xpath("local_transfer_table_data")).text 
         rescue Exception => e 
         puts error= e.message
         puts "error #{error}"
         raise e if  !error.include? "Ambiguous match,"
        end
       payee_data_length=error.split(" ").map(&:to_i).compact
       fail "Error..!! Payee list is empty for user - #{$current_user}"  if payee_data_length[3]==0
   end
end

Then(/^I perform search for payee details and validate the result$/) do
	on(TransactionLibrary) do |page|
     page.wait_for_ajax
        begin

        $browser.find(:xpath, page.find_xpath("local_transfer_table_data")).text 
         rescue Exception => e 
         puts error= e.message
         puts "Im here 1"
         puts "error #{error}"
        raise e if  !error.include? "Ambiguous match,"
        end
       payee_data_length=error.split(" ").map(&:to_i).compact
       fail "Error..!! Payee list is empty for user - #{$current_user}"  if payee_data_length[3]==0
       @payee_list=[]
        for acc_index in 1...payee_data_length[3]
           @payee_list<<$browser.find(:xpath, "html/body//form//table[1]/tbody/tr[#{acc_index}]/td[1]").text
        end
       rand_number=rand(0...@payee_list.length)
       puts "@payee_list[rand_number] #{@payee_list[rand_number]}"
       $browser.fill_in page.find_xpath("search_payee"), :with => @payee_list[rand_number]
       sleep 15
        begin
          
        $browser.find(:xpath, page.find_xpath("local_transfer_table_data")).text 
         rescue Exception => e 
         puts error= e.message
         puts "Im here 2"
         puts "error #{error}"
        raise e if  !error.include? "Ambiguous match,"
         @payee_data_length_2=error.split(" ").map(&:to_i).compact
        end
      
       puts "payee_data_length  #{@payee_data_length_2}"
       fail "Defect..!! Payee search is not displaying existing value in the list"  if @payee_data_length_2[3]==0
       @payee_list_2=[]
        for acc_index in 1...@payee_data_length_2[3]
           @payee_list_2<<$browser.find(:xpath, "html/body//form//table[1]/tbody/tr[#{acc_index}]/td[1]").text
        end
        # @payee_list.each do |each_payee|
        # 	fail "Defect..!! list is displaying wrong search result 
        # 	Expected: #{@payee_list[rand_number]}
        # 	Actual: #{each_payee}" if !@payee_list[rand_number].include?each_payee
        # end
    end
end

Then(/^I Verify that the manage payee button is displaying$/) do
	on(TransactionLibrary) do |page|
	 page.wait_for_ajax
     fail "Defect..!!! Manage payee button is not dispalying" if !$browser.has_xpath?(page.find_xpath("manage_payee_button"))
    end
end

Then(/^I Verify Note section$/) do
  on(TransactionLibrary) do |page|
  	puts $browser.find(:xpath, page.find_xpath("notes")).text 
  end
end

Then(/^I verify the selected payee details in from Screen$/) do
	on(TransactionLibrary) do |page|
	  page.payee_selection("IBFT")
    sleep 5
	  page.from_screen_data_capture
	  page.from_screen_data_validation
	end
end

Then(/^I validate the Transfer Reference feild and default value$/) do
	on(TransactionLibrary) do |page|
	  page.payee_selection("IBFT")
	  page.wait_for_ajax
	  $browser.find(:xpath, page.find_xpath("select_Account")).click
	  $browser.find(:xpath, "//*[@class='ui-menu ui-corner-bottom ui-widget ui-widget-content']/li[3]").click 
	  

       # fail "Defect(1191)..!!! filed name should be #{page.find_xpath("Description_filed_name_AE")}
       # BUT displaying #{$browser.find(:xpath, page.find_xpath("trans_ref_AE")).text}" if $browser.find(:xpath, page.find_xpath("trans_ref_AE")).text!=page.find_xpath("Description_filed_name_AE")

	  # fail "Defect..!!! Transfer Reference feild default value mismatch 
	  # Expected:: #{page.find_xpath("default_description_AE")}
	  # Actual:: #{$browser.find(:id, page.find_xpath("description_feild_path")).text}" if $browser.find(:id, page.find_xpath("description_feild_path")).text != page.find_xpath("default_description_AE")
	end
end

Then(/^I validate Description field without default value$/) do
    on(TransactionLibrary) do |page|
	  page.payee_selection("IBFT")
	  page.wait_for_ajax
	  $browser.find(:xpath, page.find_xpath("select_Account")).click
	  $browser.find(:xpath, "//*[@class='ui-menu ui-corner-bottom ui-widget ui-widget-content']/li[3]").click 
	  
      fail "Defect..!!! filed name should be #{page.find_xpath("Description_filed_name_SG")}
       BUT displaying #{$browser.find(:xpath, page.find_xpath("Description_SG")).text}" if $browser.find(:xpath, page.find_xpath("Description_SG")).text!=page.find_xpath("Description_filed_name_SG")

	  # fail "Defect..!! For SG system is displaying default value[#{$browser.find(:xpath, page.find_xpath("description_feild_path")).text}]" if $browser.find(:xpath, page.find_xpath("description_feild_path")).text !=nil
	end
end