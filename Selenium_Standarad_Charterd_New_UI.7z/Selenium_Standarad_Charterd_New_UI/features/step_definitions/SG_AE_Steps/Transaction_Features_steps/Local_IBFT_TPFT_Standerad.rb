Then(/^I Select the "([^"]*)" Transction$/) do |trans_type|
on(TransactionLibrary) do |page|
   
end
  
end

Then(/^I perform "([^"]*)" transaction$/) do |trans_type|
	on(TransactionLibrary) do |page|
      page.local_transfer_SG(trans_type)
	end
end

# Then(/^I perform "([^"]*)" cross currency transaction$/) do |trans_type| 
#   on(TransactionLibrary) do |page|
#   	puts
#       page.currency_type_transfer_AE_SG(trans_type)
#   end
# end

Then(/^I perform "([^"]*)" cross currency transaction with below From data:$/) do |trans_type, table|
   on(TransactionLibrary) do |page|
      page.currency_type_transfer_AE_SG(trans_type, page.scrap_hash_data(table.hashes,"curency type"))
     
  end
end

Then(/^I perform "([^"]*)" same FCY\-FCY transaction for below regions:$/) do |trans_type, table|
	on(TransactionLibrary) do |page|
		puts "table #{table}"
	   page.fcy_AE(trans_type, page.scrap_hash_data(table.hashes,"curency type"))
	end
end

Then(/^I perform "([^"]*)" cross currency transaction with below Payee data:$/) do |trans_type, table|
  on(TransactionLibrary) do |page|
	   page.fcy_lcY_cross_Currencies(trans_type, page.scrap_hash_data(table.hashes,"curency type"))
   end
end