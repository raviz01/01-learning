Then(/^I validate the payment initation for a "([^"]*)"$/) do |currency_type|
   on(Oaft) do |page|
  page.oaft_local_transaction($browser, currency_type) 
  puts "!!!Successfully navigated to transaction submition page!!!" if $browser.has_xpath?(page.find_xpath("finish_close_button")) 
        puts "#" * 50
        puts "!!!Reference Number::::#{$browser.find(:xpath, page.find_xpath("reference_number")).text} !!!" 
        puts "!!!To_Account_Number::::#{$browser.find(:xpath, page.find_xpath("account_to_be_transfered")).text} !!!"    
        puts "!!!From_Account_Number::::#{$browser.find(:xpath, page.find_xpath("account_to_be_transfered_from")).text} !!!"   
        puts "!!!Currency_Value::::#{$browser.find(:xpath, page.find_xpath("currency_amount")).text} !!!"   
        puts "#" * 50 
  end
end

Given(/^I should see the error message for "([^"]*)" funds transfer$/) do |zero_balance|
  on(Oaft) do |page|
     page.oaft_local_transaction($browser, zero_balance)
  end   
end

Then(/^I validate the payment initation for a "([^"]*)" to check transfer initiation screen$/) do |currency_type|
  on(Oaft) do |page|
  page.oaft_local_transaction($browser, currency_type)
  puts "!!!Successfully navigated to transaction submition page!!!" if $browser.has_xpath?(page.find_xpath("finish_close_button"))
  $browser.find(:xpath, page.find_xpath("make_another_transfer")).click
  page.wait_for_ajax
  pop_up_message "!!!Successfully Navigated back to csl transfer link page!!!" if $browser.has_xpath?(page.find_xpath("oaft_to_account"))
end
end

Then(/^I validate the payment initation for a "([^"]*)" to check dashboard page screen$/) do |currency_type|
  on(Oaft) do |page|
  page.oaft_local_transaction($browser, currency_type)
  puts "!!!Successfully navigated to transaction submition page!!!" if $browser.has_xpath?(page.find_xpath("finish_close_button"))
  $browser.find(:xpath, page.find_xpath("finish_close_button")).click
  page.wait_for_ajax
  pop_up_message("!!Successfully Navigated back to Overview screen page!!")if $browser.has_xpath?(page.find_xpath("Dashboard"))
  end 
end

Then(/^I validate global account transaction for a "([^"]*)"$/) do |transaction_type|
 on(Oaft) do |page|
  page.oaft_global_transaction($browser, transaction_type)
  puts "!!!Successfully navigated to transaction submition page!!!" if $browser.has_xpath?(page.find_xpath("finish_close_button"))  
        puts "#" * 50       
        puts "!!!Reference Number::::#{$browser.find(:xpath, page.find_xpath("reference_number")).text} !!!" 
        puts "!!!To_Account_Number::::#{$browser.find(:xpath, page.find_xpath("account_to_be_transfered")).text} !!!"    
        puts "!!!From_Account_Number::::#{$browser.find(:xpath, page.find_xpath("account_to_be_transfered_from")).text} !!!"   
        puts "!!!Currency_Value::::#{$browser.find(:xpath, page.find_xpath("currency_amount")).text} !!!"   
        puts "#" * 50 
end
end

Then(/^I should see the error message for "([^"]*)" funds for global accounts$/) do |currency_value|
on(Oaft) do |page|
  page.oaft_global_transaction($browser, currency_value) 
end
end

Then(/^I should see payment initiation page when user click Make another transfer button for "([^"]*)"$/) do |transaction_type|
  on(Oaft) do |page|
   page.oaft_global_transaction($browser, transaction_type)  
   puts "!!!Successfully navigated to transaction submition page!!!" if $browser.has_xpath?(page.find_xpath("finish_close_button"))
   puts "#" * 50
        puts "!!!Reference Number::::#{$browser.find(:xpath, page.find_xpath("reference_number")).text} !!!" 
        puts "!!!To_Account_Number::::#{$browser.find(:xpath, page.find_xpath("account_to_be_transfered")).text} !!!"    
        puts "!!!From_Account_Number::::#{$browser.find(:xpath, page.find_xpath("account_to_be_transfered_from")).text} !!!"   
        puts "!!!Currency_Value::::#{$browser.find(:xpath, page.find_xpath("currency_amount")).text} !!!"   
   puts "#" * 50 
  $browser.find(:xpath, page.find_xpath("make_another_transfer")).click
  page.wait_for_ajax
  fail "!!!Defect!!! System does not navigated back to csl transfer link page" if !$browser.has_xpath?(page.find_xpath("oaft_to_account"))
  puts "!!!Successfully Navigated back to csl transfer link page!!!" if $browser.has_xpath?(page.find_xpath("oaft_to_account"))
end
end

Then(/^I should see overview screen when user click Finish & Close button for "([^"]*)"$/) do |transaction_type|
    on(Oaft) do |page|
  page.oaft_global_transaction($browser, transaction_type)
  puts "!!!Successfully navigated to transaction submition page!!!" if $browser.has_xpath?(page.find_xpath("finish_close_button"))
  puts "#" * 50
        puts "!!!Reference Number::::#{$browser.find(:xpath, page.find_xpath("reference_number")).text} !!!" 
        puts "!!!To_Account_Number::::#{$browser.find(:xpath, page.find_xpath("account_to_be_transfered")).text} !!!"    
        puts "!!!From_Account_Number::::#{$browser.find(:xpath, page.find_xpath("account_to_be_transfered_from")).text} !!!"   
        puts "!!!Currency_Value::::#{$browser.find(:xpath, page.find_xpath("currency_amount")).text} !!!"   
   puts "#" * 50 
  $browser.find(:xpath, page.find_xpath("finish_close_button")).click  
  page.wait_for_ajax
  fail "!!!Defect!!! System does not Navigated back to Overview screen page" if !$browser.has_xpath?(page.find_xpath("Dashboard"))
  puts "!!Successfully Navigated back to Overview screen page!!" if $browser.has_xpath?(page.find_xpath("Dashboard"))
  end
end

Given(/^I click on back button and modified the screen$/) do
 on(Oaft) do |page|
     page.back_button($browser)
 end
end

Then(/^I should able to perform global account transaction "([^"]*)"$/) do |transaction_type|
  on(Oaft) do |page| 
  page.wait_for_ajax  
   page.oaft_global_transaction($browser, transaction_type)
   sleep 8
   fail "!!!Defect!!! System could not able to perform transaction!!!" if !$browser.has_xpath?(page.find_xpath("finish_close_button"))
   puts "!!!Successfully navigated to transaction submition page!!!" if $browser.has_xpath?(page.find_xpath("finish_close_button"))
   puts "#" * 50
        puts "!!!Reference Number::::#{$browser.find(:xpath, page.find_xpath("reference_number")).text} !!!" 
        puts "!!!To_Account_Number::::#{$browser.find(:xpath, page.find_xpath("account_to_be_transfered")).text} !!!"    
        puts "!!!From_Account_Number::::#{$browser.find(:xpath, page.find_xpath("account_to_be_transfered_from")).text} !!!"   
        puts "!!!Currency_Value::::#{$browser.find(:xpath, page.find_xpath("currency_amount")).text} !!!"   
   puts "#" * 50 
  end 
end
