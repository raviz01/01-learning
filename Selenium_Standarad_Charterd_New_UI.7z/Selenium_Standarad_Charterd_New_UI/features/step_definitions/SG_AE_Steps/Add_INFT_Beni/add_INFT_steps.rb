Given(/^I add the beni for "([^"]*)"$/) do |currency_type|
  on(Beni) do |page|
  	 page.wait_for_ajax  	 
     page.add_inft(currency_type)
     $browser.find(:xpath, page.find_xpath("finish_close_button")).click 
  end   
end

Then(/^I validate the added beni details in "([^"]*)" screen$/) do |transfer_type| 
 on(SsoRequet) do |page|	
	 $browser.find(:id, page.find_xpath("menu")).hover #if $browser.find_link(page.find_xpath(dasboard)).visible?
	 $browser.find_link(transfer_type).click 
	 sleep 5
 end 
  on(Beni) do |page|
  	 page.wait_for_ajax  	 
     page.validate_inft_page($iban_Number)
    sleep 5
  end 
  end

Given(/^I add the duplicate beni for "([^"]*)"$/) do |arg1|
  on(Beni) do |page|
  	 page.wait_for_ajax  	 
     page.duplicate_iban 
  end  
end

Then(/^I validate the error message "([^"]*)" screen$/) do |arg1|
  
end
