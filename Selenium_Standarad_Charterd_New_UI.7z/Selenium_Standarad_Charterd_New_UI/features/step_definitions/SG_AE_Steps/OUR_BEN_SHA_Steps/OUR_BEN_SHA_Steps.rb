Then(/^I submit "([^"]*)" IBFT Transfer by selecting "([^"]*)"$/) do |currency_type, transaction_type|
  on(OurBenShaLib) do |page|
  	page.our_ben_sha_validation(currency_type, transaction_type)
  end
end

# Then(/^I submit "([^"]*)" "([^"]*)" Transfer by selecting "([^"]*)"$/) do |currency_type, transfer, transaction_type|
#   on(OurBenShaLib) do |page|
#   	page.international_our_ben_sha_validation(currency_type, transfer, transaction_type)
#   end
# end

Then(/^I submit "([^"]*)" "([^"]*)" Transfer with Charges To Be Paid By "([^"]*)"$/) do |currency_type, transfer_type, paid_by|
  	on(OurBenShaLib) do |page|
     page.inft_xbt_transfer_our_ben_sha(currency_type, transfer_type, paid_by)
	end
end
