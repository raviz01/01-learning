Given(/^I Login to BAU i-banking with valid "([^"]*)"$/) do |user|
  on(Login) do |page|
		pop_up_message "Started Selenium Automation testing for #{$framework['region']}"
		 $current_user_instance=user
		 $current_user=$user[$framework["region"]][$current_user_instance]["user_name"]
		show "Current_User is  #{$current_user_instance} - #{$current_user} "
		# puts "sso --#{$framework['Direct_SSO']}--"		 
		if $framework['Direct_SSO'] == false
		 	$browser.fill_in page.find_xpath("user_name"), :with => $current_user
		  	$browser.fill_in page.find_xpath("password"), :with => $user[$framework["region"]][$current_user_instance]["password"]
		  	# capture = $browser.find(:xpath, page.find_xpath("capture_captcha")).text if $framework["region"] == "CN" 
		  	# puts "capture:: #{capture}"
		  	# $browser.fill_in page.find_xpath("enter_captcha"), :with => capture if $framework["region"] == "CN"
		  	$browser.click_button page.find_xpath("login") if $framework["region"] 			                          	        	
   	    end
	end
end

Then(/^I navigate "([^"]*)"$/) do |transfer_type|
	on(SsoRequet) do |page|	
	$browser.find(:xpath, page.find_xpath("welcome_close_button")).click if $browser.has_xpath?(page.find_xpath("welcome_close_button"))
	   unless $framework['Direct_SSO'] == true	  			   
	            if $framework["region"] == "SG"  
	            	sleep 5
	              $browser.find(:id, page.find_xpath("menu")).hover #if $browser.find_link(page.find_xpath(dasboard)).visible?
	              $browser.find_link(transfer_type).click  
	              $browser.find(:xpath, page.find_xpath("standered_screen")).click if transfer_type=="To Local Account"         
	            	 otp= page.get_otp_and_fill($test_data["SIMCO Singapore"]["simco_environment"], $test_data["SIMCO Singapore"]["simco_country"], $current_user, $test_data["otp_url"])
	                 $browser.fill_in page.find_xpath("otp_security_token"), :with => otp
	                 $browser.find(:id, page.find_xpath("submit")).click
	                 # $browser.find(:xpath, page.find_xpath("sg_transfer_link_page")).click
	            elsif $framework["region"] == "AE"
	              $browser.find(:id, page.find_xpath("menu")).hover #if $browser.find_link(page.find_xpath(dasboard)).visible?
	              $browser.find_link(transfer_type).click if $browser.find_link(transfer_type).visible? == true 
	            elsif $framework["region"] == "CN" 
	               $browser.find(:xpath, page.find_xpath("Online_FX")).click
	               $browser.find(:xpath, page.find_xpath("To_Local_Account")).click
	            end
	    else
	           $browser.visit page.landing_directly_to_csl($current_user_instance, transfer_type) 
	    end  
	end
	sleep 5
end

Then(/^I have valid data$/) do
  on(TransactionLibrary) do |page|
  	puts page.find_xpath("local_transfer_table_data")
  	sleep 6
 	puts $browser.find(:xpath, page.find_xpath("local_transfer_table_data")).text
 end
end

Given(/^I Fetch the BAU "([^"]*)" Payee data$/) do |page|
on(SsoRequet) do |page|	
  $browser.find(:xpath, page.find_xpath("Transfer_Money")).click
  $browser.find(:xpath, page.find_xpath("To_Local_Account")).click
end
end





