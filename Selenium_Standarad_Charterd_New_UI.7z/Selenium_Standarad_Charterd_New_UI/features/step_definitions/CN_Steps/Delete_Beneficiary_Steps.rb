Then(/^I Delete any random "([^"]*)"$/) do |bene_type|
  on(CNPayeeLib) do |page|
  	sleep 5
  	p bene_type
    @deleted_payee=page.delete_payee(bene_type)
  end
end

Then(/^I validate Beneficiary is deleted successfully under "([^"]*)"$/) do |screen|
   on(CNPayeeLib) do |page|
  	page.validate_bene_exits(@deleted_payee)
  end
end
