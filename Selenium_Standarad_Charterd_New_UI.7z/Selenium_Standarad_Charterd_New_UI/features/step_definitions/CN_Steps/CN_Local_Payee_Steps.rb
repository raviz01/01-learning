Then(/^I validate whether the local payee list is displaying$/) do
	on(CNPayeeLib) do |page|
    # page.get_bene_details("ALL")
	 page.payee_list_displaying_validation
	end
end

Then(/^I validate payee list header as per the customer profile$/) do 
  on(CNPayeeLib) do |page|
	 page.en_cn_profile_header_validation
  end
end

Then(/^I validate select "([^"]*)"$/) do |tran_type|
 on(CNPayeeLib) do |page|
   page.cn_payee_selection(tran_type)
 end
end

Then(/^I validate seleted "([^"]*)" payee in step(\d+)$/) do |tran_type, arg2|
  on(CNPayeeLib) do |page|
    page.cn_payee_selection(tran_type)
    page.from_screen_data_capture
    page.from_screen_data_validation
  end
end

Then(/^I able to navigate to local transfer page$/) do
  pending # Write code here that turns the phrase above into concrete actions
end

Then(/^I validate step(\d+) language as per the customer profile$/) do |arg1|
  on(CNPayeeLib) do |page|
    page.en_cn_profile_lable_validation
  end
end

Then(/^I Comapare the BAU Data with CSL Screen$/) do
  pending # Write code here that turns the phrase above into concrete actions
end