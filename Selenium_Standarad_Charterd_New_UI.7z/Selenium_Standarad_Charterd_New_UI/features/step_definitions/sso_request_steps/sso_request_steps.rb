When(/^I navigate to "([^"]*)" then to "([^"]*)"$/) do |dasboard, menuitem|
	on(SsoRequet) do |page|
    sleep 2
    if $framework['Direct_SSO'] == false   			   
          sleep 2
             @sub_tab=menuitem.split('/')
            if $framework["environment"] == "SG"             
              $browser.find(:xpath, page.find_xpath("welcome_close_button")).click
              sleep 3
              $browser.find(:id, page.find_xpath("menu")).hover #if $browser.find_link(page.find_xpath(dasboard)).visible?
            	sleep 3
              $browser.find_link(@sub_tab[0]).click               
              sleep 3
            	 otp= page.get_otp_and_fill($test_data["SIMCO Singapore"]["simco_environment"], $test_data["SIMCO Singapore"]["simco_country"], @current_user, $test_data["otp_url"])
                 $browser.fill_in page.find_xpath("otp_security_token"), :with => otp
                 $browser.find(:id, page.find_xpath("submit")).click
                 sleep 3
                 $browser.find(:xpath, page.find_xpath("sg_transfer_link_page")).click
            elsif $framework["environment"] == "AE"
              $browser.find(:id, page.find_xpath("menu")).hover #if $browser.find_link(page.find_xpath(dasboard)).visible?
            	 $browser.find_link(@sub_tab[1]).click if $browser.find_link(@sub_tab[1]).visible? == true 
            end
      end      
    end        
end


Then(/^I should able to see Transfer Page$/) do
  on(SsoRequet) do |page|
 sleep 10
          if $framework['Direct_SSO'] == false
            fail "!!!Error!!! Transfer link page not loaded properly" if !$browser.find(:xpath, page.find_xpath("transfer_link_page")).visible?       
          end
     end     
end

When(/^I close transfer link page$/) do
  on(SsoRequet) do |page|       
    $browser.find(:xpath, page.find_xpath("transfer_close_button")).click     
  end
end

Then(/^I should navigate back to "([^"]*)" page$/) do |tab|
  on(SsoRequet) do |page|       
    # fail "!!!Error!!! Login Page displaying instead of Dashboard page" if $browser.find_field(page.find_xpath("user_name")).visible?
    fail "!!!Error!!! Dashboard page not loaded" if !$browser.find_link(page.find_xpath(tab)).visible? 
  end
 end 