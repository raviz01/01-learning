 class SsoRequet
	include Handler
	include WaitForAjax


	def initialize
	  super
	    @xpath = {
	       "dasboard"				 						=>"DASHBOARD...",
	       "transfer_history"                               =>"Transfer History",
	       "transfer_text"								    =>"Your other SCB account",
	       "user_name"                                      => "j_username",
	       "scb_account_details"  							=>"//div[@class='option-card-label ng-binding'][contains(text(),'Other SCB')])",
	       "fund_limits_details_tab"                        =>"Change Funds Transfer Limit",
	       "transfer_text"								    =>"Your other SCB account",	     	       
	       "transfer_link_page"                             => "//*[@id='scb-ng-component-8-step-0']/h2" ,	       
	       "transfer_close_button"                          =>  "//button[@ng-click='closeSession()']",  
	       "one_of_contacts"                                =>  "//div[(@class='option-card-wrapper') and (contains(.,'One of your contacts'))]" ,
		   "menu"                                           => "menu",
		   "welcome_close_button"                           => "//div[@class='sc-close-btn']",
		    "Online_FX"                                     => "//a[@class='jsAccordion plusIcon titleBG'][contains(text(),'Online FX')]",
            "To_Local_Account"                              => "/html/body/div/div/div[1]/section/ul[7]/li[3]/a",
            "Transfer_Money"                                => "//a[@class='jsAccordion plusIcon titleBG'][contains(text(),'Transfer Money')]",

	       #otp screen xpaths
	       "otp_env"                                        =>"env",
       	   "otp_country"                                    =>"country",
           "get_otp"                                        =>"go",
           "user_id"                                        =>"userId", 
           "otp_security_token"               				=>"securityToken",
       	   "submit"                           			    =>"Proceed",
       	   "sg_transfer_link_page"     			            =>"//*[@id='printContent']/a[2]",
       	   "AE_transfers_history_list"                      =>"//*[@id='transferHistoryList']",
       	   "Account Preferences"							=>"Account Preferences",
       	    "SG_TXL_Limit_check"                            => "Authorisation & Notifications",
       	    "SG_transfers_history_list"						=>"//*[@id='vPaymentList']",
       	    "ODL" 											=>"//*[@id='preferenceForm']/table/tbody/tr/td/table[2]/tbody/tr[2]/td[3]",
       	    "standered_screen"                              =>"//*[@id='command']/table/tbody/tr[2]/td/div/a[1]/input",
	    }

	end#//*[@id="changeFTLimitForm"]/table/tbody/tr/td/table/tbody/tr[2]/td[4]

	def fetch_limit_details(limit_type,browser,default_limit_type=nil)

		if $framework["region"]=="AE"
			if default_limit_type==nil
				limit=browser.find(:xpath, "//*[@id='changeFTLimitForm']/table//tr[3]/td[4]").text if limit_type.strip=="LOCAL TRANSFER (OUTSIDE THE BANK)"
				limit=browser.find(:xpath, "//*[@id='changeFTLimitForm']/table//tr[4]/td[4]").text if limit_type.strip=="LOCALS TRANSFER (WITHIN THE BANK)"
			    # limit=browser.find(:xpath, "//*[@id='changeFTLimitForm']/table//tr[4]/td[4]").text if limit_type.strip=="TRANSFERS BETWEEN OWN ACCOUNTS"
			    limit=browser.find(:xpath, "//*[@id='changeFTLimitForm']/table//tr[5]/td[4]").text if limit_type.strip=="INTERNATIONAL TRANSFERS"
			    limit=browser.find(:xpath, "//*[@id='changeFTLimitForm']/table//tr[6]/td[3]").text if limit_type.strip=="OVERALL DAILY LIMIT(AED)"
			elsif default_limit_type!=nil
				puts "check #{browser.find(:xpath, "//*[@id='changeFTLimitForm']/table//tr[3]/td[3]").text}"
				limit=browser.find(:xpath, "//*[@id='changeFTLimitForm']/table//tr[3]/td[3]").text if limit_type.strip=="LOCAL TRANSFER (OUTSIDE THE BANK)"
				limit=browser.find(:xpath, "//*[@id='changeFTLimitForm']/table//tr[4]/td[3]").text if limit_type.strip=="LOCALS TRANSFER (WITHIN THE BANK)"
			    limit=browser.find(:xpath, "//*[@id='changeFTLimitForm']/table//tr[5]/td[3]").text if limit_type.strip=="TRANSFERS BETWEEN OWN ACCOUNTS"
			    limit=browser.find(:xpath, "//*[@id='changeFTLimitForm']/table//tr[6]/td[3]").text if limit_type.strip=="INTERNATIONAL TRANSFERS"
			end
		elsif $framework["region"]=="SG"
			limit=browser.find(:xpath, "//*[@id='billPaymentLimit']").value if limit_type.strip=="BILL PAYMENTS"
			puts limit=browser.find(:xpath, "//*[@id='thirdPartyLimit']").value if limit_type.strip=="LOCALS TRANSFER (WITHIN THE BANK)"
			limit=browser.find(:xpath, "//*[@id='interbankLimit']").value if limit_type.strip=="LOCAL TRANSFER (OUTSIDE THE BANK)"
		    limit=browser.find(:xpath, "//*[@id='internationalLimit']").value if limit_type.strip=="INTERNATIONAL TRANSFERS"
		    if limit_type == "OVERALL DAILY LIMIT(AED)"
		    	$browser.find_link($user[$framework["region"]][$current_user_instance]["screen_appear_name"]).hover
				browser.find_link(find_xpath("Account Preferences")).click
		    	limit=browser.find(:xpath, "//*[@id='preferenceForm']/table/tbody/tr/td/table[2]/tbody/tr[2]/td[3]").text if limit_type.strip=="OVERALL DAILY LIMIT(AED)"
		    	limit=limit[4..limit.length]
		    end

	     end
	   return limit
    end


end