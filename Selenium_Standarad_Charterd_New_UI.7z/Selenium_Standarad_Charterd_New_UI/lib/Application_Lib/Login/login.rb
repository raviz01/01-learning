class Login
  include Handler
  

def initialize
  super
    @xpath = {
      #BAU Screen Xpaths
       "user_name"                         => "j_username",
       "password"                          => "j_password",
       "login"                             => "Login",
       "savings&Current_text"              => ".//*[@id='printContent']//div[3]/div",
       "enter_captcha"                     => "captcha",
       "capture_captcha"                   => "//img[@id='captchaImage']",
       

       #Otp Screen Xpaths
       "otp_env"                           => "env",
       "otp_country"                       => "country",
       "get_otp"                           => "go",
       "user_id"                           => "userId", 
       # "otp_security_token"                =>"securityToken"
       "otp_security_token"                =>"otp_security_token"
       

    }

end


    
        
end