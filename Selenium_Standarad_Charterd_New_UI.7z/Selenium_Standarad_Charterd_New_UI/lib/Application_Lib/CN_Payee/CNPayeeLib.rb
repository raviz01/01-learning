class CNPayeeLib
	include Handler
    include WaitForAjax
    include PomLocalTransfer
    include ServiceFile
   

   def delete_payee(bene_type)
     sleep 2
     # puts "bene_type #{bene_type}"
     # no_of_payees=payee_list_displaying_validation
     # puts "no_of_payees #{no_of_payees}"
     # rand_payee=1
     # rand_payee=rand(1..no_of_payees) if no_of_payees!=1
     deleted_payee=$browser.find(:xpath, "html/body//form//table[1]/tbody/tr[1]/td[1]").text
     $browser.find(:xpath, "html/body//form//table[1]/tbody/tr[1]/td[5]").click
     sleep 2
     $browser.find(:xpath, find_xpath("Yes")).click if $browser.has_xpath?(find_xpath("pop_up_window"))
     return deleted_payee
  end

  def validate_bene_exits(check_bene)
    no_of_payees=payee_list_displaying_validation
    for acc_index in 1..no_of_payees[3]
      fail "Defect..!!! Bene(#{check_bene}) has not been deleted " if $browser.find(:xpath, "html/body//form//table[1]/tbody/tr[#{acc_index}]/td[1]").text==check_bene
    end
  end
    
   def en_cn_profile_header_validation
   	 payee_name_header_UI=$browser.find(:xpath, "html/body//form//table[1]/tbody/tr[1]/td[1]").text
     bank_name_header_UI=$browser.find(:xpath, "html/body//form//table[1]/tbody/tr[1]/td[2]").text
     sub_branch_name_header_UI=$browser.find(:xpath, "html/body//form//table[1]/tbody/tr[1]/td[3]").text
     account_number_header_UI=$browser.find(:xpath, "html/body//form//table[1]/tbody/tr[1]/td[4]").text
     # delecte_header_UI=$browser.find(:xpath, "html/body//form//table[1]/tbody/tr[1]/td[5]").text
   	 confulence_payee_header=$user[$framework['region']]['Payee_'+"#{$user['LANG']}"+'_Header']
   	 conf_payee_data=confulence_payee_header.spilt(',')
   	 fail "Defect..!!! China #{$user['LANG']} user header is not as per the confulence
   	 Expected payee name header: #{conf_payee_data[0]} 
   	 Actually paye name header : #{payee_name_header_UI}" if conf_payee_data[0]==payee_name_header_UI
     fail "Defect..!!! China #{$user['LANG']} user header is not as per the confulence
   	 Expected bank name header: #{conf_payee_data[0]} 
   	 Actually bank name header: #{payee_name_header_UI}" if conf_payee_data[1]=bank_name_header_UI
   	 fail "Defect..!!! China #{$user['LANG']} user header is not as per the confulence
   	 Expected sub branch name header: #{conf_payee_data[0]} 
   	 Actually sub branch name header: #{payee_name_header_UI}" if conf_payee_data[2]=sub_branch_name_header_UI
     fail "Defect..!!! China #{$user['LANG']} user header is not as per the confulence
   	 Expected Acc No header: #{conf_payee_data[0]} 
   	 Actually Acc No header: #{payee_name_header_UI}" if conf_payee_data[3]=account_number_header_UI
   end

    def payee_list_displaying_validation
        wait_for_ajax
        $browser.find(:xpath, find_xpath("local_transfer_table_data")).text 
         rescue Exception => e 
         puts error= e.message
        raise e if  !error.include? "Ambiguous match,"
       payee_data_length=error.split(" ").map(&:to_i).compact
       fail "Error..!! Payee list is empty for user - #{$current_user}"  if payee_data_length[3]==0
       return payee_data_length[3]
    end

	def cn_payee_selection(transfer_type)
		 show "selecting"
        wait_for_ajax
        $browser.find(:xpath, find_xpath("local_transfer_table_data")).text 
         rescue Exception => e 
         puts error= e.message
         puts "error #{error}"
        raise e if  !error.include? "Ambiguous match,"
       payee_data_length=error.split(" ").map(&:to_i).compact
       for acc_index in 1..payee_data_length[3]
        puts $browser.find(:xpath, "html/body//form//table[1]/tbody/tr[#{acc_index}]/td[2]").text
         if transfer_type.to_s.include? "IBFT"
          if $browser.find(:xpath, "html/body//form//table[1]/tbody/tr[#{acc_index}]/td[2]").text!="Standard Chartered Bank"
             @select_acc=$browser.find(:xpath, "html/body//form//table[1]/tbody/tr[#{acc_index}]/td[3]").text
             @row=acc_index
               break
          end
         elsif transfer_type.to_s.include? "TPFT"
          if $browser.find(:xpath, "html/body//form//table[1]/tbody/tr[#{acc_index}]/td[2]").text=="Standard Chartered Bank"
              @select_acc=$browser.find(:xpath, "html/body//form//table[1]/tbody/tr[#{acc_index}]/td[3]").text
              @row=acc_index
               break
          end
          end

       end
       puts "@select_acc :: #{@select_acc}"
        $browser.find(:xpath, "html/body//form//table//tbody/tr[td[contains(., '#{@select_acc}')]]").click
        payee_screen_data_capture(@row)
        wait_for_ajax
        sleep 5
        $browser.find(:xpath, find_xpath("next")).click
	end

  def delete_bene(type)
      wait_for_ajax
        $browser.find(:xpath, find_xpath("local_transfer_table_data")).text 
         rescue Exception => e 
         puts error= e.message
         puts "error #{error}"
        raise e if  !error.include? "Ambiguous match,"
       payee_data_length=error.split(" ").map(&:to_i).compact
       fail "Error..!! Payee list is empty for user - #{$current_user}"  if payee_data_length[3]==0
       rand_bene=$browser.find(:xpath, "html/body//form//table[1]/tbody/tr[#{rand(1..payee_data_length[3])}]/td[3]")
       @delete_bene=rand_bene.text
       rand_bene.click
  end

  def check_bene_deleted()
      wait_for_ajax
      $browser.find(:xpath, find_xpath("local_transfer_table_data")).text 
         rescue Exception => e 
         puts error= e.message
         puts "error #{error}"
        raise e if  !error.include? "Ambiguous match,"
       payee_data_length=error.split(" ").map(&:to_i).compact
       fail "Error..!! Payee list is empty for user - #{$current_user}"  if payee_data_length[3]==0
       for acc_index in 1...payee_data_length[3]
           @payee_list<<$browser.find(:xpath, "html/body//form//table[1]/tbody/tr[#{acc_index}]/td[1]").text
       end
       fail "Defect..!!!Deleted Payee is displaying in the list" if @payee_list.inculde?@delete_bene
  end


end