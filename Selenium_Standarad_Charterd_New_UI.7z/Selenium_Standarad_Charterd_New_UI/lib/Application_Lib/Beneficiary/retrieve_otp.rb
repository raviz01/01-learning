require 'HTTParty'
# require 'pry'
# require 'mechanize'


module RetrieveOtp
	def retrieve_otp(relId,beneAccNum)
		get_otp_list_of_customer = []	
=begin	
		if self.class.environment.csl_beneficiary_url.include?("http://10.20.234.24:9000")
			@env = 'http://10.20.234.24:9880'
		elsif self.class.environment.csl_beneficiary_url.include?("http://10.20.234.34:9000")
			@env = 'http://10.20.234.34:9880'
		elsif self.class.environment.csl_beneficiary_url.include?("http://10.20.234.42:9000")
			@evn = 'http://10.20.234.42:9880'
		else
	    	@env = 'http://10.20.234.21:9880'
		end
=end
		@env = "http://10.20.234.34:9880"
		number = beneAccNum[0..beneAccNum.length-5]
		encrypt = number.sub!(number,"*"*number.length)
		last_four_digits_of_account = beneAccNum.split(//).last(4).join("").to_s
		encrypted_bene_account = encrypt+last_four_digits_of_account

		10.times do
			@page = HTTParty.get("#{@env}/examples/OTPRetrieval.jsp")
			sleep(1)
		end
		sleep(2)
		begin
			parse_page = Nokogiri::HTML(@page)
			string = parse_page.search('.//body/pre').text
			@otp_list = string.split("\n")
			@otp_list.each do |otp|
				if otp.include? ("#{relId}") and  otp.include?(encrypted_bene_account)
					get_otp_list_of_customer << otp
				end
			end
			latest_customer_otp = get_otp_list_of_customer[-1]
			begin
				raw_otp_message = latest_customer_otp.split("#")
				otp_process_1	= raw_otp_message[2].split(".")
				otp_process_2 	= otp_process_1[0].split(",")
				otp				= otp_process_2[0].scan(/\d+/).join('')
			rescue Exception
				puts "*********Customer ID and Bene ID not matached with any string in OTP page*********"
			end
		rescue Exception => e
			puts "*********INVALID XPATH HAS DETECTED #{e}*********"
		end
	end
end
