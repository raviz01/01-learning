class Add_local_payee
  include Handler
  include WaitForAjax
  include RetrieveOtp
 

def initialize
  super
    @xpath = {
       "add_new_local_bene"                         => "btn-contacts-local",
       "paye_type_click"                            => "#ui-id-7-button",
       "payee_type_list"                            => "#ui-id-7-menu",
       "select_local_bank_payee"                    => "#ui-id-9",
       "payee_name"                                 => "#form-item-20",
       "payee_short_name"                           => "#form-item-26",
       "payee_country_click"                        => "#ui-id-16-button",
       "payee_country_list"                         => "#ui-id-16-menu",
       "paye_country"                               => "#ui-id-260",
       "payee_addrees1_field"                       => "#form-item-72-address1",
       "payee_addrees2_field"                       => "#form-item-72-address2",
       "payee_addrees3_field"                       => "#form-item-72-address3",
       "select_currency_button"                     => "#ui-id-21-button",
       "select_currency_list"                       => "#ui-id-21-menu",
       "bank_list_button"                           => "#ui-id-23-button",
       "bank_list_menu"                             => "#ui-id-23-menu",
       "email"                                      => "#form-item-28",
       "notification_button_radio"                  => "#form-item-30",
       "bene_submit_button"                         => "#form-item-33",
       "account_number"                             => "#form-item-22",
       "bene_submit_button_2"                       => "#form-item-545",
       "enter_otp"                                  => "input.form-control.otp-field.ng-valid.ng-valid-maxlength.ng-touched.ng-dirty.ng-valid-parse.ng-empty",
       "bene_submit_button_3"                       => "#form-item-567",
       "manage_payee_button"                        => "button.btn.btn-secondary.btn-block",
       "edit_payee_button"                          => ".//table[@id='table-contacts-local'][1]/tbody/tr[1]/td[4]/button[1]",
       "edit_address1"                             => "#form-item-84-address1",
       "edit_address2"                             => "#form-item-84-address2",
       "edit_address3"                             => "#form-item-84-address3",
       "edit_email"                                => "#form-item-94",
       "edit_short_name"                           => "#form-item-92",
       "edit_payee_country_click"                  => "#ui-id-6-button",
       "edit_submit_payee"                         => "#form-item-99",
       "edit_submit_payee_2"                       => "#form-item-435",
       "tpft_currency_menu"                        => "#ui-id-15-button"
     }
end

      def navigate_to_local_payee
        $browser.click_button(find_xpath("add_new_local_bene"))
      end

      def navigate_to_edit_payee
        sleep 8
        $browser.find(:xpath,find_xpath("edit_payee_button")).click
      end

      def select_payee_type(select_local_bank_payee)
        $browser.find("#{find_xpath("paye_type_click")}").click
        wait_for_ajax
        #$browser.find("#{find_xpath("select_local_bank_payee")}").click  
        $browser.find("li", :text => select_local_bank_payee).click
        sleep 10
      end

      def enter_payee_name(paye_name)
         wait_for_ajax
         $browser.find("#{find_xpath("payee_name")}").set(paye_name)
      end

      def select_payee_country(country)
        $browser.find("#{find_xpath("payee_country_click")}").click  
        wait_for_ajax
        $browser.find("li", :text => "#{country}").click
        #$browser.find("#{find_xpath("paye_country")}").click 
      end

      def select_edit_payee_country(country)
        $browser.find("#{find_xpath("edit_payee_country_click")}").click  
        wait_for_ajax
        $browser.find("li", :text => "#{country}").click
        #$browser.find("#{find_xpath("paye_country")}").click 
      end

      def enter_payee_short_name(paye_short_name)
        wait_for_ajax
        $browser.find("#{find_xpath("payee_short_name")}").set(paye_short_name)
      end

      def edit_payee_short_name(paye_short_name)
        wait_for_ajax
        $browser.find("#{find_xpath("edit_short_name")}").set(paye_short_name)
      end

      def enter_payee_email(email)
        $browser.find("#{find_xpath("email")}").set(email)
      end

      def edit_payee_email(email)
        $browser.find("#{find_xpath("edit_email")}").set(email)
      end

      def enter_address_fields(address1,address2,address3)
        $browser.find("#{find_xpath("payee_addrees1_field")}").set(address1)
        $browser.find("#{find_xpath("payee_addrees2_field")}").set(address2)
        $browser.find("#{find_xpath("payee_addrees3_field")}").set(address3)
      end

      def edit_address_fields(address1,address2,address3)
        $browser.find("#{find_xpath("edit_address1")}").set(address1)
        $browser.find("#{find_xpath("edit_address2")}").set(address2)
        $browser.find("#{find_xpath("edit_address3")}").set(address3)
      end

      def get_currency_list(currency)
        # list = $browser.find("#{find_xpath("select_currency_button")}").all('li')
        # currencies = Array.new        
        # list each do |list_item|
        #   currencies << list_item.text
        # end
        $browser.find("#{find_xpath("select_currency_button")}").click
        wait_for_ajax       
        $browser.find("li", :text => "#{currency}").click
      end

      def tpft_get_currency_list(currency)
        $browser.find("#{find_xpath("tpft_currency_menu")}").click
        wait_for_ajax       
        $browser.find("li", :text => "#{currency}").click
      end

      def select_bank_from_list
        $browser.find("#{find_xpath("bank_list_button")}").click
        wait_for_ajax
        $browser.find("li", :text => "Commercial Bank of Dubai").click
      end

      def check_radio_button
        $browser.find("#{find_xpath("notification_button_radio")}").click
      end

      def submit_payee
        $browser.find("#{find_xpath("bene_submit_button")}").click
        wait_for_ajax
      end

       def edit_submit_payee
        $browser.find("#{find_xpath("edit_submit_payee")}").click
        wait_for_ajax
      end

      def enter_account_number(ae_account_number)
        $browser.find("#{find_xpath("account_number")}").set(ae_account_number)
      end

      def verify_the_step
        text = $browser.find("div.form-step-counter.small.ng-binding.ng-scope").text
      end

      def submit_payee_2
        wait_for_ajax
        $browser.find("#{find_xpath("bene_submit_button_2")}").click
      end

      def edit_submit_payee_2
        wait_for_ajax
        $browser.find("#{find_xpath("edit_submit_payee_2")}").click
      end

       def submit_payee_3
        wait_for_ajax
        $browser.find("#{find_xpath("bene_submit_button_3")}").click
      end

      def enter_otp(otp)
        sleep 5
        $browser.find(:xpath,".//input").set(otp)
      end

      def click_on_manage_payee
        wait_for_ajax
        $browser.find("#{find_xpath("manage_payee_button")}").click
      end

      def payee_success_message
        wait_for_ajax
        $browser.find("div.message.ng-binding").text
      end

      def verify_payee_in_list(payee_short_name)
        sleep 5
        wait_for_ajax
        $browser.find('tr', text: "#{payee_short_name}").text        
      end

      def error_messages(required_index)
        wait_for_ajax
        error = $browser.all("div.ng-binding.ng-scope")
        error[required_index].text
      end

      def tpft_button2
        $browser.find("#form-item-104").click
      end

      def tpft_button3
        $browser.find("#form-item-123").click
      end

      def duplicate_bene_error
        wait_for_ajax
        $browser.find("div.message.ng-binding").text
      end
end


