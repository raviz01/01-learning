class Gl_Transfer
  include Handler
  include WaitForAjax
 

def initialize
  super
    @xpath = {
       
       #Add Beny    
       "List_of_GL_data"                          => "//div[@class='row row960 mainContainer']/table",
       "SG_GL_Data"                               => "//td[@class='tbl_content_top']",
       # "GL_Data"                                  => "//*[@id='productSummaryForm']/table/tbody/tr/td/table/tbody[2]",
       "Manage_global_accounts"                   => "//a[@class='extraDropdown']",
       "Link_GL_Account"                          => "//*[@id='printContent']//li[1]/a",
       "Delete_GL_Account"                        => "//*[@id='printContent']//li[3]/a",
       "Delete_GL_Account_Page"                   => "//*[@id='productSummaryForm']/table/tbody/tr/td/div[1]/div[1]",       
       "Select_country_drop_down"                 => "//select[@id='commonUserVO.country']",       
       "HK_country_AE"                            => "//*[@id='commonUserVO.country']/option[8]" ,  
       "HK_country_SG"                            => "//*[@id='commonUserVO.country']/option[7]" ,       
       "username"                                 => "commonUserVO.userId",
       "password"                                 => "commonUserVO.password" , 
       "next_button"                              => "//input[@type='submit']",
       "error_message"                            => "//div[@class='error-container__message']",
       "check_box"                                => "termsAcceptanceFlag1",
       "success_mess"                             => "//tr[@class='tbl_instructions success sc ']",      
       "confirm_button"                           => "//input[@value='Confirm']",
       "select_HK"                                => "//*[@id='productSummaryVO.productSummaryList0.selected1']",
       "confirm_button"                           => "//input[@value='Confirm']",
       "delete_confirm_message"                   => "//tr[@class='tbl_instructions success']"

}
end

      def add_GL_account_number(beny_number, browser)
        account_numbers = []
          puts "beny_number:: #{beny_number}"               
          browser.find(:xpath, find_xpath("Manage_global_accounts")).click
          wait_for_ajax 
          browser.find(:xpath, find_xpath("Link_GL_Account")).click     
          wait_for_ajax  
          browser.find(:xpath, find_xpath("Select_country_drop_down")).click      
          wait_for_ajax            
          browser.find(:xpath, find_xpath("HK_country_AE")).click  if $framework["region"] == "AE"        
          wait_for_ajax   
          browser.find(:xpath, find_xpath("HK_country_SG")).click  if $framework["region"] == "SG"        
          wait_for_ajax         
          fail"!!!Application Error!!! Service is down" if browser.has_xpath?(find_xpath("error_message"))
          wait_for_ajax           
          # browser.fill_in find_xpath("username"), :with => "#{$user[$framework["region"]][$current_user_instance]["gl_account_number"]}"
          browser.fill_in find_xpath("username"), :with => "#{beny_number}"
          wait_for_ajax           
          browser.fill_in find_xpath("password"), :with => "#{$user[$framework["region"]][$current_user_instance]["gl_password"]}"
          wait_for_ajax 
          browser.find(:id, find_xpath("check_box")).click      
          wait_for_ajax 
          browser.find(:xpath, find_xpath("next_button")).click      
          wait_for_ajax 
          fail"!!!Test Data Issue!!! Incorrect Password" if browser.has_xpath?(find_xpath("error_message"))
          wait_for_ajax   
          puts "!!!success!!! User able to add GL account and displaying as !!!#{browser.find(:xpath, find_xpath("success_mess")).text}!!!" if browser.has_xpath?(find_xpath("success_mess"))
          wait_for_ajax                      
      end  

      def delete_GL_account_number(browser)
         puts "#" * 50
          browser.find(:xpath, find_xpath("Manage_global_accounts")).click
          wait_for_ajax 
          browser.find(:xpath, find_xpath("Delete_GL_Account")).click     
          wait_for_ajax  
          delete_GL_account_page = browser.find(:xpath, find_xpath("Delete_GL_Account_Page")).text 
          puts "!!!Successfully!!! Navigated to Delete Global Accounts page" if delete_GL_account_page.include?('Delete Global Accounts')                                                                 
          wait_for_ajax            
          # overall_test_data = (browser.find(:xpath, find_xpath("SG_GL_Data")).text).split(" ")          
          # puts "SG_Data:: #{overall_test_data}"                  
          browser.find(:xpath, find_xpath("select_HK")).click      
          wait_for_ajax 
          browser.find(:xpath, find_xpath("next_button")).click      
          wait_for_ajax 
          browser.find(:xpath, find_xpath("confirm_button")).click      
          wait_for_ajax  
          puts "!!!Successfully!!! Deleted Selected Global Account" if (browser.find(:xpath, find_xpath("delete_confirm_message")).text).include? "THE ACCOUNT HAS BEEN DELETED SUCCESSFULLY"             
      end  
    

end


