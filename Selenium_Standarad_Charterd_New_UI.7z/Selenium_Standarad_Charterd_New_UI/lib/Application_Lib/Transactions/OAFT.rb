class Oaft
  include Handler
  include WaitForAjax
  include PomLocalTransfer
 

def initialize
  super
  $oaft_txn_amount=1.00
    @xpath = {
       

       #csl OAFT screen     
       "oaft_to_account"                   => "//span[@class='select-menu-toggle-icon']",
       "select_oaft_to_account"            => "//*[@id='form-item-24']/div/ul/li[1]/ul/li[1]",               
       "to_account_list"                   => "//ul[@class='select-menu-menu']",       
       "oaft_from_account"                 => "//span[@class='ui-selectmenu-button ui-selectmenu-button-closed ui-corner-all ui-button ui-widget']",                                                                           
       "from_account_list"                 => "//ul[@class='ui-menu ui-corner-bottom ui-widget ui-widget-content']" ,
       "select_oaft_from_account"          => "ui-id-15", 
       "currency_value"                    => "transferAmount-amount",
       "description_entery_field"          => "description",
       "next_button"                       => "//button[@type='submit']",
       "accept_terms"                      => "//input[@type='checkbox']" ,     
       "finish_close_button"               => "//button[@class='btn btn-primary btn-block']",
       "error_message"                     => "//div[@class='message ng-binding']",
       "reference_number"                  => "//div[@id='main']/div/div[2]/div[2]/div/div[1]/div[2]",
       "account_to_be_transfered"          => "//div[@id='main']/div/div[2]/div[2]/div/div[2]/div[2]" ,
       "account_to_be_transfered_from"     => "//div[@id='main']/div/div[2]/div[2]/div/div[3]/div[2]", 
       "currency_amount"                   => "//div[@id='main']/div/div[2]/div[2]/div/div[4]/div[2]" ,
       "make_another_transfer"             => "//button[@class='btn btn-secondary btn-block']"  ,
       "exchange_rate_value"               => "//div[@class='exchange-rate-rate ng-binding']",
       "exchange_rate_amount"              => "//div[@class='exchange-rate-amount ng-binding']",
       "back_button"                       => "//button[@class='btn btn-default btn-block form-item form-item-back form-type-back']" ,
       "Dashboard"                         => "//div[@id='dashboard']" ,
       "get_from_account_selected"         => "//*[@class='select-menu-label ng-binding']" ,

       ##### Global Accounts #####
       "global_to_account_list"            => "//ul[@class='ui-menu ui-corner-bottom ui-widget ui-widget-content']" ,
       "global_from_account_list"          => "//div[@class='ui-selectmenu-menu ui-front ui-selectmenu-open']",
       "bank_chargers"                     => "//span[@class='amount ng-binding']",
       "to_be_paid"                        => "//div[@class='row']//div[@class='col-sm-8']//span[@class='ui-selectmenu-button ui-selectmenu-button-closed ui-corner-all ui-button ui-widget']"  ,
       "select_only_reciept"               => "//div[@class='ui-selectmenu-menu ui-front ui-selectmenu-open']//li[3]",
       "select_country"                    => "//div[@class='form-group form-item form-item-country-code form-type-select form-item form-item-country-code form-type-select']//span[@class='ui-selectmenu-button ui-selectmenu-button-closed ui-corner-all ui-button ui-widget']",
       "select_India"                      => "//div[@class='ui-menu-item-wrapper'][contains(text(),'Indian')]" ,
       "select_state"                      => "//*[@id='ui-id-25-menu']/li[103]",
       "Address_field_one"                 => "address-address1",
       "Address_field_two"                 => "address-address2",
       "Address_field_three"               => "address-address3",
       "select_outside"                    => "//div[@class='currency-code form-type-select']",     
    }

end

def oaft_local_transaction(browser, currency_type)
    puts "#" * 50  
    puts "Transaction_Type:: #{currency_type}"  
    wait_for_ajax    
    puts "To Account Drown down is displaying" if browser.has_xpath?(find_xpath("oaft_to_account")) 
    sleep 12    
    browser.find(:xpath, find_xpath("oaft_to_account")).click
    wait_for_ajax    
    browser.find(:xpath, find_xpath("select_oaft_to_account")).click if currency_type == 'Zero' 
    wait_for_ajax      
  if currency_type != 'Zero' 
    @to_act_pos=1
    to_account_data = browser.find(:xpath, find_xpath("to_account_list")).text     
    to_account_data_list = to_account_data.split(" ")   
    to_currency_value = []  
    puts "to_account_data_list:: #{to_account_data_list}"   
  for index in 0...to_account_data_list.length   
     if to_account_data_list[index].include? '.'                        
        if currency_type == 'cross' && to_account_data_list[index-1] != "#{$framework['region']+'D'}" && to_account_data_list[index] != "0.00" 
            to_currency_value << to_account_data_list[index-1] if to_account_data_list[index-1] != "#{$framework['region']+'D'}" && to_account_data_list[index] != "0.00"                    
            to_account_value = to_account_data_list[index]
            break if to_account_data_list[index-1] != "#{$framework['region']+'D'}" && to_account_data_list[index] != "0.00"                                
        elsif currency_type == 'same' && to_account_data_list[index-1] == "#{$framework['region']+'D'}" && to_account_data_list[index] != "0.00"
             to_currency_value << to_account_data_list[index-1] if to_account_data_list[index-1] == "#{$framework['region']+'D'}" && to_account_data_list[index] != "0.00"               
             to_account_value = to_account_data_list[index]
            break if to_account_data_list[index-1] == "#{$framework['region']+'D'}" && to_account_data_list[index] != "0.00"                             
        end 
       @to_act_pos=@to_act_pos+1                        
    end   
  end 
  puts "to_currency_type:: #{to_currency_value}" 
  browser.find(:xpath, "//div[@class='ng-binding ng-scope'][contains(text(),'#{to_account_value}')]").click
  # Get To Account Details Info
  $get_txn_details_ref << browser.find(:xpath, find_xpath("get_from_account_selected")).text      
  end    
     ##################From Account List###################
    browser.find(:xpath, find_xpath("oaft_from_account")).click
    #Get From Accounts into an Array
    @local_scb_accounts=browser.find(:css,'div.ui-selectmenu-menu.ui-front.ui-selectmenu-open').all('li').collect(&:text)
    p "From Accounts Available as ::: #{@local_scb_accounts }" 
     wait_for_ajax    
    from_account_data = browser.find(:xpath, find_xpath("from_account_list")).text  
    from_account_data_list = from_account_data.split(" ")     
    currency_value = []
   @act_pos=1
  for index in 0...from_account_data_list.length   
     if from_account_data_list[index].include? '.' 
     case currency_type 
     when "cross"                      
        if from_account_data_list[index-1] != "#{to_currency_value}" && from_account_data_list[index] != "0.00" 
            currency_value << from_account_data_list[index-1] if from_account_data_list[index-1] != "#{to_currency_value}" && from_account_data_list[index] != "0.00"                    
            break
        end    
     when "same"
        if from_account_data_list[index-1] == "#{$framework['region']+'D'}" && from_account_data_list[index] != "0.00"
             currency_value << from_account_data_list[index-1] if from_account_data_list[index-1] == "#{$framework['region']+'D'}" && from_account_data_list[index] != "0.00"               
            break       
       end 
     when "Zero"  
      if from_account_data_list[index] == "0.00"     
             currency_value << from_account_data_list[index-1] if from_account_data_list[index] == "0.00"
             test_data = from_account_data_list[index]               
             break          
       end 
      end 
       @act_pos=@act_pos+1                        
    end   
  end
    p "@act_pos ::: #{@act_pos}"   
    fail "!!!Data Issue!!! Zero funds account are not present under from account data" if currency_type == 'Zero' && test_data.nil?
    puts "from_currency_type:: #{currency_value}"       
    browser.find(:xpath, "//div[@class='ui-selectmenu-menu ui-front ui-selectmenu-open']//li[#{@act_pos}+1]").click
    $get_txn_details_ref << @local_scb_accounts[@act_pos] # Get From Account Value Based on Acct Position
    wait_for_ajax   
    browser.fill_in find_xpath("currency_value"), :with => $oaft_txn_amount
    $get_txn_details_ref << to_currency_value.join("")+" "+$oaft_txn_amount.to_s # Get OAFT Txn Amount
     wait_for_ajax   
    browser.fill_in find_xpath("description_entery_field"), :with => $payment_txn_ref
    $get_txn_details_ref << $payment_txn_ref
     wait_for_ajax 
     sleep 10
    @exchange_rate_amount = browser.find(:xpath, find_xpath("exchange_rate_amount")).text if currency_type == 'cross'
    @exchange_rate_value = browser.find(:xpath, find_xpath("exchange_rate_value")).text if currency_type == 'cross' 
    puts "!!!Exchange Amount:- #{browser.find(:xpath, find_xpath("exchange_rate_amount")).text} & Exchange Values:- #{browser.find(:xpath, find_xpath("exchange_rate_value")).text} are displaying as expected!!!" if browser.has_xpath?(find_xpath("exchange_rate_value"))

    @exchange_rate_amount = @exchange_rate_amount.split(/\= /)
    @exchange_rate_amount = @exchange_rate_amount[1]

    @exchange_rate_value = @exchange_rate_value.split(/\= /)
    @exchange_rate_value = @exchange_rate_value[1]


    $get_txn_details_ref <<  @exchange_rate_amount+" (Indicative Exchange Rate = "+@exchange_rate_value+")"

    fail "!!! Defect !!! Exchange rates are bot displaying for cross currency transaction!!!" if currency_type == 'cross' && exchange_rate_amount.empty? && exchange_rate_value.empty?
    oaft_post_txn_amount_validation($get_txn_details_ref) # Get the Txn Details for Post Txn Amount Validation

    browser.find(:xpath, find_xpath("next_button")).click 
     wait_for_ajax   
        if currency_type == 'Zero'   # When the balance in Zero    
          error_message_text = browser.find(:xpath, find_xpath("error_message")).text    
          fail "!!!Defect!!! Error Message displaying as '#{error_message_text}' !!!" if error_message_text != "Please ensure you have sufficient balance to perform the transaction"
          puts "!!!Error Message!!! Displaying as expected #{error_message_text}" 
          puts "#" * 50
          else
          review_the_transaction # Review the Transactions and Accepts Terms & Condition if applicable
          #   wait_for_ajax
          # conformation_of_transaction
          # browser.find(:xpath, find_xpath("next_button")).click 
          #  wait_for_ajax 
          # # browser.find(:xpath, find_xpath("accept_terms")).click  
          # #  wait_for_ajax  
          # browser.find(:xpath, find_xpath("next_button")).click   
          # wait_for_ajax      
        end  
  end  

  def oaft_global_transaction(browser, transaction_Type)
      puts "#" * 50       
      wait_for_ajax          
      puts "To Account Drown down is displaying" if browser.has_xpath?(find_xpath("oaft_to_account")) 
      sleep 12           
      browser.find(:xpath, find_xpath("oaft_to_account")).click
      wait_for_ajax         
      to_account_data = browser.find(:xpath, find_xpath("to_account_list")).text       
      to_currency_value = []; local_difference=[]; 
          for global_value in 0...to_account_data.length            
                if to_account_data[global_value]== 'G'
                  global_value_data = global_value if to_account_data[global_value+1] == 'l'
                  break if to_account_data[global_value+2]== 'o'                                
                end
          end                
       to_account_data_list = to_account_data[global_value_data..to_account_data.length].split(" ")              
         @to_act_pos=1                  
        for index in 0...to_account_data_list.length  
          if to_account_data_list[index].include? '.'                                                      
                  if transaction_Type == 'cross' && to_account_data_list[index-1] != "#{$framework['region']+'D'}" && to_account_data_list[index] != "0.00" 
                      to_currency_value << to_account_data_list[index-1] if to_account_data_list[index-1] != "#{$framework['region']+'D'}" && to_account_data_list[index] != "0.00"                                          
                      to_account_value = to_account_data_list[index]
                      break if to_account_data_list[index-1] != "#{$framework['region']+'D'}"               
                  elsif transaction_Type == 'same' && to_account_data_list[index-1] == "#{$framework['region']+'D'}" && to_account_data_list[index] != "0.00"
                       to_currency_value << to_account_data_list[index-1] if to_account_data_list[index-1] == "#{$framework['region']+'D'}" && to_account_data_list[index] != "0.00"                                                                     
                       to_account_value = to_account_data_list[index]
                       break if to_account_data_list[index-1] == "#{$framework['region']+'D'}"                     
                  end  
                   wait_for_ajax  
          @to_act_pos=@to_act_pos+1                                                                                                                 
         end           
      end      
      puts "Transaction_Type:: #{transaction_Type}"
      puts "to_currency_type:: #{to_currency_value}"
      puts "To_account_funds:: #{to_account_value}"
      fail "!!!Test Data Issue!!! There is no #{transaction_Type} currency data is present" if to_currency_value.empty?         
      browser.find(:xpath, "//div[@class='ng-binding ng-scope'][contains(text(),'#{to_account_value}')]").click        
       ##################From Account List###################
       wait_for_ajax 
       sleep 8 
      browser.find(:xpath, find_xpath("oaft_from_account")).click  
       wait_for_ajax    
      from_account_data = browser.find(:xpath, find_xpath("global_from_account_list")).text  
      from_account_data_list = from_account_data.split(" ")  
      currency_value = []      
     @act_pos=1
    for index in 0...from_account_data_list.length   
       if from_account_data_list[index].include? '.' 
       case transaction_Type 
       when "cross"                      
          if from_account_data_list[index-1] != "#{to_currency_value}" && from_account_data_list[index] != "0.00" 
              currency_value << from_account_data_list[index-1] if from_account_data_list[index-1] != "#{$framework['region']+'D'}" && from_account_data_list[index] != "0.00"                    
              break
          end    
       when "same"
          if from_account_data_list[index-1] == "#{$framework['region']+'D'}" && from_account_data_list[index] != "0.00"
               currency_value << from_account_data_list[index-1] if from_account_data_list[index-1] == "#{$framework['region']+'D'}" && from_account_data_list[index] != "0.00"                               
              break       
         end 
       when "Zero"  
        if from_account_data_list[index] == "0.00"     
               currency_value << from_account_data_list[index-1] if from_account_data_list[index] == "0.00"               
              break       
         end 
        end 
         @act_pos=@act_pos+1                        
      end   
    end        
     browser.find(:xpath, "//div[@class='ui-selectmenu-menu ui-front ui-selectmenu-open']//li[#{@act_pos}+1]").click    
     wait_for_ajax    
     browser.fill_in find_xpath("currency_value"), :with => 1
     wait_for_ajax       
      browser.find(:xpath, find_xpath("select_outside")).click
     wait_for_ajax 
      sleep 5 
     bank_chargers = browser.find(:xpath, find_xpath("bank_chargers")).text if transaction_Type == 'cross'
     fail "!!!Defect!!! Bank chargers are not displaying" if bank_chargers == '' && transaction_Type == 'cross'
     puts "bank_chargers:: #{bank_chargers}"
      wait_for_ajax            
      exchange_rate_amount = browser.find(:xpath, find_xpath("exchange_rate_amount")).text if transaction_Type == 'cross'
      exchange_rate_value = browser.find(:xpath, find_xpath("exchange_rate_value")).text if transaction_Type == 'cross' 
      puts "!!!Exchange Amount:- #{browser.find(:xpath, find_xpath("exchange_rate_amount")).text} & Exchange Values:- #{browser.find(:xpath, find_xpath("exchange_rate_value")).text} are displaying as expected!!!" if browser.has_xpath?(find_xpath("exchange_rate_value")) 
      fail "!!! Defect !!! Exchange rates are bot displaying for cross currency transaction!!!" if transaction_Type == 'cross' && exchange_rate_amount.empty? && exchange_rate_value.empty?
     wait_for_ajax
     browser.find(:xpath, find_xpath("select_outside")).click  
     wait_for_ajax          
     browser.find(:xpath, find_xpath("to_be_paid")).click if transaction_Type != 'cross'
     wait_for_ajax    
     browser.find(:xpath, find_xpath("select_only_reciept")).click  if transaction_Type != 'cross'
     wait_for_ajax  
     browser.has_xpath?(find_xpath("next_button"))       
     browser.find(:xpath, find_xpath("select_country")).click if browser.has_xpath?(find_xpath("next_button")) == false 
     wait_for_ajax      
     browser.find(:xpath, find_xpath("select_India")).click if browser.has_xpath?(find_xpath("next_button"))  == false    
     wait_for_ajax 
     browser.fill_in find_xpath("Address_field_one"), :with => "Plot No: 157, Road No:5"
     wait_for_ajax  
     browser.fill_in find_xpath("Address_field_two"), :with => "Deen Dayal Nagar, Neredmet"
     wait_for_ajax  
     browser.fill_in find_xpath("Address_field_three"), :with => "Hyderabad"
     wait_for_ajax
     browser.fill_in find_xpath("description_entery_field"), :with => "Selenium UI Automation Testing"
     wait_for_ajax      
    browser.find(:xpath, find_xpath("next_button")).click 
    sleep 24
     wait_for_ajax       
        if transaction_Type == 'Zero'       
            error_message_text = browser.find(:xpath, find_xpath("error_message")).text    
            puts "!!!Error_Message!!! Displaying successfully!!!" if error_message_text.include?("Please ensure you have sufficient balance to perform the transaction")
            puts "#" * 50
        else                    
            browser.find(:xpath, find_xpath("accept_terms")).click  
            wait_for_ajax  
            browser.find(:xpath, find_xpath("next_button")).click   
            wait_for_ajax         
        end 
       otp = get_otp_and_fill_cls('Between Own Accounts', '1')
       puts "otp:: #{otp}"
end

def back_button(browser)
      sleep 10           
      browser.find(:xpath, find_xpath("oaft_to_account")).click
      wait_for_ajax         
      to_account_data = browser.find(:xpath, find_xpath("to_account_list")).text       
      to_currency_value = []; local_difference=[]; 
          for global_value in 0...to_account_data.length            
                if to_account_data[global_value]== 'G'
                  global_value_data = global_value if to_account_data[global_value+1] == 'l'
                  break if to_account_data[global_value+2]== 'o'                                
                end
          end                
       to_account_data_list = to_account_data[global_value_data..to_account_data.length].split(" ")              
         @to_act_pos=1                 
        for index in 0...to_account_data_list.length  
          if to_account_data_list[index].include? '.'                                                      
                  if  to_account_data_list[index-1] == "#{$framework['region']+'D'}" && to_account_data_list[index] != "0.00" 
                      to_currency_value << to_account_data_list[index-1] if to_account_data_list[index-1] == "#{$framework['region']+'D'}" && to_account_data_list[index] != "0.00"                                          
                      to_account_value = to_account_data_list[index]
                      break if to_account_data_list[index-1] == "#{$framework['region']+'D'}"                                                    
                  end  
                   wait_for_ajax  
          @to_act_pos=@to_act_pos+1                                                                                                                 
         end           
      end            
      puts "to_currency_type:: #{to_currency_value}"
      puts "To_account_funds:: #{to_account_value}"      
      browser.find(:xpath, "//div[@class='ng-binding ng-scope'][contains(text(),'#{to_account_value}')]").click        
       ##################From Account List###################
      browser.find(:xpath, find_xpath("oaft_from_account")).click  
       wait_for_ajax    
      from_account_data = browser.find(:xpath, find_xpath("global_from_account_list")).text  
      from_account_data_list = from_account_data.split(" ")  
      currency_value = []      
     @act_pos=1
    for index in 0...from_account_data_list.length   
       if from_account_data_list[index].include? '.'                   
          if from_account_data_list[index-1] == "#{to_currency_value}" && from_account_data_list[index] != "0.00" 
              currency_value << from_account_data_list[index-1] if from_account_data_list[index-1] == "#{$framework['region']+'D'}" && from_account_data_list[index] != "0.00"                    
              break if from_account_data_list[index-1] == "#{$framework['region']+'D'}" && from_account_data_list[index] != "0.00"
          end           
         @act_pos=@act_pos+1                        
      end   
    end        
     browser.find(:xpath, "//div[@class='ui-selectmenu-menu ui-front ui-selectmenu-open']//li[#{@act_pos}]").click    
     wait_for_ajax    
     browser.fill_in find_xpath("currency_value"), :with => 1
     wait_for_ajax       
      browser.find(:xpath, find_xpath("select_outside")).click
     wait_for_ajax 
      sleep 5          
      wait_for_ajax                  
     browser.find(:xpath, find_xpath("select_outside")).click  
     wait_for_ajax          
     browser.find(:xpath, find_xpath("to_be_paid")).click if transaction_Type != 'cross'
     wait_for_ajax    
     browser.find(:xpath, find_xpath("select_only_reciept")).click  if transaction_Type != 'cross'
     wait_for_ajax      
     browser.fill_in find_xpath("Address_field_one"), :with => "Plot No: 157, Road No:5"
     wait_for_ajax  
     browser.fill_in find_xpath("Address_field_two"), :with => "Deen Dayal Nagar, Neredmet"
     wait_for_ajax  
     browser.fill_in find_xpath("Address_field_three"), :with => "Hyderabad"
     wait_for_ajax     
     browser.find(:xpath, find_xpath("select_country")).click if browser.has_xpath?(find_xpath("next_button")) == false
     wait_for_ajax      
     browser.find(:xpath, find_xpath("select_India")).click if browser.has_xpath?(find_xpath("next_button")) == false
     wait_for_ajax 
     browser.fill_in find_xpath("description_entery_field"), :with => "Selenium UI Automation Testing"
     wait_for_ajax      
     browser.find(:xpath, find_xpath("next_button")).click 
     wait_for_ajax
     sleep 5 
     puts "!!!Back Button is Displaying!!!" if browser.has_xpath?(find_xpath("back_button")) 
     browser.find(:xpath, find_xpath("back_button")).click     
end

end


