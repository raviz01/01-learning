class InftLib
include Handler
include WaitForAjax
include PomLocalTransfer

def inft_xbt_transfer(currency_type, transfer_type)
  @payee_data=[]
  sleep 10
   trans_type=currency_type.split("-")
    wait_for_ajax
    sleep 5
     # bene=transfer_type+" "+trans_type[1]
    @bene=transfer_type+" Valid "+trans_type[1]

    # Get the Payee Name based on the Row Number
    table=$browser.find(:css, find_xpath("bene_tabel"))
    row_count=(table.all(:css,'tr').size)-1
    raise "International Payee records are not available to proceed further !! " if row_count.eql?(0)

    for i_count in 1..row_count do
      @is_valid=0
      @payee_name=$browser.find(:xpath,"//*[@id='form-item-20']/table[1]/tbody/tr[#{i_count}]/td[1]").text
        if @payee_name.eql? @bene
           @is_valid=1
           payee_screen_data_capture(i_count)
           $browser.find(:xpath,"//*[@id='form-item-20']/table[1]/tbody/tr[#{i_count}]/td[1]").click
           break
        end
    end
        fail "Error..!! There is specific PAYEE test data for Automation..
       Please Do Create PAYEE with Payee Name '#{@bene}' for #{$framework["region"]} 
       " if (@is_valid!=1)


    # puts $browser.has_xpath?("html/body//form//table//tbody/tr[td[contains(., '#{@bene}')]]")
    # fail "Error..!! There is specific PAYEE test data for Automation..
    #    Please Do Create PAYEE with Payee Name '#{@bene}' for #{$framework["region"]} 
    #    "if ! $browser.has_xpath?("html/body//form//table//tbody/tr[td[contains(., '#{@bene}')]]")
    #     $browser.find(:xpath, "html/body//form//table//tbody/tr[td[contains(., '#{@bene}')]]").click
        # payee_bene=#{bene}.to_s
        # payee_screen_data_capture(payee_bene)
        wait_for_ajax
        sleep 10
        $browser.find(:xpath, find_xpath("next")).click
        wait_for_ajax
        from_screen_data_capture
        from_screen_data_validation
        $browser.find(:xpath, find_xpath("select_Account")).click
          p drop_down_data= $browser.find(:xpath, find_xpath("drop_down_box")).text
          to_account_data=drop_down_data.split(" ")
          currecy_type=[]; all_amount=[];same_curreny_amount=[]
             to_account_data.each_with_index do |e,i|
              if e.include? "."
                all_amount<<e
                 currecy_type<<to_account_data[i-1] 
                 same_curreny_amount<<e if trans_type[0]==to_account_data[i-1]
              end
            end
            fail "Error..!! #{trans_type[1]} test data is not available in from account" if same_curreny_amount==[]
            puts "same_curreny_amount #{same_curreny_amount}"
             max_amount_index=all_amount.index same_curreny_amount.max
             puts "max_amount_index  #{max_amount_index}"
             max_amount=5
            all_amount[max_amount_index.to_i].delete! ","
            max_amount=all_amount[max_amount_index.to_i].to_i if all_amount[max_amount_index.to_i].to_i<5
            $browser.find(:xpath, "//*[@class='ui-menu ui-corner-bottom ui-widget ui-widget-content']/li[#{max_amount_index.to_i+2}]").click 
           enter_amount(max_amount)
           #p $payment_amount
           # Return the $payment_amount value from enter_amount method.Get Payment Amount
           $get_txn_details_ref << (trans_type[1]+" "+$payment_amount) # Get Currency and Amount Reference

           $browser.fill_in find_xpath("description_entery_field"), :with => $payment_txn_ref # Set Payment Reference
           $get_txn_details_ref << $payment_txn_ref # Get Payment Reference

           wait_for_ajax
           stop "Defect..!! Bank Charges have not been displayed" if !$browser.has_xpath?(find_xpath("bank_charges"))

            wait_for_ajax  
            $browser.find(:xpath, find_xpath("bank_charges_paid_by_selection")).click 

            wait_for_ajax
            $browser.find(:xpath, "//div[@class='ui-menu-item-wrapper'][contains(., 'Only the recipient')]").click

            # Get the Bank Charges
            sleep 8
            @bank_charges=$browser.find(:xpath, find_xpath("bank_charges")).text

            # If the Bank Charges are 0.00, then To Be Paid By Field should not be applicable
             if @bank_charges.include? ("0.00")
              @concat_charges=(@bank_charges+" (Not Applicable)") # Concat the Charge Amount and Paid By
             else
            # Get To Be Paid By Field
              @bank_charges_paid_by=$browser.find(:xpath, find_xpath("bank_charges_paid_by_selection")).text
              wait_for_ajax
              @concat_charges=(@bank_charges+" (To be paid by "+@bank_charges_paid_by+")") # Concat the Charge Amount and Paid By
            end

              $get_txn_details_ref << @concat_charges

             if trans_type[0]!=trans_type[1]
              sleep 5
               stop "Defect..!! exchanage rates have not been displayed for #{currency_type}" if !$browser.has_xpath?(find_xpath("exchange_rate_value"))
                  @exchange_rate_value=$browser.find(:xpath, find_xpath("exchange_rate_value")).text
               stop "Defect..!! exchange rate amount have not been displayed for  #{currency_type}" if !$browser.has_xpath?(find_xpath("exchange_rate_amount"))
                  @exchange_rate_amount=$browser.find(:xpath, find_xpath("exchange_rate_amount")).text

                  @exchange_rate_value = @exchange_rate_value.split(/\= /)
                  @exchange_rate_value = @exchange_rate_value[1]
      
                  @exchange_rate_amount = @exchange_rate_amount.split(/\= /)
                  @exchange_rate_amount = @exchange_rate_amount[1]
                  
                  # Get Exchange Rate Amount and Value
                  $get_txn_details_ref <<  @exchange_rate_amount+" (Indicative Exchange Rate = "+@exchange_rate_value+")"
                  sleep 5
              end
              wait_for_ajax
            
            # Select Purpose of Payment
             if trans_type[1] == "INR"
              $browser.find(:xpath,find_xpath("click_pop_dropdown")).click
              @pop_codes=$browser.find(:xpath,find_xpath("collect_pop_values")).all('li').collect(&:text)
              #@pop_codes=@pop_codes(1..@pop_codes.length)
              @pop_index=rand (1..@pop_codes.length)
              $browser.find(:xpath,"//div[@class='ui-menu-item-wrapper'][contains(text(),'#{@pop_codes[@pop_index]}')]").click
              $get_txn_details_ref << @pop_codes[@pop_index] 
              end

            wait_for_ajax

            # @exchange_rate_amount = @exchange_rate_amount.split(/\= /)
            # @exchange_rate_amount = @exchange_rate_amount[1]

            # @exchange_rate_value = @exchange_rate_value.split(/\= /)
            # @exchange_rate_value = @exchange_rate_value[1]
            # # Get Exchange Rate Amount and Value
            # $get_txn_details_ref <<  @exchange_rate_amount+" (Indicative Exchange Rate = "+@exchange_rate_value+")"
            # sleep 5
            post_txn_amount_validation($get_txn_details_ref) # Call Post Txn Amount Validation
              
            $browser.find(:xpath, find_xpath("next")).click
            wait_for_ajax
            sleep 20
            review_the_transaction # Review the Transaction
            sleep 15
            wait_for_ajax
            conformation_of_transaction # Confirm the Txn and Capture the Txn Referencce Number
            puts "*** Successfully Completed #{transfer_type} Trasaction with #{currency_type} ***"        
end

end