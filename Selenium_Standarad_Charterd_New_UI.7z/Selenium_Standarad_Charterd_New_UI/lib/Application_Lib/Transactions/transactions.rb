class TransactionLibrary
    include Handler
    include WaitForAjax
    include PomLocalTransfer
    

     def payee_selection(transfer_type)
        show "selecting"
        wait_for_ajax
        table=$browser.find(:css,find_xpath("bene_tabel"))
        payee_data_length=(table.all(:css,'tr').size)-1
       for acc_index in 1..payee_data_length
         if transfer_type.to_s.include? "IBFT"
          if $browser.find(:xpath, "html/body//form//table[1]/tbody/tr[#{acc_index}]/td[2]").text!="Standard Chartered Bank"
             @select_acc=$browser.find(:xpath, "html/body//form//table[1]/tbody/tr[#{acc_index}]/td[3]").text
             @row=acc_index
               break
          end
         elsif transfer_type.to_s.include? "TPFT"
          if $browser.find(:xpath, "html/body//form//table[1]/tbody/tr[#{acc_index}]/td[2]").text=="Standard Chartered Bank"
              @select_acc=$browser.find(:xpath, "html/body//form//table[1]/tbody/tr[#{acc_index}]/td[3]").text
              p "TPFT Account ::: #{@select_acc}"
              @row=acc_index
               break
          end
          end

       end
       puts "#"*100
       puts "@select_acc :: #{@select_acc}"
        $browser.find(:xpath, "html/body//form//table//tbody/tr[td[contains(., '#{@select_acc}')]]").click
        payee_screen_data_capture(@row)
        wait_for_ajax
        sleep 15
        $browser.find(:xpath, find_xpath("next")).click
     end
     
    

     def from_acc_selection(transfer_type)
       @payee_data=[]
       $get_txn_details_ref=[]       
       wait_for_ajax
       from_screen_data_capture #Capture Data from Local Payee List
       from_screen_data_validation #Validate captured data in Local Txn Page
       $browser.find(:xpath, find_xpath("select_Account")).click

        drop_down_data= $browser.find(:xpath, find_xpath("drop_down_box")).text
        @amount =[]; @all_amount=[]
          for i in 0..drop_down_data.split.length
             puts @all_amount<< drop_down_data.split[i+2] if drop_down_data.split[i]== "-"
            if (transfer_type.include?"Same") && drop_down_data.split[i+1]==$framework["currency_type"]
              @amount<< drop_down_data.split[i+2] if drop_down_data.split[i]== "-"
            elsif (transfer_type.include? "Cross") && drop_down_data.split[i+1]!= $framework["currency_type"]
               @amount<< drop_down_data.split[i+2] if drop_down_data.split[i]== "-"
            end
          end
           max_amount=@all_amount.index @amount.max
           @from_account_number=$browser.find(:xpath, "//*[@class='ui-menu ui-corner-bottom ui-widget ui-widget-content']/li[#{max_amount.to_i+2}]").text
           $get_txn_details_ref << @from_account_number
           $browser.find(:xpath, "//*[@class='ui-menu ui-corner-bottom ui-widget ui-widget-content']/li[#{max_amount.to_i+2}]").click 
           amount=rand(0.5..100) #Generate Random Amount
           amount=amount.to_s[0..4] #Round Off to Valid Amount
           @entered_amount=amount
          $browser.fill_in find_xpath("amount_field"), :with => @entered_amount
          $get_txn_details_ref << ($framework["currency_type"]+" "+@entered_amount) # Get Currency and Amount Reference

          #if @tran_type.include? "IBFT"
          if ($framework["region"]== "SG") && (@tran_type.include? "IBFT")
            stop "Defect..!! System is not displaying POP" if ! $browser.has_xpath?(find_xpath("POP"), :text => 'Select Purpose')
            $browser.find(:xpath, find_xpath("POP"), :text => 'Select Purpose').click 
            @pop_text=$browser.find(:xpath, find_xpath("POP_1")).text
            $browser.find(:xpath, find_xpath("POP_1")).click
            $get_txn_details_ref << @pop_text # Get Pop Code Reference
            wait_for_ajax
            # Get the Bank Charges
            sleep 8
            @bank_charges=$browser.find(:xpath,find_xpath("bank_charges")).text
            # Get the To Be Paid By Value
            sleep 8
            @bank_charges_paid_by=$browser.find(:xpath,"//*[@id='newText']").text
            @concat_charges=(@bank_charges+" ("+@bank_charges_paid_by+")") # Concat the Charge Amount and Paid By
            $get_txn_details_ref << @concat_charges                         
          end

          if ($framework["region"]== "AE") && (@tran_type.include? "IBFT")
            wait_for_ajax
            stop "Defect..!! Bank Charges have not been displayed" if !$browser.has_xpath?(find_xpath("bank_charges"))
            @bank_charges=$browser.has_xpath?(find_xpath("bank_charges")).text
            $browser.find(:xpath, find_xpath("bank_charges_paid_by_selection")).click 
            wait_for_ajax
            $browser.find(:xpath, find_xpath("only_the_recipient")).click
            @bank_charges_paid_by=$browser.find(:xpath, find_xpath("only_the_recipient")).text
          end
          # Get Payment Txn Reference
          $get_txn_details_ref << $payment_txn_ref          
          $browser.fill_in find_xpath("description_entery_field"), :with => $payment_txn_ref
          wait_for_ajax
          post_txn_amount_validation($get_txn_details_ref) # Pass Txn Details to post_txn_amount_validation method
          $browser.find(:xpath, find_xpath("next")).click
          # Handle any Generic Error Occurance
            if $browser.has_css?('div.alert.alert-danger.ng-scope')
              fail "Error Message ::: "+ $browser.find(:css,'div.alert.alert-danger.ng-scope').text 
            end          
     end

     
     def local_transfer_SG(transfer_type)
      @tran_type=transfer_type
        payee_selection(transfer_type)
        from_acc_selection(transfer_type)
        review_the_transaction(transfer_type)
        wait_for_ajax
        conformation_of_transaction
        $browser.find(:xpath, find_xpath("Finsh&close_button")).click 
        # html/body//form//table[1]/tbody/tr[1]/td[2]
        # transfer_to= transfer_type=="To Local Account" ? local_acc_transfer : transfer_type== "To International Account" ? international_transfer :  manage_bene
        # $browser.find(:xpath, "html/body//form//table//tbody/tr[td[contains(., '20161013175104467')]]").click
     end

     def scrap_hash_data(data,key)
        @hash_data_values=[]
          data.each do |x| 
           x.each do |k,v| 
              if k == key
                @hash_data_values.push(v)
              end
           end

          end
            return @hash_data_values
      end
      
     # def from_cross_currency_select(table)
     #  sleep 5
     #    # from_screen_data_validation
     #    $browser.find(:xpath, find_xpath("select_Account")).click
     #    drop_down_data= $browser.find(:xpath, find_xpath("drop_down_box")).text
     #    to_account_data=drop_down_data.split(" ")
     #    currecy_type=[]; all_amount=[];same_curreny_amount=[]
     #    to_account_data.each_with_index do |e,i|
     #       all_amount<<e
     #      if e.include? "."
     #         currecy_type<<a[i-1] 
     #         same_curreny_amount<<e if table[index]==a[i-1]
     #      end
     #    end
     #    if same_curreny_amount!=[]
     #      max_amount=all_amount.index same_curreny_amount.min
     #      max_amount=@all_amount.index @amount.min
     #         $browser.find(:xpath, "//*[@class='ui-menu ui-corner-bottom ui-widget ui-widget-content']/li[#{max_amount.to_i+2}]").click 
     #         amount=rand(0.5..100)
     #         @payee_data<<amount=amount.to_s[0..4]
     #        $browser.fill_in find_xpath("amount_field"), :with => amount
     #        puts"@tran_type #{@tran_type}"
     #        if @tran_type.include? "IBFT"
     #          stop "Defect..!! System is not displaying" if ! $browser.has_xpath?(find_xpath("POP"), :text => 'Select Purpose')
     #          $browser.find(:xpath, find_xpath("POP"), :text => 'Select Purpose').click 
     #          @payee_data<<$browser.find(:xpath, find_xpath("POP_1")).text
     #          $browser.find(:xpath, find_xpath("POP_1")).click 
     #        end
     #        if ($framework["region"]== "AE") && (@tran_type.include? "IBFT")
     #          sleep 5 
     #          stop "Defect..!! Bank Charges have not been displayed" if !$browser.has_xpath?(find_xpath("bank_charges"))
     #          $browser.find(:xpath, find_xpath("bank_charges_paid_by_selection")).click 
     #          sleep 10
     #          $browser.find(:xpath, find_xpath("only_the_recipient")).click
     #        end
     #          $browser.fill_in find_xpath("description_entery_field"), :with => "Selenium UI Automation Testing"
     #        sleep 10
     #        $browser.find(:xpath, find_xpath("next")).click

     # end

     def currency_type_transfer_AE_SG(transfer_type, table)
      @tran_type=transfer_type
      @validated_currecy=[]; @skiped_validation=[]
      @skiped_Tranaction=false
      for index in 0..table.length
        @payee_data=[]
          puts transfer_type.include? "IBFT"
          type= transfer_type.include?("IBFT") ? "IBFT" : "TPFT"
          wait_for_ajax
          if @skiped_Tranaction==false
            @select_acc=$browser.find(:xpath, "html/body//form//table//tbody/tr[td[contains(., '#{$user[$framework["region"]][$current_user_instance][type]}')]]").click
           wait_for_ajax
            $browser.find(:xpath, find_xpath("next")).click
          wait_for_ajax
            $browser.find(:xpath, find_xpath("select_Account")).click
            drop_down_data= $browser.find(:xpath, find_xpath("drop_down_box")).text
            to_account_data=drop_down_data.split(" ")
          end
        currecy_type=[]; all_amount=[];same_curreny_amount=[]
        to_account_data.each_with_index do |e,i|
          if e.include? "."
            all_amount<<e
             currecy_type<<to_account_data[i-1] 
             if table[index]==to_account_data[i-1]
               same_curreny_amount<<e
             end 
          end
        end
        if (same_curreny_amount!=[]) && (!same_curreny_amount.include?("0.00"))
          max_amount=all_amount.index same_curreny_amount.max
          # max_amount=@all_amount.index @amount.min
             $browser.find(:xpath, "//*[@class='ui-menu ui-corner-bottom ui-widget ui-widget-content']/li[#{max_amount.to_i+2}]").click 
             enter_amount(10)
            #  amount=rand(0.5..100)
            #  @payee_data<<amount=amount.to_s[0..4]
            # $browser.fill_in find_xpath("amount_field"), :with => amount
            wait_for_ajax
            puts"@tran_type #{@tran_type}"
            if @tran_type== "IBFT"
              stop "Defect..!! System is not displaying" if ! $browser.has_xpath?(find_xpath("POP"), :text => 'Select Purpose')
              $browser.find(:xpath, find_xpath("POP"), :text => 'Select Purpose').click 
              @payee_data<<$browser.find(:xpath, find_xpath("POP_1")).text
              $browser.find(:xpath, find_xpath("POP_1")).click 
            end
            if ($framework["region"]== "AE") && (@tran_type.include? "IBFT")
             wait_for_ajax
              stop "Defect..!! Bank Charges have not been displayed" if !$browser.has_xpath?(find_xpath("bank_charges"))
              bank_charges=$browser.find(:xpath, find_xpath("bank_charges")).text
              wait_for_ajax
              $browser.find(:xpath, find_xpath("bank_charges_paid_by_selection")).click 
               @payee_data << bank_charges
              wait_for_ajax
              $browser.find(:xpath, "//div[@class='ui-menu-item-wrapper'][contains(., 'You and the recipient')]").click
            end
              $browser.fill_in find_xpath("description_entery_field"), :with => "Selenium UI Automation Testing"
              @payee_data<<"Selenium UI Automation Testing"
             wait_for_ajax
               stop "Defect..!! exchange rate value have not been displayed" if !$browser.has_xpath?(find_xpath("exchange_rate_value"))
                  @payee_data<<$browser.find(:xpath, find_xpath("exchange_rate_value")).text
               stop "Defect..!! exchange rate amount have not been displayed" if !$browser.has_xpath?(find_xpath("exchange_rate_amount"))
                  @payee_data<<$browser.find(:xpath, find_xpath("exchange_rate_amount")).text
            wait_for_ajax
            $browser.find(:xpath, find_xpath("next")).click
            wait_for_ajax
          review_the_transaction
          conformation_of_transaction
          wait_for_ajax
          index==table.length ? $browser.find(:xpath, find_xpath("Finsh&close_button")).click  : $browser.find(:xpath, find_xpath("make_another_transfer")).click
           @validated_currecy<<table[index]
           puts "\n \n Successfully Completed Validation for #{table[index]}"
           @skiped_Tranaction=false
        else 
          puts "Skipped Transaction #{table[index]}"
          @skiped_validation<< table[index]
          @skiped_Tranaction=true
          same_curreny_amount=[]
        end
     end
     puts "Successfully Completed the Validation of below metioned Currencies
     #{@validated_currecy}"
     fail "Error..!!! Below Mentioned Currency Type test data is not available in Application..
     PLease request the Team to add all the From account of below currecies to Validate 
     #{@skiped_validation}"if @skiped_validation!=[]
   end


   def fcy_AE(transfer_type, table)
    sleep 15
    @tran_type=transfer_type
    wait_for_ajax
    bene_table=$browser.find(:css,find_xpath('bene_tabel'))
    payee_data_length=(bene_table.all(:css,'tr').size)-1
       if transfer_type=="IBFT"
          @payee_pattern=transfer_type+"_"
       elsif transfer_type=="TPFT"
          @payee_pattern=transfer_type+" "
       end
       @payee_list=[]
       for acc_index in 1...payee_data_length
           @payee_list<<$browser.find(:xpath, "html/body//form//table[1]/tbody/tr[#{acc_index}]/td[1]").text
       end
       p "@payee_list ::: #{@payee_list}"
       @payee_available=[]
       for payee_index in 0...table.length
        # puts "payee name#{transfer_type+"_"+table[payee_index]}"
        if table[payee_index]!=nil
         @payee_available<<@payee_pattern+table[payee_index] if @payee_list.include?(@payee_pattern+table[payee_index])
        end
       end
       puts "@payee_available #{@payee_available}"
       fail "Error..!! There is specific PAYEE test data for Automation..
       Please Do Create it with below mention from_amount
       IBFT_USD/TPFT USD " if @payee_available==[]
       #@select_acc=$browser.find(:xpath, "html/body//form//table//tbody/tr[td[contains(., '#{@payee_available[2]}')]]").click       
       @select_acc=$browser.find(:xpath, "//*[@class='payee-name'][contains(text(),'#{@payee_available[2]}')]").click
       # payee_screen_data_capture(@payee_list.index @payee_available[2])
       #  wait_for_ajax
        sleep 5
       $browser.find(:xpath, find_xpath("next")).click
       wait_for_ajax
        # from_screen_data_capture
        # from_screen_data_validation
          $browser.find(:xpath, find_xpath("select_Account")).click
          drop_down_data= $browser.find(:xpath, find_xpath("drop_down_box")).text
          $browser.find(:xpath, find_xpath("back_button")).click
          wait_for_ajax
          to_account_data=drop_down_data.split(" ")
          from_currencies=[]; from_amount=[]
          for i in 0...to_account_data.length
            if to_account_data[i].include? "."
                from_currencies<<to_account_data[i-1]
                from_amount<<to_account_data[i]
            end
          end

          transfer_to=[];can_transfer_currencys=[];can_transfer_amount=[];can_transfer_index=[]
          for i in 0...@payee_available.length
            for c in 0...from_currencies.length
              puts "from_currencies[c] #{from_currencies[c]}"
              puts "@payee_available #{@payee_pattern}"
             puts  payee=@payee_pattern+from_currencies[c]
              if @payee_available[i]==payee
                if from_amount[c]!="0.00"
                  if !can_transfer_currencys.include?from_currencies[c]
                   transfer_to<<@payee_available[i]
                   can_transfer_currencys<<from_currencies[c]
                   can_transfer_index<<c
                   can_transfer_amount<<from_amount[c]
                  end
                end
              end
            end
          end
          puts "transfer_to:: #{transfer_to}"
          for i in 0...transfer_to.length
            @select_acc=$browser.find(:xpath, "html/body//form//table//tbody/tr[td[contains(., '#{transfer_to[i]}')]]").click   
            payee_screen_data_capture((@payee_list.index transfer_to[i]).to_i+1)
            wait_for_ajax
            sleep 3
            $browser.find(:xpath, find_xpath("next")).click
            wait_for_ajax
            from_screen_data_capture
            sleep 2
            from_screen_data_validation
            $browser.find(:xpath, find_xpath("select_Account")).click
            wait_for_ajax
            $browser.find(:xpath, "//*[@class='ui-menu ui-corner-bottom ui-widget ui-widget-content']/li[#{can_transfer_index[i]+2}]").click 
             max_amount=100
             can_transfer_amount[i].delete! ","
             max_amount=can_transfer_amount[i].to_i if can_transfer_amount[i].to_i<100
             amount=rand(0.5..max_amount)
             @payee_data<<amount=amount.to_s[0..4]
             $browser.fill_in find_xpath("amount_field"), :with => amount
             wait_for_ajax
            if @tran_type== "IBFT"
              stop "Defect..!! System is not displaying" if ! $browser.has_xpath?(find_xpath("POP"), :text => 'Select Purpose')
              $browser.find(:xpath, find_xpath("POP"), :text => 'Select Purpose').click 
              @payee_data<<$browser.find(:xpath, find_xpath("POP_1")).text
              $browser.find(:xpath, find_xpath("POP_1")).click 
            end
            if ($framework["region"]== "AE") && (transfer_type=="IBFT")
              wait_for_ajax 
              stop "Defect..!! Bank Charges have not been displayed" if !$browser.has_xpath?(find_xpath("bank_charges"))
              bank_charges=$browser.find(:xpath, find_xpath("bank_charges")).text
              $browser.find(:xpath, find_xpath("bank_charges_paid_by_selection")).click 
               @payee_data << bank_charges
              wait_for_ajax
              $browser.find(:xpath, "//div[@class='ui-menu-item-wrapper'][contains(., 'You and the recipient')]").click
            end
              $browser.fill_in find_xpath("description_entery_field"), :with => "Selenium UI Automation Testing"
              @payee_data<<"Selenium UI Automation Testing"
             stop "Defect..!! exchanage rates have been displayed for same FCY to FCY" if $browser.has_xpath?(find_xpath("exchange_rate_value"))
                # @payee_data<<$browser.find(:xpath, find_xpath("exchange_rate_value")).text
             stop "Defect..!! exchange rate amount have been displayed for same FCY to FCY" if $browser.has_xpath?(find_xpath("exchange_rate_amount"))
                # @payee_data<<$browser.find(:xpath, find_xpath("exchange_rate_amount")).text
            wait_for_ajax
            $browser.find(:xpath, find_xpath("next")).click
            wait_for_ajax
            review_the_transaction
            conformation_of_transaction
            wait_for_ajax
            puts "*** Successfully Completed Trasaction for #{transfer_to[i]}  ***"
            i+1==table.length ? $browser.find(:xpath, find_xpath("Finsh&close_button")).click  : $browser.find(:xpath, find_xpath("make_another_transfer")).click
            wait_for_ajax
          end
         end

    def fcy_lcY_cross_Currencies(transfer_type, table)
      @tran_type=transfer_type
       if transfer_type=="IBFT"
          @payee_pattern=transfer_type+"_"
       elsif transfer_type=="TPFT"
          @payee_pattern=transfer_type+" "
       end
    wait_for_ajax
    @payee_data=[]
    table=$browser.find(:css,find_xpath("bene_tabel"))
    payee_data_length=(table.all(:css,'tr').size)-1
       @payee_list=[]
       for acc_index in 1...payee_data_length[3]
           @payee_list<<$browser.find(:xpath, "html/body//form//table[1]/tbody/tr[#{acc_index}]/td[1]").text
       end
       @payee_available=[]
       for payee_index in 0...table.length
        # puts "payee name#{transfer_type+"_"+table[payee_index]}"
        if table[payee_index]!=nil
         @payee_available<<@payee_pattern+table[payee_index] if @payee_list.include?(@payee_pattern+table[payee_index])
        end
       end
       puts @payee_available
       fail "Error..!! There is specific PAYEE test data for Automation..
       Please Do Create it with below mention from_amount
       IBFT_USD/TPFT_SGD " if @payee_available==[]
       for i in 0...@payee_available.length
        @select_acc=$browser.find(:xpath, "html/body//form//table//tbody/tr[td[contains(., '#{@payee_available[i]}')]]").click       
        check_index=@payee_list.index @payee_available[i]
        payee_screen_data_capture(check_index.to_i+1)
            wait_for_ajax
            sleep 5
        $browser.find(:xpath, find_xpath("next")).click
            wait_for_ajax
            from_screen_data_capture
            from_screen_data_validation
            $browser.find(:xpath, find_xpath("select_Account")).click
         if i==0
            drop_down_data= $browser.find(:xpath, find_xpath("drop_down_box")).text
            to_account_data=drop_down_data.split(" ")
           currecy_type=[]; all_amount=[];same_curreny_amount=[]
           to_account_data.each_with_index do |e,i|
            if e.include? "."
              all_amount<<e
               currecy_type<<to_account_data[i-1] 
               same_curreny_amount<<e if $framework["currency_type"]==to_account_data[i-1]
            end
          end
          fail "Error..!! AED is test data is not available in from account" if same_curreny_amount==[]
          max_amount_index=all_amount.index same_curreny_amount.min
          max_amount=100
          all_amount[max_amount_index.to_i].delete! ","
          max_amount=all_amount[max_amount_index.to_i].to_i if all_amount[max_amount_index.to_i].to_i<100
        end
          
          $browser.find(:xpath, "//*[@class='ui-menu ui-corner-bottom ui-widget ui-widget-content']/li[#{max_amount_index.to_i+2}]").click 
          enter_amount(max_amount)
           $browser.fill_in find_xpath("description_entery_field"), :with => "Selenium UI Automation Testing"
              @payee_data<<"Selenium UI Automation Testing"
          wait_for_ajax
          if @tran_type== "IBFT"
              stop "Defect..!! System is not displaying" if ! $browser.has_xpath?(find_xpath("POP"), :text => 'Select Purpose')
              $browser.find(:xpath, find_xpath("POP"), :text => 'Select Purpose').click 
              @payee_data<<$browser.find(:xpath, find_xpath("POP_1")).text
              $browser.find(:xpath, find_xpath("POP_1")).click 
          end
            if ($framework["region"]== "AE") && (transfer_type=="IBFT")
              wait_for_ajax
              stop "Defect..!! Bank Charges have not been displayed" if !$browser.has_xpath?(find_xpath("bank_charges"))
              bank_charges=$browser.find(:xpath, find_xpath("bank_charges")).text
              wait_for_ajax
              $browser.find(:xpath, find_xpath("bank_charges_paid_by_selection")).click 
               @payee_data << bank_charges
              wait_for_ajax
              $browser.find(:xpath, "//div[@class='ui-menu-item-wrapper'][contains(., 'You and the recipient')]").click
            end
             wait_for_ajax
             stop "Defect..!! exchanage rates have not been displayed for same FCY to LCY" if !$browser.has_xpath?(find_xpath("exchange_rate_value"))
                @payee_data<<$browser.find(:xpath, find_xpath("exchange_rate_value")).text
             stop "Defect..!! exchange rate amount have not been displayed for same FCY to LCY" if !$browser.has_xpath?(find_xpath("exchange_rate_amount"))
                @payee_data<<$browser.find(:xpath, find_xpath("exchange_rate_amount")).text
            wait_for_ajax
            $browser.find(:xpath, find_xpath("next")).click
            wait_for_ajax
            review_the_transaction
            conformation_of_transaction
            wait_for_ajax
            puts "*** Successfully Completed Trasaction for #{@payee_available[i]}  ***"
            wait_for_ajax
            i+1==table.length ? $browser.find(:xpath, find_xpath("Finsh&close_button")).click  : $browser.find(:xpath, find_xpath("make_another_transfer")).click
            wait_for_ajax
          end
    end

  

 ##########################################################POP################################################################
   def pop_validation(type, pop)
    @payee_data=[]
      trans_type=type.split("-")
    wait_for_ajax
    sleep 5
    @payee_list=[]
    table=$browser.find(:css,find_xpath("bene_tabel"))
    payee_data_length=(table.all(:css,'tr').size)-1
        for acc_index in 1...payee_data_length[3]
           @payee_list<<$browser.find(:xpath, "html/body//form//table[1]/tbody/tr[#{acc_index}]/td[1]").text
        end
        payee_index=@payee_list.index "IBFT "+trans_type[0] if trans_type[0]=="AED"
        payee_index=@payee_list.index "IBFT_"+trans_type[0] if trans_type[0]!="AED"
        fail "Error..!! There is specific PAYEE test data for Automation..
       Please Do Create IBFT_#{trans_type[0]} for #{$framework["region"]} "if payee_index==nil
       for each_pop in pop
        @select_acc=$browser.find(:xpath, "html/body//form//table//tbody/tr[td[contains(., '#{@payee_list[payee_index]}')]]").click
        payee_screen_data_capture(payee_index+1)
        wait_for_ajax
        sleep 10
        $browser.find(:xpath, find_xpath("next")).click
        from_screen_data_capture
        from_screen_data_validation
        wait_for_ajax
        $browser.find(:xpath, find_xpath("select_Account")).click
        if each_pop==pop[0]
          drop_down_data= $browser.find(:xpath, find_xpath("drop_down_box")).text
          to_account_data=drop_down_data.split(" ")
          currecy_type=[]; all_amount=[];same_curreny_amount=[]
             to_account_data.each_with_index do |e,i|
              if e.include? "."
                all_amount<<e
                 currecy_type<<to_account_data[i-1] 
                 same_curreny_amount<<e if trans_type[1]==to_account_data[i-1]
              end
            end
            fail "Error..!! #{trans_type[1]} test data is not available in from account" if same_curreny_amount==[]
            puts "same_curreny_amount #{same_curreny_amount}"
             max_amount_index=all_amount.index same_curreny_amount.max
             puts "max_amount_index  #{max_amount_index}"
             max_amount=10
            all_amount[max_amount_index.to_i].delete! ","
            max_amount=all_amount[max_amount_index.to_i].to_i if all_amount[max_amount_index.to_i].to_i<10
        end
         $browser.find(:xpath, "//*[@class='ui-menu ui-corner-bottom ui-widget ui-widget-content']/li[#{max_amount_index.to_i+2}]").click 
          enter_amount(max_amount)
           $browser.fill_in find_xpath("description_entery_field"), :with => "Selenium UI Automation Testing"
           @payee_data<<"Selenium UI Automation Testing"
           wait_for_ajax
           stop "Defect..!! System is not displaying" if ! $browser.has_xpath?(find_xpath("POP"), :text => 'Select Purpose')
           $browser.find(:xpath, find_xpath("POP"), :text => 'Select Purpose').click 
           @payee_data<<$browser.find(:xpath, "//div[@class='ui-selectmenu-menu ui-front ui-selectmenu-open']//li[starts-with(., '#{each_pop}')]").text
           $browser.find(:xpath, "//div[@class='ui-selectmenu-menu ui-front ui-selectmenu-open']//li[starts-with(., '#{each_pop}')]").click 
           if ($framework["region"]== "AE")
              wait_for_ajax
              stop "Defect..!! Bank Charges have not been displayed" if !$browser.has_xpath?(find_xpath("bank_charges"))
              bank_charges=$browser.find(:xpath, find_xpath("bank_charges")).text
              wait_for_ajax
              $browser.find(:xpath, find_xpath("bank_charges_paid_by_selection")).click 
               @payee_data << bank_charges
              wait_for_ajax
              $browser.find(:xpath, "//div[@class='ui-menu-item-wrapper'][contains(., 'You and the recipient')]").click
            end
             wait_for_ajax
             if trans_type[0]!=trans_type[1]
              sleep 5
               stop "Defect..!! exchanage rates have not been displayed for FCY to LCY" if !$browser.has_xpath?(find_xpath("exchange_rate_value"))
                  @payee_data<<$browser.find(:xpath, find_xpath("exchange_rate_value")).text
               stop "Defect..!! exchange rate amount have not been displayed for same FCY to LCY" if !$browser.has_xpath?(find_xpath("exchange_rate_amount"))
                  @payee_data<<$browser.find(:xpath, find_xpath("exchange_rate_amount")).text
              end
              wait_for_ajax
              sleep 5
            $browser.find(:xpath, find_xpath("next")).click
            wait_for_ajax
            sleep 20
            review_the_transaction
            sleep 15
            wait_for_ajax
            conformation_of_transaction
            wait_for_ajax
            puts "*** Successfully Completed Trasaction with  #{each_pop} POP ***"
            wait_for_ajax
            sleep 15
            each_pop==pop[pop.length-1] ? $browser.find(:xpath, find_xpath("Finsh&close_button")).click  : $browser.find(:xpath, find_xpath("make_another_transfer")).click
            wait_for_ajax
            sleep 15
      end
   end

   def pop_list_validation(confulence_pop_list)
    puts confulence_pop_list.length
      payee_selection("IBFT")
      $browser.find(:xpath, find_xpath("select_Account")).click
      $browser.find(:xpath, "//*[@class='ui-menu ui-corner-bottom ui-widget ui-widget-content']/li[2]").click 
      $browser.find(:xpath, find_xpath("POP"), :text => 'Select Purpose').click 
      $browser.find(:xpath, "//div[@class='ui-selectmenu-menu ui-front ui-selectmenu-open']//li").click 
         rescue Exception => e 
         puts error= e.message
         puts "error #{error}"
        raise e if  !error.include? "Ambiguous match,"
       payee_data_length=error.split(" ").map(&:to_i).compact
       puts "all_acc_numbers:: #{payee_data_length}"
       app_pop_list=[]
       for i in 2..payee_data_length[3]
         app_pop_list<<$browser.find(:xpath, "//div[@class='ui-selectmenu-menu ui-front ui-selectmenu-open']//li[#{i}]").text
       end
       puts app_pop_list
       mismatch_list=confulence_pop_list-app_pop_list | app_pop_list-confulence_pop_list
       fail "Defect..!!! Application POP list is not matching with confulence pop list 
       please find details below
       POP's not available in Application:
       #{confulence_pop_list-app_pop_list} 
       POP's not available in Confulence:
       #{app_pop_list-confulence_pop_list} 
       " if !mismatch_list.empty?
   end

def ibcc_selection(transfer_type)    
        wait_for_ajax            
        puts "!!!Selected other local bank credit card" if $browser.find(:xpath, "//td[@class='payee-name'][contains(text(),'IBCC User')]").visible?
        wait_for_ajax
        $browser.find(:xpath, "//td[@class='payee-name'][contains(text(),'IBCC User')]").click
        sleep 8
        $browser.find(:xpath, find_xpath("next")).click if $browser.find(:xpath, find_xpath("next")).visible?
        wait_for_ajax        
        $browser.find(:xpath, find_xpath("select_Account")).click
        drop_down_data= $browser.find(:xpath, find_xpath("drop_down_box")).text      
        @from_account_number=[]      
            for i in 0..drop_down_data.split.length
               @from_account_number<< drop_down_data.split[i-1] if drop_down_data.split[i]== "-" && drop_down_data.split[i+1] !='0.00' && drop_down_data.split[i+1] !='-'        
            end        
        wait_for_ajax 
        fail "!!!Error!!! There is no casa accounts are present" if @from_account_number.nil?               
        $browser.find(:xpath, "//div[@class='ui-menu-item-wrapper'][contains(text(),'#{@from_account_number[1]}')]").click
        wait_for_ajax
        $browser.fill_in find_xpath("amount_field"), :with => '1'  
        wait_for_ajax
        stop "Defect..!! System is not displaying" if ! $browser.has_xpath?(find_xpath("POP"), :text => 'Select Purpose')
        $browser.find(:xpath, find_xpath("POP"), :text => 'Select Purpose').click            
        $browser.find(:xpath, find_xpath("POP_1")).click 
        wait_for_ajax
        $browser.fill_in find_xpath("description_entery_field"), :with => "Selenium UI Automation Testing"
        wait_for_ajax
        sleep 5
        $browser.find(:xpath, find_xpath("next")).click    
        wait_for_ajax       
    end

def credit_card_selection(transfer_type)
  wait_for_ajax
        from_screen_data_validation
        $browser.find(:xpath, find_xpath("select_Account")).click
        drop_down_data= $browser.find(:xpath, find_xpath("drop_down_box")).text      
        @from_account_number=[]
            for i in 0..drop_down_data.split.length
               @from_account_number<< drop_down_data.split[i-1] if drop_down_data.split[i]== "-"            
            end
            puts "@from_account_numbers:: #{@from_account_number}"
            for index in 0...@from_account_number.size
                  @credit_card_number = @from_account_number[index] if @from_account_number[index].size > 15
                  break if @from_account_number[index].size > 15
            end
            puts "@Credit_Card_Number:: #{@credit_card_number}"
            if ($framework["region"]== "AE") && (transfer_type.include? "IBFT")
                 wait_for_ajax
                 fail "!!!Defect!!! Credit card data is present for Global Accounts" if !@credit_card_number.nil?                
                 puts "!!!Perfect!!! There is no Credit Card Data for IBFT transaction" if @credit_card_number.nil?
            else
                 fail "!!!Test Data Issue!!! There is no Creditcard data is present" if @credit_card_number.nil?                            
                 max_amount=@from_account_number.index @credit_card_number
                 $browser.find(:xpath, "//*[@class='ui-menu ui-corner-bottom ui-widget ui-widget-content']/li[#{max_amount.to_i+2}]").click                                  
                 $browser.fill_in find_xpath("amount_field"), :with => '1'
                 puts"@tran_type:: #{transfer_type}"                
          if transfer_type.include? "IBFT"
                stop "Defect..!! System is not displaying" if ! $browser.has_xpath?(find_xpath("POP"), :text => 'Select Purpose')
                $browser.find(:xpath, find_xpath("POP"), :text => 'Select Purpose').click 
                @payee_data<<$browser.find(:xpath, find_xpath("POP_1")).text
                $browser.find(:xpath, find_xpath("POP_1")).click 
          end                  
                $browser.fill_in find_xpath("description_entery_field"), :with => "Selenium UI Automation Testing"
                wait_for_ajax
                sleep 5
                $browser.find(:xpath, find_xpath("next")).click                 
          end
end  



end
