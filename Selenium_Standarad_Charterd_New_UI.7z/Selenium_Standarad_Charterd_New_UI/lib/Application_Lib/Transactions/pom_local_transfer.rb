module PomLocalTransfer

 def initialize
      super

        @xpath = {
          # Local_Transfer_Elements
            # "local_transfer_table_data"         =>         "//div[@class='form-step form-step-to']",
            "local_transfer_table_data"         =>         "//*[@class='bank-name']",
            
            "from_acc_data"                     =>         "//div[@class='form-fields']",
            #"next"                              =>         "//button[@type='submit']",
            "next"                              =>         "//*/button[@type='submit']",
# "next_button"                       => "//button[@type='submit']"
            # "select_Account"                  =>         "ui-id-2-button",
            "drop_down_box"                     =>         "//div[@class='ui-selectmenu-menu ui-front ui-selectmenu-open']",
            "select_Account"                    =>         "//span[@class='ui-selectmenu-button ui-selectmenu-button-closed ui-corner-all ui-button ui-widget']",
            "amount_field"                      =>         "transferAmount-amount",
            "POP"                               =>         "//span[@class='ui-selectmenu-text']",
            "POP_1"                             =>         "//div[@class='ui-selectmenu-menu ui-front ui-selectmenu-open']//li[2]",
            "accept_terms"                      =>         "//input[@type='checkbox']" ,
            "reference_number"                  =>        "//*[@id='main']/div/div[2]/div[2]/div/div[1]/div[2]",
            "account_to_be_transfered"          =>        "//*[@id='main']/div/div[2]/div[2]/div/div[4]/div[2]" ,
            "account_to_be_transfered_from"     =>        "//*[@id='main']/div/div[2]/div[2]/div/div[5]/div[2]", 
            "currency_amount"                   =>        "//*[@id='main']/div/div[2]/div[2]/div/div[6]/div[2]" ,
            "conformation_payee_name"           =>        "//*[@id='main']/div/div[2]/div[2]/div/div[3]/div[2]",
            "payee_name_from_screen"            =>        "//*[@class='form-step form-step-main']/div[1]/scb-ng-common-field[1]/div/div",
            "payee_acc_no_from_screen"          =>        "//*[@class='form-step form-step-main']/div[1]/scb-ng-common-field[2]/div/div",
            "payee_Bank_name_from_screen"       =>        "//*[@class='form-step form-step-main']/div[1]/scb-ng-common-field[3]/div/div",
            "Review_Screen"                     =>        "//div[@class='form-step form-step-review']",
            "Confromation_Screen"               =>        "//div[@class='grid container-fluid']",
            "Finsh&close_button"                =>        "//button[@class='btn btn-primary btn-block']",
            "bank_charges"                      =>        "//span[@class='amount ng-binding']",
            "description_entery_field"          =>        "description",
            "only_the_recipient"                =>        "//div[@class='ui-menu-item-wrapper ui-state-active']",
            "bank_charges_paid_by_selection"    =>        "//*[@name = 'paidBy']/span",
            "make_another_transfer"             =>        "//button[@class='btn btn-secondary btn-block']"  ,
            "You and the recipient"             =>        "//div[@class='ui-menu-item-wrapper'][contains(., 'You and the recipient')]",
            "exchange_rate_value"               =>        "//div[@class='exchange-rate-rate ng-binding']",
            "exchange_rate_amount"              =>        "//div[@class='exchange-rate-amount ng-binding']",
            "back_button"                       =>         "//button[@class='btn btn-default btn-block form-item form-item-back form-type-back']" ,
            # "bank_charges_paid_by_selection"    =>        "html/body//form//scb-ng-common-selectmenu[@name = 'paidBy']/span"
            "TSP"                               =>        "//*[@class='form-step form-step-auth']",
            "Error_Alert"                        =>      "//*[@id='main']/div/div[2]/scb-ng-common-form/form/scb-ng-common-messages/div/div/scb-ng-common-message/div",
            "search_payee"                       =>       "Search",
            "manage_payee_button"                =>       "//*[@class='btn btn-primary btn-sm']",
            "default_description_AE"             =>      "iBanking FT Local Trf",
            "Description_filed_name_AE"          =>      "DESCRIPTION",
            "Description_filed_name_SG"          =>      "DESCRIPTION",
            "trans_ref_AE"                       =>       "//*[@class='form-group form-item form-item-description form-type-text']/label",
            "Description_SG"                     =>       "//*[@class='form-group form-item form-item-description form-type-text']/label",
            "description_feild_path"             =>       "//*[@class='form-control ng-pristine ng-valid ng-not-empty ng-valid-minlength ng-valid-required ng-valid-pattern ng-valid-maxlength ng-touched']",
            "pop_up_window"                      =>       "/html/body/div[2]/div/div/div/h2",
            "Yes"                                =>       "//button[@class='btn btn-primary btn-block']",
            "bene_tabel"                         =>       "table.table-hover.table-bordered.hidden-xs.common-table.ng-scope",
            "inft_payee_Bank_name_from_screen"   =>        "//*[@class='form-step form-step-main']/div[1]/scb-ng-common-field[5]/div/div",
            "inft_payee_acc_no_from_screen"      =>        "//*[@class='form-step form-step-main']/div[1]/scb-ng-common-field[7]/div/div",
            "click_pop_dropdown"                 =>         "//div/*[@name='receivingPurpose']/span[@class='ui-selectmenu-button ui-selectmenu-button-closed ui-corner-all ui-button ui-widget']",
            "collect_pop_values"                 =>       "//div[@class='ui-selectmenu-menu ui-front ui-selectmenu-open']"
         }

      end

      def payee_screen_data_capture(row)
        @payee_name_payee_screen=$browser.find(:xpath, "html/body//form//table[1]/tbody/tr[#{row}]/td[1]").text
        @bank_name_payee_screen=$browser.find(:xpath, "html/body//form//table[1]/tbody/tr[#{row}]/td[2]").text
        @account_number_payee_screen=$browser.find(:xpath, "html/body//form//table[1]/tbody/tr[#{row}]/td[3]").text

     end

      def from_screen_data_capture
        @get_title=$browser.find(:css,'h1.form-title.ng-binding').text
        if @get_title.eql? "Transfer / To International Account"
          @payee_name_from_screen=$browser.find(:xpath, find_xpath("payee_name_from_screen")).text
          @bank_name_from_screen=$browser.find(:xpath, find_xpath("inft_payee_Bank_name_from_screen")).text
          @account_number_from_screen=$browser.find(:xpath, find_xpath("inft_payee_acc_no_from_screen")).text

        else
          @payee_name_from_screen=$browser.find(:xpath, find_xpath("payee_name_from_screen")).text
          @bank_name_from_screen=$browser.find(:xpath, find_xpath("payee_Bank_name_from_screen")).text
          @account_number_from_screen=$browser.find(:xpath, find_xpath("payee_acc_no_from_screen")).text

        end
      end


     def from_screen_data_validation
       fail "Defect..!!! Payee name is not Matching with payee screen and from screen.
         Expected:- #{@payee_name_payee_screen}, Actual:- #{@payee_name_from_screen}
         " if @payee_name_payee_screen != @payee_name_from_screen
       fail "Defect..!!! Bank name is not Matching with payee screen and from screen.
         Expected:- #{@bank_name_payee_screen}, Actual:- #{@bank_name_from_screen}
         " if @bank_name_payee_screen != @bank_name_from_screen
       fail "Defect..!!! Account Number is not Matching with payee screen and from screen.
         Expected:- #{@account_number_payee_screen}, Actual:- #{@account_number_from_screen}
         " if @account_number_payee_screen != @account_number_from_screen       
     end

    def review_and_conformation_screen_data_validation(screen)
       sleep 7
        @display_actual_value=[]
        @actual_value=[] # Collect all the value from Payment Screen
        @exp_page_screen_validation # calling a returned value from method 'post_txn_amount_validation(txn_amount_details)'
        @get_txn_step=$browser.find(:css,'div.form-step-counter.ng-binding.ng-scope').text
        
        # Validate Payment Details in Payment Review Screen
        puts "Validate Payment Details in Payment Review Screen"
        @row_count=$browser.find(:xpath,"//*[@class='grid container-fluid ng-scope']").all(:xpath,"div[starts-with(@class,'row')]").size
      
      for exp in 0...@exp_page_screen_validation.length do
          @exp_value=@exp_page_screen_validation[exp].downcase
        for i in 1..@row_count do
          @actual_value=$browser.find(:xpath,"//*[@class='grid container-fluid ng-scope']/div[#{i}]/div[2]").text
          @actual_value=@actual_value.downcase
          @display_actual_value << @actual_value
          if @actual_value.include? @exp_value
            @is_valid=1
            break  
          end
          @is_valid=0
        end
          if (@is_valid != 1)
            puts "Display actual value as captured :: #{@display_actual_value}"
            raise "Unable to Validate Expected Value::#{@exp_value} in #{@get_txn_step} Payment Review Screen" 
          end
      end
        puts "Payment Txn Details in step #{@get_txn_step} - Review Payment Details is validated successfully\n"       
    end

     def review_the_transaction(transfer_type="")
      wait_for_ajax
        @tran_type=transfer_type
        @get_title=$browser.find(:css,'h1.form-title.ng-binding').text
        review_and_conformation_screen_data_validation("Review_Screen")
         wait_for_ajax
         if ($framework["region"]== "SG") && ((@tran_type.include? "INFT") || (@get_title.eql? "Transfer / To International Account")) 
          $browser.find(:xpath, find_xpath("accept_terms")).click
         elsif ($framework["region"]== "AE") && ((%w(OAFT TPFT IBFT INFT OBCC).include? @tran_type) || (@get_title.eql? "Transfer / To International Account"))
          $browser.find(:xpath, find_xpath("accept_terms")).click
         else
          puts "Terms and condition checkbox is not applicable for country::: #{$framework["region"]} and Txn Type could be either OAFT,TPFT or IBFT"
         end
        wait_for_ajax
        sleep 3
        $browser.find(:xpath, find_xpath("next")).click
        sleep 7 
        
        if $browser.has_css?('div.alert.alert-danger.ng-scope')
          fail "Error Message ::: "+ $browser.find(:css,'div.alert.alert-danger.ng-scope').text 
        end    
       
         # review_and_conformation_screen_data_validation("Review_Screen")
         # wait_for_ajax
         # # For SG IBFT- Terms and Condition Check Box is not required, but for AE the Terms and Conditions req.
         # $browser.find(:xpath, find_xpath("accept_terms")).click 
         # wait_for_ajax
         # $browser.find(:xpath, find_xpath("next")).click
     end

     def conformation_of_transaction
     wait_for_ajax
        @actual_value=[] # Collect all the value from Payment Screen
        @exp_page_screen_validation # calling a returned value from method 'post_txn_amount_validation(txn_amount_details)'        
        
        # Validate Payment Details in Transaction Submitted Screen
        @get_txn_sub_ref=$browser.find(:css,'div.message.ng-binding').text 
        fail "Missing Transaction Submitted Reference ::: #{@get_txn_sub_ref}" if @get_txn_sub_ref != "Your transaction has been submitted."
        # Get Txn Reference
        $transaction_reference=$browser.find(:xpath, find_xpath("reference_number")).text
        puts "Transaction Reference Number ::: #{$transaction_reference}"
        
        @row_count=$browser.find(:xpath,"//*[@class='grid container-fluid']").all(:xpath,"div[starts-with(@class,'row')]").size
      
      for exp in 0...@exp_page_screen_validation.length do
          @exp_value=@exp_page_screen_validation[exp].downcase   
            for i in 2..(@row_count) do
              @actual_value=$browser.find(:xpath,"//*[@class='grid container-fluid']/div[#{i}]/div[2]").text
              @actual_value=@actual_value.downcase
              if @actual_value.include? @exp_value
              @is_valid=1
              break
              end
              @is_valid=0
            end
      raise "Unable to Validate Expected Value::#{@exp_value} in #{@get_txn_step} Payment Review Screen" if (@is_valid != 1)
      end

        puts "Payment Acknowledgement Page is validated successfully with note '#{@get_txn_sub_ref}'\n"

        #Clear the Array Post Validations
        @exp_page_screen_validation.clear
        $get_txn_details_ref.clear
        @display_actual_value.clear


     end

       def enter_amount(max_amount)
          $payment_amount=0
          amount=rand(1.5..max_amount)
          amount_length=4
          index_amount=amount.to_s.index "."
          amount_length=3 if index_amount==1
          @payee_data<<amount=amount.to_s[0..amount_length]
          $payment_amount = amount
          $browser.fill_in find_xpath("amount_field"), :with => $payment_amount
          puts "The Tranasction $payment_amount ::: #{$payment_amount}"
    end

     def post_txn_amount_validation(txn_amount_details)
      @exp_page_screen_validation=[]      
      @exp_page_screen_validation << $browser.find(:xpath, find_xpath("payee_name_from_screen")).text
      @exp_page_screen_validation << $browser.find(:xpath, find_xpath("payee_Bank_name_from_screen")).text          
      @exp_page_screen_validation << $browser.find(:xpath, find_xpath("payee_acc_no_from_screen")).text
      @exp_page_screen_validation << txn_amount_details
      @exp_page_screen_validation=@exp_page_screen_validation.flatten
      puts "@exp_page_screen_validation :::: #{@exp_page_screen_validation}"
      return @exp_page_screen_validation
     end    

     def oaft_post_txn_amount_validation(txn_amount_details)
      @exp_page_screen_validation=[]      
      @exp_page_screen_validation << txn_amount_details
      p @exp_page_screen_validation=@exp_page_screen_validation.flatten
      return @exp_page_screen_validation
     end


     
end