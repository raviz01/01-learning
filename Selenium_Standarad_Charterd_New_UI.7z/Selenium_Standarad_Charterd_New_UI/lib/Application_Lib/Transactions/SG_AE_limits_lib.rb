class SGAELimits
 include Handler
 include WaitForAjax
 include PomLocalTransfer
  
  def limit_SG_AE(currency_type, transaction_type, limit)
    puts "limit checking here #{limit}"
    @limit_amount=limit
    @limit_amount=limit.delete(",") if limit.include?(",") 
  	puts "@limit_amount:: #{@limit_amount}"
  	 @payee_data=[]
      trans_type=currency_type.split("-")
    wait_for_ajax
    sleep 5
    @payee_list=[]
    $browser.find(:xpath, find_xpath("local_transfer_table_data")).text 
         rescue Exception => e 
         puts error= e.message
         puts "error #{error}"
        raise e if  !error.include? "Ambiguous match,"
       payee_data_length=error.split(" ").map(&:to_i).compact
       puts "all_acc_numbers:: #{payee_data_length}"
        for acc_index in 1...payee_data_length[3]
           @payee_list<<$browser.find(:xpath, "html/body//form//table[1]/tbody/tr[#{acc_index}]/td[1]").text
        end
        payee_index=@payee_list.index "#{transaction_type} "+trans_type[0] if trans_type[0]=="AED"
        payee_index=@payee_list.index "#{transaction_type}"+"_"+trans_type[0] if trans_type[0]!="AED"
        fail "Error..!! There is specific PAYEE test data for Automation..
       Please Do Create #{transaction_type}_#{trans_type[0]} for #{$framework["region"]} "if payee_index==nil
        @select_acc=$browser.find(:xpath, "html/body//form//table//tbody/tr[td[contains(., '#{@payee_list[payee_index]}')]]").click
        payee_screen_data_capture(payee_index+1)
        wait_for_ajax
        sleep 10
        $browser.find(:xpath, find_xpath("next")).click
        wait_for_ajax
        from_screen_data_capture
        from_screen_data_validation
        $browser.find(:xpath, find_xpath("select_Account")).click
          drop_down_data= $browser.find(:xpath, find_xpath("drop_down_box")).text
          to_account_data=drop_down_data.split(" ")
          currecy_type=[]; all_amount=[];same_curreny_amount=[]
             to_account_data.each_with_index do |e,i|
              if e.include?(".")
                all_amount<<e
                 currecy_type<<to_account_data[i-1] 
                 same_curreny_amount<<e if trans_type[1]==to_account_data[i-1]
              end
            end
            fail "Error..!! #{trans_type[1]} test data is not available in from account" if same_curreny_amount==[]
            puts "same_curreny_amount #{same_curreny_amount}"
            if (trans_type[0]!=trans_type[1]) && ($framework["region"]== "AE")
            	max_amount_index=same_curreny_amount.index same_curreny_amount[0]
            	$browser.find(:xpath, "//*[@class='ui-menu ui-corner-bottom ui-widget ui-widget-content']/li[#{max_amount_index.to_i+2}]").click 
            	$browser.fill_in find_xpath("amount_field"), :with => 1 
            	sleep 10
            	puts "amount :: #{$browser.find(:xpath, find_xpath("exchange_rate_amount")).text}"
            	puts amount=$browser.find(:xpath, find_xpath("exchange_rate_amount")).text.to_f*@limit_amount
            	same_curreny_amount.each do |e|
                actual_amount=e
                e=e.delete(",") if e.include?(",")
	            	if e.to_f>@limit_amount.to_f
	            		@max_amount=e
	            		break
	            	end
                end
                @amount=amount
             	$browser.fill_in find_xpath("amount_field"), :with => amount.next
            else
            	same_curreny_amount.each do |e|
                actual_amount=e
                e=e.delete "," if e.include? ","
	            	if e.to_f>@limit_amount.to_f
	            		@max_amount=actual_amount
	            		break
	            	end
                end
                @amount=@limit_amount
            end
            max_amount_index=same_curreny_amount.index @max_amount
              fail "Error..!!! Please TOP UP amount for this user accounts to perform the limit check
              limit for this transaction: #{@limit_amount}
              available #{trans_type[1]} funds in this user account : #{same_curreny_amount}
              " if max_amount_index==nil
           $browser.find(:xpath, "//*[@class='ui-menu ui-corner-bottom ui-widget ui-widget-content']/li[#{max_amount_index.to_i+2}]").click 
           $browser.fill_in find_xpath("amount_field"), :with => @limit_amount.next
           $browser.fill_in find_xpath("description_entery_field"), :with => "Selenium UI Automation Testing"
           @payee_data<<"Selenium UI Automation Testing"
           wait_for_ajax
           stop "Defect..!! System is not displaying" if ! $browser.has_xpath?(find_xpath("POP"), :text => 'Select Purpose')
           $browser.find(:xpath, find_xpath("POP"), :text => 'Select Purpose').click 
           @payee_data<<$browser.find(:xpath, find_xpath("POP_1")).text
           $browser.find(:xpath, find_xpath("POP_1")).click
           if ($framework["region"]== "AE") && (transaction_type=="IBFT")
              wait_for_ajax
              stop "Defect..!! Bank Charges have not been displayed" if !$browser.has_xpath?(find_xpath("bank_charges"))
              bank_charges=$browser.find(:xpath, find_xpath("bank_charges")).text
              wait_for_ajax
              $browser.find(:xpath, find_xpath("bank_charges_paid_by_selection")).click 
               @payee_data << bank_charges
              wait_for_ajax
              $browser.find(:xpath, "//div[@class='ui-menu-item-wrapper'][contains(., 'Only the recipient')]").click
            end
             wait_for_ajax
              sleep 5
              if trans_type[0]!=trans_type[1]
               stop "Defect..!! exchanage rates have not been displayed for FCY to LCY" if !$browser.has_xpath?(find_xpath("exchange_rate_value"))
                  @payee_data<<$browser.find(:xpath, find_xpath("exchange_rate_value")).text
               stop "Defect..!! exchange rate amount have not been displayed for same FCY to LCY" if !$browser.has_xpath?(find_xpath("exchange_rate_amount"))
                  @payee_data<<$browser.find(:xpath, find_xpath("exchange_rate_amount")).text
              end
                wait_for_ajax
              sleep 5
            $browser.find(:xpath, find_xpath("next")).click
            wait_for_ajax
            if $check_limit_error==true
            sleep 5
    	      #          @default_limit_AE.gsub(/[^0-9]/, "") if @default_limit_AE!=nil
    	      # @default_limit_AE ||= $user[$framework["environment"]]["Common_limits"]["#{tran_type}_Limit"].to_i 
    	      # ui_error_message=amount.to_i<= @default_limit_AE.to_i ? page.find_xpath("Limit Message").strip : page.find_xpath("Max Limit Message").strip
    	       puts $browser.find(:xpath, find_xpath("Error_Alert")).text
    	       stop "Defect..!! Limit Error message has not been diplayed " if !$browser.has_xpath?(find_xpath("Error_Alert"))
    	       stop "Error..!! Wrong Limit message displayed - Actual:- #{$browser.find(:xpath, find_xpath("Error_Alert")).text} Expected:- The amount entered exceeds transaction limit or limit set by you. Please re-enter the transfer amount" if $browser.find(:xpath, find_xpath("Error_Alert")).text.strip!="The amount entered exceeds transaction limit or limit set by you. Please re-enter the transfer amount"

            else
            review_the_transaction
            sleep 15
            fail "OTP Page has not been displayed" if !$browser.has_xpath?(find_xpath("TSP"))
            puts "OTP page has been displayed"
            end
             
  end



end