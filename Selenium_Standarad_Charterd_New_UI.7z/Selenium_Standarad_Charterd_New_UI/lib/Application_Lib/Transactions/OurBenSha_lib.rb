class OurBenShaLib
	include Handler
    include WaitForAjax
    include PomLocalTransfer

# def our_ben_sha_validation(currency_type, transaction_type)
#     @payee_data=[]
#       trans_type=currency_type.split("-")
#     wait_for_ajax
#     sleep 5
#     @payee_list=[]
#     table=$browser.find(:css, find_xpath("bene_tabel"))
#     payee_data_length=(table.all(:css,'tr').size)-1
#         for acc_index in 1...payee_data_length[3]
#            @payee_list<<$browser.find(:xpath, "html/body//form//table[1]/tbody/tr[#{acc_index}]/td[1]").text
#         end
#         puts  "trans_type[0] :: #{trans_type[0]}"
#         payee_index=@payee_list.index "IBFT "+trans_type[0] if trans_type[0].strip=="AED"
#         payee_index=@payee_list.index "IBFT_"+trans_type[0] if trans_type[0].strip!="AED"
#         fail "Error..!! There is specific PAYEE test data for Automation..
#        Please Do Create IBFT_#{trans_type[0]} for #{$framework["region"]} "if payee_index==nil
#         @select_acc=$browser.find(:xpath, "html/body//form//table//tbody/tr[td[contains(., '#{@payee_list[payee_index]}')]]").click
#         payee_screen_data_capture(payee_index+1)
#         wait_for_ajax
#         sleep 10
#         $browser.find(:xpath, find_xpath("next")).click
#         wait_for_ajax
#         from_screen_data_capture
#         from_screen_data_validation
#         $browser.find(:xpath, find_xpath("select_Account")).click
#           drop_down_data= $browser.find(:xpath, find_xpath("drop_down_box")).text
#           to_account_data=drop_down_data.split(" ")
#           currecy_type=[]; all_amount=[];same_curreny_amount=[]
#              to_account_data.each_with_index do |e,i|
#               if e.include? "."
#                 all_amount<<e
#                  currecy_type<<to_account_data[i-1] 
#                  same_curreny_amount<<e if trans_type[1]==to_account_data[i-1]
#               end
#             end
#             fail "Error..!! #{trans_type[1]} test data is not available in from account" if same_curreny_amount==[]
#             puts "same_curreny_amount #{same_curreny_amount}"
#              max_amount_index=all_amount.index same_curreny_amount.max
#              puts "max_amount_index  #{max_amount_index}"
#              max_amount=10
#             all_amount[max_amount_index.to_i].delete! ","
#             max_amount=all_amount[max_amount_index.to_i].to_i if all_amount[max_amount_index.to_i].to_i<10
#          $browser.find(:xpath, "//*[@class='ui-menu ui-corner-bottom ui-widget ui-widget-content']/li[#{max_amount_index.to_i+2}]").click 
#           enter_amount(max_amount)
#            $browser.fill_in find_xpath("description_entery_field"), :with => "Selenium UI Automation Testing"
#            @payee_data<<"Selenium UI Automation Testing"
#            wait_for_ajax
#            stop "Defect..!! System is not displaying" if ! $browser.has_xpath?(find_xpath("POP"), :text => 'Select Purpose')
#            $browser.find(:xpath, find_xpath("POP"), :text => 'Select Purpose').click 
#            @payee_data<<$browser.find(:xpath, find_xpath("POP_1")).text
#            $browser.find(:xpath, find_xpath("POP_1")).click
#            if ($framework["region"]== "AE")
#               wait_for_ajax
#               stop "Defect..!! Bank Charges have not been displayed" if !$browser.has_xpath?(find_xpath("bank_charges"))
#               bank_charges=$browser.find(:xpath, find_xpath("bank_charges")).text
#               wait_for_ajax
#               $browser.find(:xpath, find_xpath("bank_charges_paid_by_selection")).click 
#                @payee_data << bank_charges
#               wait_for_ajax
#               type=transaction_type== "BEN" ? 'Only the recipient' : "OUR" ? 'Only you' : 'You and the recipient'
#               $browser.find(:xpath, "//div[@class='ui-menu-item-wrapper'][contains(., '#{type}')]").click
#             end
#              wait_for_ajax
#              if trans_type[0]!=trans_type[1]
#               sleep 5
#                stop "Defect..!! exchanage rates have not been displayed for FCY to LCY" if !$browser.has_xpath?(find_xpath("exchange_rate_value"))
#                   @payee_data<<$browser.find(:xpath, find_xpath("exchange_rate_value")).text
#                stop "Defect..!! exchange rate amount have not been displayed for same FCY to LCY" if !$browser.has_xpath?(find_xpath("exchange_rate_amount"))
#                   @payee_data<<$browser.find(:xpath, find_xpath("exchange_rate_amount")).text
#               end
#               wait_for_ajax
#               sleep 5
#             $browser.find(:xpath, find_xpath("next")).click
#             wait_for_ajax
#             sleep 20
#             review_the_transaction
#             sleep 15
#             wait_for_ajax
#             conformation_of_transaction
#             wait_for_ajax
#             puts "*** Successfully Completed Trasaction with  #{transaction_type}  ***"
#             wait_for_ajax
#             sleep 5
#    end

#    def international_our_ben_sha_validation
   
#    end

def inft_xbt_transfer_our_ben_sha(currency_type, transfer_type, paid_by)
  @payee_data=[]
  sleep 10
  trans_type=currency_type.split("-")
  wait_for_ajax
  sleep 5
  @from_account_currency=trans_type[0]
  @to_account_currency=trans_type[1]
  
  @bene=transfer_type+" Valid "+trans_type[1]

  # Get the Payee Name based on the Row Number
  table=$browser.find(:css, find_xpath("bene_tabel"))
  row_count=(table.all(:css,'tr').size)-1
  raise "International Payee records are not available to proceed further !! " if row_count.eql?(0)
  
    for i_count in 1..row_count do
      @is_valid=0
      @payee_name=$browser.find(:xpath,"//*[@id='form-item-20']/table[1]/tbody/tr[#{i_count}]/td[1]").text
        if @payee_name.eql? @bene
           @is_valid=1
           payee_screen_data_capture(i_count)
           $browser.find(:xpath,"//*[@id='form-item-20']/table[1]/tbody/tr[#{i_count}]/td[1]").click
           break
        end
    end
    fail "Error..!! There is specific PAYEE test data for Automation..
    Please Do Create PAYEE with Payee Name '#{@bene}' for #{$framework["region"]} 
    " if (@is_valid!=1)

  wait_for_ajax
  sleep 10
  $browser.find(:xpath, find_xpath("next")).click
  wait_for_ajax
  from_screen_data_capture
  from_screen_data_validation
  $browser.find(:xpath, find_xpath("select_Account")).click
  p drop_down_data= $browser.find(:xpath, find_xpath("drop_down_box")).text
  to_account_data=drop_down_data.split(" ")
  currecy_type=[]; all_amount=[];same_curreny_amount=[]
        to_account_data.each_with_index do |e,i|
          if e.include? "."
            all_amount<<e
             currecy_type<<to_account_data[i-1] 
             same_curreny_amount<<e if trans_type[0]==to_account_data[i-1]
          end
        end
  fail "Error..!! #{trans_type[1]} test data is not available in from account" if same_curreny_amount==[]
  puts "same_curreny_amount #{same_curreny_amount}"
  max_amount_index=all_amount.index same_curreny_amount.max
  puts "max_amount_index  #{max_amount_index}"
  max_amount=5
  all_amount[max_amount_index.to_i].delete! ","
  max_amount=all_amount[max_amount_index.to_i].to_i if all_amount[max_amount_index.to_i].to_i<5
  $browser.find(:xpath, "//*[@class='ui-menu ui-corner-bottom ui-widget ui-widget-content']/li[#{max_amount_index.to_i+2}]").click 
  enter_amount(max_amount) # Enter Amount by calling this method
  sleep 5
  # Return the $payment_amount value from enter_amount method.Get Payment Amount
  $get_txn_details_ref << (trans_type[1]+" "+$payment_amount) # Get Currency and Amount Reference

  $browser.fill_in find_xpath("description_entery_field"), :with => $payment_txn_ref # Set Payment Reference
  $get_txn_details_ref << $payment_txn_ref # Get Payment Reference

  wait_for_ajax
  stop "Defect..!! Bank Charges have not been displayed" if !$browser.has_xpath?(find_xpath("bank_charges"))

  wait_for_ajax   
  # Get the Bank Charges if displayed for default to be paid by value
  sleep 10
  @bank_charges=$browser.find(:xpath, find_xpath("bank_charges")).text

  # If the Bank Charges are 0.00, then To Be Paid By Field should not be applicable
    if @bank_charges.include? ("0.00")
       @concat_charges=(@bank_charges+" (Not Applicable)") # Concat the Charge Amount and Paid By                      
    else
      # Get To Be Paid By Field
      if (%w(INFT XBT).include? transfer_type)
            $browser.find(:xpath, find_xpath("bank_charges_paid_by_selection")).click 
            to_be_paid_by=paid_by== "BEN" ? 'Only the recipient' : paid_by=="OUR" ? 'Only you' : paid_by=="SHA" ? 'You and the recipient' : "Selection Type not available"
            wait_for_ajax
            $browser.find(:xpath, "//div[@class='ui-menu-item-wrapper'][contains(., '#{to_be_paid_by}')]").click
            sleep 10
            @bank_charges=$browser.find(:xpath, find_xpath("bank_charges")).text
            sleep 6
            puts "@bank_charges Captured :: #{@bank_charges}" 
              if(paid_by=="BEN" && (@bank_charges.include? "#{@to_account_currency}"))
              @bank_charges_paid_by=$browser.find(:xpath, find_xpath("bank_charges_paid_by_selection")).text # Get Paid By Value
              p "Bank Charges Paid By:: #{paid_by} - #{@bank_charges_paid_by}"
              elsif ((paid_by=="SHA" || paid_by=="OUR") && (@bank_charges.include? "#{@from_account_currency}"))
              @bank_charges_paid_by=$browser.find(:xpath, find_xpath("bank_charges_paid_by_selection")).text # Get Paid By Value
              p "Bank Charges Paid By:: #{paid_by} - #{@bank_charges_paid_by}"
              else
              stop "Bank Charges are not being displayed for To Be Paid By Value :: #{to_be_paid_by}"
              end
              @concat_charges=(@bank_charges+" (To be paid by "+@bank_charges_paid_by+")") # Concat the Charge Amount and Paid By
      end
    end
          #   if (%w(INFT XBT).include? transfer_type)
          #     $browser.find(:xpath, find_xpath("bank_charges_paid_by_selection")).click 
          #     to_be_paid_by=paid_by== "BEN" ? 'Only the recipient' : paid_by=="OUR" ? 'Only you' : paid_by=="SHA" ? 'You and the recipient' : "Selection Type not available"
          #     wait_for_ajax
          #     $browser.find(:xpath, "//div[@class='ui-menu-item-wrapper'][contains(., '#{to_be_paid_by}')]").click
          #     sleep 3
          #     @bank_charges=$browser.find(:xpath, find_xpath("bank_charges")).text
          #     sleep 6
          #   end
          #     @bank_charges_paid_by=$browser.find(:xpath, find_xpath("bank_charges_paid_by_selection")).text # Get Charges
          #     wait_for_ajax
          #     @concat_charges=(@bank_charges+" (To be paid by "+@bank_charges_paid_by+")") # Concat the Charge Amount and Paid By
          #     sleep 3
          # end

          $get_txn_details_ref << @concat_charges

          if trans_type[0]!=trans_type[1]
            sleep 5
            stop "Defect..!! exchanage rates have not been displayed for #{currency_type}" if !$browser.has_xpath?(find_xpath("exchange_rate_value"))
            @exchange_rate_value=$browser.find(:xpath, find_xpath("exchange_rate_value")).text
            stop "Defect..!! exchange rate amount have not been displayed for  #{currency_type}" if !$browser.has_xpath?(find_xpath("exchange_rate_amount"))
            @exchange_rate_amount=$browser.find(:xpath, find_xpath("exchange_rate_amount")).text
      
            @exchange_rate_value = @exchange_rate_value.split(/\= /)
            @exchange_rate_value = @exchange_rate_value[1]
            
            @exchange_rate_amount = @exchange_rate_amount.split(/\= /)
            @exchange_rate_amount = @exchange_rate_amount[1]
      
            # Get Exchange Rate Amount and Value
            $get_txn_details_ref <<  @exchange_rate_amount+" (Indicative Exchange Rate = "+@exchange_rate_value+")"
            sleep 5
            else
            puts "Exchange Rate and Indicative Exchange Rate are not displayed for #{transfer_type} Transaction-Same Currency #{currency_type}"
          end

          # if trans_type[0]!=trans_type[1]
          #   sleep 5
          #   stop "Defect..!! exchanage rates have not been displayed for #{currency_type}" if !$browser.has_xpath?(find_xpath("exchange_rate_value"))
          #   @exchange_rate_value=$browser.find(:xpath, find_xpath("exchange_rate_value")).text
          #   stop "Defect..!! exchange rate amount have not been displayed for  #{currency_type}" if !$browser.has_xpath?(find_xpath("exchange_rate_amount"))
          #   @exchange_rate_amount=$browser.find(:xpath, find_xpath("exchange_rate_amount")).text
          # end
            wait_for_ajax
            
            # Select Purpose of Payment
          if trans_type[1] == "INR"
            $browser.find(:xpath,find_xpath("click_pop_dropdown")).click
            @pop_codes=$browser.find(:xpath,find_xpath("collect_pop_values")).all('li').collect(&:text)
            #@pop_codes=@pop_codes(1..@pop_codes.length)
            @pop_index=rand (1..@pop_codes.length)
            $browser.find(:xpath,"//div[@class='ui-menu-item-wrapper'][contains(text(),'#{@pop_codes[@pop_index]}')]").click
            $get_txn_details_ref << @pop_codes[@pop_index] 
          end
  
  wait_for_ajax

  # @exchange_rate_value = @exchange_rate_value.split(/\= /)
  # @exchange_rate_value = @exchange_rate_value[1]

  # @exchange_rate_amount = @exchange_rate_amount.split(/\= /)
  # @exchange_rate_amount = @exchange_rate_amount[1]

  # # Get Exchange Rate Amount and Value
  # $get_txn_details_ref <<  @exchange_rate_amount+" (Indicative Exchange Rate = "+@exchange_rate_value+")"
  # sleep 5

  post_txn_amount_validation($get_txn_details_ref) # Call Post Txn Amount Validation
  
  $browser.find(:xpath, find_xpath("next")).click
  wait_for_ajax
  sleep 20
  review_the_transaction # Review the Transaction
  sleep 15
  wait_for_ajax
  conformation_of_transaction # Confirm the Txn and Capture the Txn Referencce Number
  puts "*** Successfully Completed #{transfer_type} Trasaction with #{currency_type} ***"        
end

end
