class Creditcard < TransactionLibrary
	include Handler
  include WaitForAjax
 


def initialize
	  super
	    @xpath = {

            #### OAFT_Cash_Advance
                         "csl_landing_page"                  => "//div[@id='main']",
                  	     "oaft_to_account"                   => "//span[@class='select-menu-toggle-icon']",
                         "select_oaft_to_account"            => "//*[@id='form-item-24']/div/ul/li[1]/ul/li[1]",               
                         "to_account_list"                   => "//ul[@class='select-menu-menu']",       
                         "oaft_from_account"                 => "//span[@class='ui-selectmenu-button ui-selectmenu-button-closed ui-corner-all ui-button ui-widget']",                                                                           
                         "from_account_list"                 => "//ul[@class='ui-menu ui-corner-bottom ui-widget ui-widget-content']" ,
                         "select_oaft_from_account"          => "ui-id-15", 
                         "currency_value"                    => "transferAmount-amount",
                         "description_entery_field"          => "description",
                         "next_button"                       => "//button[@type='submit']",
                         "accept_terms"                      => "//input[@type='checkbox']" ,     
                         "finish_close_button"               => "//button[@class='btn btn-primary btn-block']",
                         "error_message"                     => "//div[@class='message ng-binding']",
                         "reference_number"                  => "//div[@id='main']/div/div[2]/div[2]/div/div[1]/div[2]",
                         "account_to_be_transfered"          => "//div[@id='main']/div/div[2]/div[2]/div/div[2]/div[2]" ,
                         "account_to_be_transfered_from"     => "//div[@id='main']/div/div[2]/div[2]/div/div[3]/div[2]", 
                         "currency_amount"                   => "//div[@id='main']/div/div[2]/div[2]/div/div[4]/div[2]" ,
                         "make_another_transfer"             => "//button[@class='btn btn-secondary btn-block']"  ,
                         "exchange_rate_value"               => "//div[@class='exchange-rate-rate ng-binding']",
                         "exchange_rate_amount"              => "//div[@class='exchange-rate-amount ng-binding']",
                         "back_button"                       => "//button[@class='btn btn-default btn-block form-item form-item-back form-type-back']" ,
                         "Dashboard"                         => "//div[@id='dashboard']",

                   ### Cash_In_Advance
                         "INFT_First_Account"               => "//*[@id='form-item-20']/table[1]/tbody/tr[1]"  , 
                         "INFT_Container"                   => "//table[@class='table table-hover table-bordered hidden-xs ng-scope']",
                         "click_Drop_down"                  => "//span[@class='ui-selectmenu-button ui-selectmenu-button-closed ui-corner-all ui-button ui-widget']",
                         "list_of_account_INFT"             => "//ul[@class='ui-menu ui-corner-bottom ui-widget ui-widget-content']",
                         "confirm_transfer_message"         => "//div[@class='alert alert-success ng-scope']",
                }

	end


def global_account(browser, currency_type)
    puts "To Account Drown down is displaying" if browser.has_xpath?(find_xpath("oaft_to_account")) 
    sleep 8    
    browser.find(:xpath, find_xpath("oaft_to_account")).click  
  to_account_data = browser.find(:xpath, find_xpath("to_account_list")).text       
      to_currency_value = []; local_difference=[]; 
          for global_value in 0...to_account_data.length            
                if to_account_data[global_value]== 'G'
                  global_value_data = global_value if to_account_data[global_value+1] == 'l'
                  break if to_account_data[global_value+2]== 'o'                                
                end
          end                
       to_account_data_list = to_account_data[global_value_data..to_account_data.length].split(" ")              
         @to_act_pos=1                  
        for index in 0...to_account_data_list.length  
          if to_account_data_list[index].include? '.'                                                      
                  if currency_type == 'global' && to_account_data_list[index-1] != "#{$framework['region']+'D'}" && to_account_data_list[index] != "0.00" 
                      to_currency_value << to_account_data_list[index-1] if to_account_data_list[index-1] != "#{$framework['region']+'D'}" && to_account_data_list[index] != "0.00"                                          
                      to_account_value = to_account_data_list[index]
                      break if to_account_data_list[index-1] != "#{$framework['region']+'D'}"               
                  elsif currency_type == 'same' && to_account_data_list[index-1] == "#{$framework['region']+'D'}" && to_account_data_list[index] != "0.00"
                       to_currency_value << to_account_data_list[index-1] if to_account_data_list[index-1] == "#{$framework['region']+'D'}" && to_account_data_list[index] != "0.00"                                                                     
                       to_account_value = to_account_data_list[index]
                       break if to_account_data_list[index-1] == "#{$framework['region']+'D'}"                     
                  end  
                   wait_for_ajax  
          @to_act_pos=@to_act_pos+1                                                                                                                 
         end           
      end     
      puts "To_Currency_Type:: #{to_currency_value}"  
      fail "!!!Test Data Issue!!! There is no GLFT test data" if to_account_value.nil?
      browser.find(:xpath, "//div[@class='ng-binding ng-scope'][contains(text(),'#{to_account_value}')]").click                   
     ##################From Account List###################
    browser.find(:xpath, find_xpath("oaft_from_account")).click  
     wait_for_ajax    
    from_account_data = browser.find(:xpath, find_xpath("from_account_list")).text  
    from_account_data_list = from_account_data.split(" ")    
          @payee_currency_type = []; @from_account_number = [];       
            from_account_data_list.each_with_index do |type, index|                       
                        if type.include? "."                      
                          @payee_currency_type << from_account_data_list[index-1]
                          @from_account_number << from_account_data_list[index-3]
                        end                   
            end        
          puts "To_Account_Number:: #{@from_account_number}"
            for index in 0...@from_account_number.size
                  @credit_card_number = @from_account_number[index] if @from_account_number[index].size > 15
                  break if @from_account_number[index].size > 15
            end
            fail "!!!Defect!!! Credit card data is present for Global Accounts" if !@credit_card_number.nil?                
            puts "!!!Perfect!!! User should not able to perform credit card transaction for global accounts" if @credit_card_number.nil?
end


def cash_in_advance_OAFT(browser, currency_type)
    puts "#" * 50  
    puts "Transaction_Type:: #{currency_type}"  
    wait_for_ajax       
    sleep 10   
    puts "To Account Drown down with account numbers are displaying" if browser.has_xpath?(find_xpath("oaft_to_account"))               
    browser.find(:xpath, find_xpath("oaft_to_account")).click   
    # browser.find("main").native.send_keys :tab
    # wait_for_ajax 
    # browser.find("main").native.send_keys :enter 
    wait_for_ajax     
    @to_act_pos=1
    to_account_data = browser.find(:xpath, find_xpath("to_account_list")).text     
    to_account_data_list = to_account_data.split(" ")   
    to_currency_value = [];      
        for index in 0...to_account_data_list.length   
           if to_account_data_list[index].include? '.'                        
              if currency_type == 'cross' && to_account_data_list[index-1] != "#{$framework['region']+'D'}" && to_account_data_list[index] != "0.00" 
                  to_currency_value << to_account_data_list[index-1] if to_account_data_list[index-1] != "#{$framework['region']+'D'}" && to_account_data_list[index] != "0.00"                    
                  to_account_value = to_account_data_list[index]                
                  break if to_account_data_list[index-1] != "#{$framework['region']+'D'}" && to_account_data_list[index] != "0.00"                                
              elsif currency_type == 'same' && to_account_data_list[index-1] == "#{$framework['region']+'D'}" && to_account_data_list[index] != "0.00"
                   to_currency_value << to_account_data_list[index-1] if to_account_data_list[index-1] == "#{$framework['region']+'D'}" && to_account_data_list[index] != "0.00"               
                   to_account_value = to_account_data_list[index]                   
                  break if to_account_data_list[index-1] == "#{$framework['region']+'D'}" && to_account_data_list[index] != "0.00"                             
              end 
             @to_act_pos=@to_act_pos+1                        
          end   
      end 
      puts "To_Currency_Type:: #{to_currency_value}"  
      browser.find(:xpath, "//div[@class='ng-binding ng-scope'][contains(text(),'#{to_account_value}')]").click                   
     ##################From Account List###################
    browser.find(:xpath, find_xpath("oaft_from_account")).click  
     wait_for_ajax    
    from_account_data = browser.find(:xpath, find_xpath("from_account_list")).text  
    from_account_data_list = from_account_data.split(" ")      
          @payee_currency_type = []; @from_account_number = [];       
            from_account_data_list.each_with_index do |type, index|                       
                        if type.include? "."                      
                          @payee_currency_type << from_account_data_list[index-1]
                          @from_account_number << from_account_data_list[index-3]
                        end                   
            end        
          puts "To_Account_Number:: #{@from_account_number}"
            for index in 0...@from_account_number.size
                  @credit_card_number = @from_account_number[index] if @from_account_number[index].size > 15
                  break if @from_account_number[index].size > 15
            end
            fail "!!!Test Data Issue!!! There is no Creditcard data is present" if @credit_card_number.nil?
            puts "@credit_card_number:: #{@credit_card_number}"        
            puts "from_currency_type:: #{@payee_currency_type}"                  
            @act_pos = @from_account_number.index "#{@credit_card_number}" 
            puts "@act_pos:: #{@act_pos}" 
     browser.find(:xpath, "//div[@class='ui-selectmenu-menu ui-front ui-selectmenu-open']//li[#{@act_pos}+2]").click
     wait_for_ajax    
     browser.fill_in find_xpath("currency_value"), :with => 1
     wait_for_ajax   
     browser.fill_in find_xpath("description_entery_field"), :with => "Selenium UI Automation Testing"
     wait_for_ajax    
     browser.find(:xpath, find_xpath("next_button")).click 
     wait_for_ajax  
     confirm_message = browser.find(:xpath, find_xpath("confirm_transfer_message")).text
     puts "!!!Confirm_Message!!! Displaying successfully!!!" if confirm_message.include?("Please confirm the details of your transfer")
     wait_for_ajax       
     browser.find(:xpath, find_xpath("accept_terms")).click if $framework['region'] == 'AE'
     wait_for_ajax   
     browser.find(:xpath, find_xpath("next_button")).click 
     wait_for_ajax           
  end  


  def credit_card_inft(browser)
   wait_for_ajax 
   browser.find(:xpath, find_xpath("INFT_First_Account")).click     
   sleep 8
   browser.find(:xpath, find_xpath("next_button")).click if browser.has_xpath?(find_xpath("next_button"))   
   wait_for_ajax
   browser.find(:xpath, find_xpath("click_Drop_down")).click 
   wait_for_ajax 
   inft_account_number = []
   list_of_data = browser.find(:xpath, find_xpath("list_of_account_INFT")).text
   test_data = list_of_data.split(' ')  
    for value in 0...test_data.length
        if test_data[value].include? '.'
          inft_account_number << test_data[value-3] if test_data[value-1] == "#{$framework['region']+'D'}" && test_data[value] != "0.00"
        end
    end 
   # browser.find(:xpath, "//div[@class='ui-menu-item-wrapper'][contains(text(),'#{inft_account_number[0]}')]").click                   
    puts "INFT_Account_From_Numbers :: #{inft_account_number}" 
            for index in 0...inft_account_number.size
                  @credit_card_number = inft_account_number[index] if inft_account_number[index].size > 15
                  break if inft_account_number[index].size > 15
            end
    fail "!!!Defect!!! Credit card data is present for INFT Accounts" if !@credit_card_number.nil?                
    puts "!!!Perfect!!! Credit card data is not present under INFT transaction" if @credit_card_number.nil?
  end 

end
