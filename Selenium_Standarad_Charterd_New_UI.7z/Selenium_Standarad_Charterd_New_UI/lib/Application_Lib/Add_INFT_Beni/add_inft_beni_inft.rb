class Beni
	include Handler
  include WaitForAjax
 


def initialize
	  super
	    @xpath = {            

                   ### INFT_add_payee
                         "Add_Beni_button"                  => "//button[@class='btn btn-primary btn-sm']",
                         "radio_button"                     => "//input[@value='search']",
                         "select_country"                   => "//span[@class='ui-selectmenu-button ui-selectmenu-button-closed ui-corner-all ui-button ui-widget']",
                         "select_bank"                      => "//div[@class='form-type-select bank-select']",
                         "search_button"                    => "//button[@class='btn btn-block btn-primary ng-scope']" ,
                         "select_UAE"                       => "//div[@class='ui-menu-item-wrapper'][contains(text(),'Emirates')]",
                         "select_branch"                    => "//option[@label='Abraaj Capital Limited']",
                         "select_branch_radio"              => "//input[@name='bankBranchBic']",
                         "next_button"                      => "//button[@type='submit']" ,
                         "payee_name"                       => "name",
                         "payee_country"                    => "//div[@class='ui-menu-item-wrapper'][contains(text(),'Emirates')]",                          
                         "payee_address"                    => "address-address1" ,                        
                         "payee_account_number"             => "accountNumber",
                         "iban_Number"                      => "//input[@name='accountNumber']" ,
                         "payee_account_currency"           => "//span[@class='ui-selectmenu-button ui-selectmenu-button-closed ui-corner-all ui-button ui-widget']",
                         "terms_conditions"                 => "//input[@type='checkbox']",
                         "INFT_First_Account"               => "//*[@id='form-item-20']/table[1]/tbody/tr[1]"  , 
                         "INFT_Container"                   => "//table[@class='table table-hover table-bordered hidden-xs ng-scope']",
                         "click_Drop_down"                  => "//span[@class='ui-selectmenu-text'][contains(text(),'Select Country')]",
                         "list_of_account_INFT"             => "//ul[@class='ui-menu ui-corner-bottom ui-widget ui-widget-content']",
                         "confirm_transfer_message"         => "//div[@class='alert alert-success ng-scope']",
                         "secure_password"                  => "//input[@type='password']"  ,
                         "secure"                           => ".//input",
                         "confirm_message"                  => "//div[@class='message ng-binding']",
                         "transfer_to_internation_account"  => "//button[@class='btn btn-primary btn-block']",
                         "manage_payee_button"              => "//button[@class='btn btn-secondary btn-block']" ,
                         "add_inft_payee"                   => "//*[@id='btn-contacts-intl']",
                         "finish_close_button"              => "//i[@ng-click='closeForm()']",                         

                         ###INFT_Page

                         "Total_page"                       => "//tbody[@class='ng-scope']",
                         "first_account_number"             => "//*[@id='form-item-20']/table[1]/tbody/tr[1]/td[3]"

                }

	end


def add_inft(currency_type)
    wait_for_ajax
    puts "#" * 50
    $browser.find(:xpath, find_xpath("Add_Beni_button")).click 
    wait_for_ajax
    $browser.find(:xpath, find_xpath("radio_button"), visible: false).set(true)    
    wait_for_ajax
    sleep 3
    $browser.find(:xpath, find_xpath("select_country")).click 
    wait_for_ajax
    $browser.find(:xpath, find_xpath("select_UAE")).click 
    wait_for_ajax
    sleep 4
    $browser.find(:xpath, find_xpath("select_bank")).click 
    wait_for_ajax
    $browser.find(:xpath, find_xpath("select_branch")).click 
    wait_for_ajax
    $browser.find(:xpath, find_xpath("search_button")).click 
    wait_for_ajax
    $browser.find(:xpath, find_xpath("select_branch_radio"), visible: false).set(true)   
    wait_for_ajax
    $browser.find(:xpath, find_xpath("next_button")).click 
    wait_for_ajax
    sleep 4
    # $browser.fill_in find_xpath("payee_name"), :with => "Auto INFT #{currency_type}"
    $browser.fill_in find_xpath("payee_name"), :with => "INFT Valid #{currency_type}"
    wait_for_ajax
    $browser.find(:xpath, find_xpath("click_Drop_down")).click 
    wait_for_ajax
    $browser.find(:xpath, find_xpath("payee_country")).click 
    wait_for_ajax
    $browser.fill_in find_xpath("payee_address"), :with => "Alibaba Street 5"
    wait_for_ajax
    $browser.fill_in find_xpath("payee_account_number"), :with => add_inft_beni
    wait_for_ajax    
    puts "$iban_Number :: #{$iban_Number }"
    wait_for_ajax
    $browser.find(:xpath, find_xpath("payee_account_currency")).click 
    wait_for_ajax
    $browser.find(:xpath, "//div[@class='ui-menu-item-wrapper'][contains(text(), '#{currency_type}')]").click 
    wait_for_ajax  
    # $browser.find(:xpath, find_xpath("terms_conditions")).click
    $browser.find(:xpath, find_xpath("next_button")).click 
    wait_for_ajax
    sleep 3  
    $browser.find(:xpath, find_xpath("next_button")).click 
    wait_for_ajax
    sleep 5 
   if $framework['region'] == 'AE' 
          otp = get_otp_and_fill_cls('add_TT', amount = '', "INFT Valid #{currency_type}")
          puts "otp:: #{otp}"
          wait_for_ajax
          sleep 4
          $browser.find(:xpath, find_xpath("secure_password")).click 
          wait_for_ajax
          $browser.find(:xpath, find_xpath("secure")).set ("#{otp}")
          wait_for_ajax
          $browser.find(:xpath, find_xpath("next_button")).click 
          sleep 3  
    end       
          puts "!!!Successfully User able to add New INFT beny!!!" if ($browser.find(:xpath, find_xpath("confirm_message")).text).include?"Your new payee has been added successfully"   

end


def validate_inft_page(iban_Number)  
    wait_for_ajax
    sleep 2
    puts "!!!Successfully New Beny details are displaying under INFT transaction page!!!" if $browser.find(:xpath, "//td[@class='account-number'][contains(text(), '#{iban_Number}')]").visible?
    fail "!!!Error!!! Newly Added INFT beny is not displaying in INFT transaction page" if !$browser.find(:xpath, "//td[@class='account-number'][contains(text(), '#{iban_Number}')]").visible?
    puts "#" * 50
end

def duplicate_iban
wait_for_ajax
    puts "#" * 50
    account_number = $browser.find(:xpath, find_xpath("first_account_number")).text
    wait_for_ajax
    puts "account_number:: #{account_number}"
    $browser.find(:xpath, find_xpath("Add_Beni_button")).click 
    wait_for_ajax
    $browser.find(:xpath, find_xpath("radio_button"), visible: false).set(true)    
    wait_for_ajax
    sleep 3
    $browser.find(:xpath, find_xpath("select_country")).click 
    wait_for_ajax
    $browser.find(:xpath, find_xpath("select_UAE")).click 
    wait_for_ajax
    sleep 4
    $browser.find(:xpath, find_xpath("select_bank")).click 
    wait_for_ajax
    $browser.find(:xpath, find_xpath("select_branch")).click 
    wait_for_ajax
    $browser.find(:xpath, find_xpath("search_button")).click 
    wait_for_ajax
    $browser.find(:xpath, find_xpath("select_branch_radio"), visible: false).set(true)   
    wait_for_ajax
    $browser.find(:xpath, find_xpath("next_button")).click 
    wait_for_ajax
    sleep 4
    $browser.fill_in find_xpath("payee_name"), :with => "Duplicate IBAN validation"
    wait_for_ajax
    $browser.find(:xpath, find_xpath("click_Drop_down")).click 
    wait_for_ajax
    $browser.find(:xpath, find_xpath("payee_country")).click 
    wait_for_ajax
    $browser.fill_in find_xpath("payee_address"), :with => "Alibaba Street 5"
    wait_for_ajax
    $browser.fill_in find_xpath("payee_account_number"), :with => account_number
    wait_for_ajax           
    $browser.find(:xpath, find_xpath("payee_account_currency")).click 
    wait_for_ajax
    $browser.find(:xpath, "//div[@class='ui-menu-item-wrapper'][contains(text(), 'AUD')]").click 
    wait_for_ajax  
    # $browser.find(:xpath, find_xpath("terms_conditions")).click
    $browser.find(:xpath, find_xpath("next_button")).click 
    wait_for_ajax
    sleep 3  

end 

end
