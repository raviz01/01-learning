require 'HTTParty'

# def header_request
#   super
#   @header_request= {  
#    "user":{  
#       "uaas2id":"8631148602",
#       "relId":"01300000384",
#       "country":"CN",
#       "language":"en",
#       "segCd":"EXBN"
#    },
#    "client":{  
#       "clientRequestId":"ccmbr-req-20170125173729234",
#       "trueClientIP":"219.76.10.77;59.189.232.132, 59.189.232.132",
#       "sessionId":"JOlAYX3o6D3pVz12kyiv9Y1",
#       "userAgent":"Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML,like Gecko) Chrome/47.0.2526.106",
#       "channel":"IBNK",
#        "deviceTy":"IPAD"
#              }
# }
#  end


def landing_directly_to_csl(transfer_type, country)
    # show "Landing directly to csl thru SSO"
     proxy = URI("http://10.112.112.73:8080")
     
          # @header_request = "AID=1|UID=USER01S2607093G|CID=01S2607093G|EBID=6557522744|NAME=TestName|CTRY=#{country}|LANG=EN|APP=OFX|is2FAAuthenticated=true|Segment=EXBN" if #{country} == "SG"
        # @header_request = "AID=1|UID=01S0019376C|CID=01S0019376C|EBID=6578782739|NAME=TestName|CTRY=#{country}|LANG=EN|APP=OFX|is2FAAuthenticated=true|Segment=EXBN" if #{country} == "SG"
           # @header_request = "AID=1|UID=01S2062552Z|CID=01S2062552Z|EBID=6519035191|NAME=TestName|CTRY=#{country}|LANG=EN|APP=OFX|is2FAAuthenticated=true|Segment=EXBN" if #{country} == "SG"  
           # @header_request = "AID=1|UID=01S6945770C|CID=01S6945770C|EBID=6573349539|NAME=TestName|CTRY=#{country}|LANG=EN|APP=OFX|is2FAAuthenticated=true|Segment=EXBN" if #{country} == "SG"  

        # @header_request = "AID=1|UID=209274375|CID=1209274375|EBID=0209274375|NAME=TestName|CTRY=#{country}|LANG=EN|APP=OFX|is2FAAuthenticated=true|Segment=01" if #{country} == "AE"
         # @header_request = "AID=1|UID=202001090|CID=202001090|EBID=0202001090|NAME=TestName|CTRY=AE|LANG=EN|APP=OFX|is2FAAuthenticated=true|Segment=01" if #{country} == "AE"       

# @header_request="AID=1|UID=01300000384|CID=01300000384|EBID=8631148602|NAME=TestName|CTRY=CN|LANG=zh_CN|APP=OFX|is2FAAuthenticated=true|Segment=EXBN"
@header_request= "AID=1|UID=300005718|CID=01300005718|EBID=8616421019|NAME=TestName|CTRY=CN|LANG=en|APP=OFX|is2FAAuthenticated=true|Segment=EXBN"
    uri = URI("http://10.20.234.11:8686/retail/api/v1/security/auth/ssoRequestMock")   
    # uri = URI("https://10.20.234.17:10083/retail/api/metadata/ssorouting/SG-NFS-OFX")

    # options =   {http_proxyaddr: proxy.host,http_proxyport:proxy.port,verify:false} 
    @http_response = HTTParty.get(uri,
                   http_proxyaddr: proxy.host, http_proxyport:proxy.port, verify:false,
                  :headers => { 
                                              
                                              "Accept" => "application/json", 
                                              "SIGNON_TOKEN" => @header_request

                                  }
                              
                                  )  
                                  puts "SSO :#{@http_response['ssoCode']}"
own_acc_transfer="https://uat.sc.com/retail/api/v1/security/auth/ssoAuthorize?SSCode=#{@http_response['ssoCode']}&RedirPageId=ownAccTransfer" 
local_acc_transfer="http://10.20.234.11:8686/retail/api/v1/security/auth/ssoAuthorize?SSCode=#{@http_response['ssoCode']}&RedirPageId=localTransfer"
international_transfer="http://10.20.234.11:8686/retail/api/v1/security/auth/ssoAuthorize?SSCode=#{@http_response['ssoCode']}&RedirPageId=intlTransfer"
manage_bene="http://10.20.234.11:8686/retail/api/v1/security/auth/ssoAuthorize?SSCode=#{@http_response['ssoCode']}&RedirPageId=mngeBenef"
transfer_to=transfer_type=="Between Own Accounts" ? own_acc_transfer : transfer_type=="To Local Account" ? local_acc_transfer : transfer_type== "To International Account" ? international_transfer :  manage_bene
return transfer_to
end

puts landing_directly_to_csl("x", 'SG')

# http://10.20.234.11:8686/retail/api/v1/security/auth/ssoRequestMock
# def get_bene_details(beneTy)
# @header_request={  
#    "user"=>{  
#       "uaas2id"=>"8631148602",
#       "relId"=>"01300000384",
#       "country"=>"CN",
#       "language"=>"en",
#       "segCd"=>"EXBN"
#    },
#     "client"=>{  
#       "clientRequestId"=>"ccmbr-req-20170125173729234",
#       "trueClientIP"=>"219.76.10.77;59.189.232.132, 59.189.232.132",
#       "sessionId"=>"JOlAYX3o6D3pVz12kyiv9Y1",
#       "userAgent"=>"Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML,like Gecko) Chrome/47.0.2526.106",
#       "channel"=>"IBNK",
#        "deviceTy"=>"IPAD"
#              }
# }


#   uri = URI("http://10.20.234.21:8186/retail/csl/v1/beneficiaries/benety/TPFTPAYEE")
#   puts 
#      @http_response = HTTParty.get(uri,
#            :body => nil,
#            :headers => { 
#                "Content-Type" => "application/json", 
#                "Accept" => "application/json", 
#                "CSL_HEADER" => @header_request.to_json 
#               }
#           )
#      puts @http_response
#  end  

# puts get_bene_details "IBFT"
