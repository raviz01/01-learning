module Handler
 
require 'capybara'
require 'selenium-webdriver'
require 'HTTParty'

   #Global Variable for Transactions
   $transaction_reference=""
   $payment_txn_ref="Selenium UI Automation Testing"
   $get_txn_details_ref=[] 

# $user = YAML.load_file('config/user.yml')
# $framework = YAML.load_file('config/framework.yml')
# $test_data = YAML.load_file('config/data/test_data.yml')

# def header_request
#   super
#   @header_request_2= {  
#    "user"=>{  
#       "uaas2id"=>#{$user[$framework["region"]][user]["EBID"]},
#       "relId"=>#{$user[$framework["region"]][user]["CID"]},
#       "country"=>#{$user[$framework["region"]][user]["CTRY"]},
#       "language"=>#{$user[$framework["region"]][user]["LANG"]},
#       "segCd"=>#{$user[$framework["region"]][user]["Segment"]}
#    },
#    "client":{  
#       "clientRequestId":"ccmbr-req-20170125173729234",
#       "trueClientIP":"219.76.10.77;59.189.232.132, 59.189.232.132",
#       "sessionId":"JOlAYX3o6D3pVz12kyiv9Y1",
#       "userAgent":"Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML,like Gecko) Chrome/47.0.2526.106",
#       "channel":"IBNK",
#        "deviceTy":"IPAD"
#              }
# }
#  end
 
def find_xpath(element)
      @xpath[element]
end

def current_date
  value = Time.now.strftime("%d %b %Y")
  return value
end
  
def landing_directly_to_csl(user, transfer_type)    
        pop_up_message("Directly landing on CSL page") 
        @header_request = "AID=1|UID=#{$user[$framework["region"]][user]["UID"]}|CID=#{$user[$framework["region"]][user]["CID"]}|EBID=#{$user[$framework["region"]][user]["EBID"]}|NAME=TestName|CTRY=#{$user[$framework["region"]][user]["CTRY"]}|LANG=#{$user[$framework["region"]][user]["LANG"]}|APP=OFX|is2FAAuthenticated=true|Segment=#{$user[$framework["region"]][user]["Segment"]}"              
        puts "@header_request #{@header_request}"
        proxy = URI($user['proxy'])
        uri = URI($test_data["#{$framework["environment"]}"+"_sso_code_url"]) 
    @http_response = HTTParty.get(uri,
                   http_proxyaddr: proxy.host,http_proxyport:proxy.port,verify:false,
                  :headers => { 
                                              
                                              "Accept" => "application/json", 
                                              "SIGNON_TOKEN" => @header_request

                                  }
                              
                                  )
  if $framework["environment"]!="dev"
    own_acc_transfer="https://#{$framework["environment"]}.sc.com/retail/api/v1/security/auth/ssoAuthorize?SSCode=#{@http_response['ssoCode']}&RedirPageId=ownAccTransfer" 
    local_acc_transfer="https://#{$framework["environment"]}.sc.com/retail/api/v1/security/auth/ssoAuthorize?SSCode=#{@http_response['ssoCode']}&RedirPageId=localTransfer"
    international_transfer="https://#{$framework["environment"]}.sc.com/retail/api/v1/security/auth/ssoAuthorize?SSCode=#{@http_response['ssoCode']}&RedirPageId=intlTransfer"
    manage_bene="https://#{$framework["environment"]}.sc.com/retail/api/v1/security/auth/ssoAuthorize?SSCode=#{@http_response['ssoCode']}&RedirPageId=mngeBenef"
  else 
    own_acc_transfer="#{$test_data["dev_url"]}/retail/api/v1/security/auth/ssoAuthorize?SSCode=#{@http_response['ssoCode']}&RedirPageId=ownAccTransfer" 
    local_acc_transfer="#{$test_data["dev_url"]}/retail/api/v1/security/auth/ssoAuthorize?SSCode=#{@http_response['ssoCode']}&RedirPageId=localTransfer"
    international_transfer="#{$test_data["dev_url"]}/retail/api/v1/security/auth/ssoAuthorize?SSCode=#{@http_response['ssoCode']}&RedirPageId=intlTransfer"
    manage_bene="#{$test_data["dev_url"]}/retail/api/v1/security/auth/ssoAuthorize?SSCode=#{@http_response['ssoCode']}&RedirPageId=mngeBenef"    
  end
    transfer_to=transfer_type=="Between Own Accounts" ? own_acc_transfer : transfer_type=="To Local Account" ? local_acc_transfer : transfer_type== "To International Account" ? international_transfer :  manage_bene
    puts transfer_to
return transfer_to
end

# def get_bene_details()
#   # @header_request_2 = "AID=1|UID=#{$user[$framework["region"]][user]["UID"]}|CID=#{$user[$framework["region"]][user]["CID"]}|EBID=#{$user[$framework["region"]][user]["EBID"]}|NAME=TestName|CTRY=#{$user[$framework["region"]][user]["CTRY"]}|LANG=#{$user[$framework["region"]][user]["LANG"]}|APP=OFX|is2FAAuthenticated=true|Segment=#{$user[$framework["region"]][user]["Segment"]}"              
#   uri = URI("#{$test_data["dev_url"]}/beneficiaries/benety/#{beneTy}")
#      @http_response = HTTParty.get(uri,
#            :body => nil,
#            :headers => { 
#                "Content-Type" => "application/json", 
#                "Accept" => "application/json", 
#                "CSL_HEADER" => @header_request_2.to_json
#               }
#           )
#      puts @http_response
#  end  

def get_otp_and_fill(environment, country, user, url)
 user='01S6945770C'
        @opt=Capybara::Session.new(:selenium)
        @opt.visit url
        @opt.select environment, :from => @xpath["otp_env"]
        @opt.select country , :from =>     @xpath["otp_country"]
        # @opt.fill_in @xpath["user_id"], :with => user          
        @opt.find_button(@xpath["get_otp"]).click
        otp=@opt.find(:xpath, "//html/body/form/table[2]/tbody/tr[td[contains(., '#{user}')]]/td[4]", :match => :first).text
        otp.index('OTP is')+7      
        @otp_exact_value= otp[otp.index('OTP is')+7..(otp.index('OTP is')+7)+5]
        puts "otp_exact_value:: #{@otp_exact_value}"
        @opt.driver.browser.close
        return @otp_exact_value
end


def reference_data(data=nil)
    exe_data=[]
    exe_data << "#"*200
    exe_data << "\n hey..!!FYR below data has been used in the excution \n"
    exe_data<< "#{data} \n"
    exe_data << "#"*200
    return exe_data
end


 def get_otp_and_fill_cls(trans_type, amount='', beny_name=nil)  
        @opt=Capybara::Session.new(:selenium)       
        payee_type=trans_type == 'IBFT' ? 'InterBank Fund Transfer' : trans_type == 'TT' ? 'InterNational Fund Transfer' : trans_type == "TPFT" ? 'Third Party Fund Transfer' : trans_type == 'add_TT' ? "#{beny_name}" : 'adding'
      # payee_type=trans_type == "Between Own Accounts" ? own_acc_transfer : trans_type=="To Local Account" ? local_acc_transfer : trans_type== "To International Account" ? 'InterNational Fund Transfer' :  manage_bene
         puts "payee_type:: #{payee_type}"
         @opt.visit $user["csl_otp_url"]          
         @opt.execute_script("location.reload()")          
         @opt.execute_script("location.reload()")  
         @opt.execute_script("location.reload()") 
         sleep 5
         data=@opt.body
         otp_data=data[67..data.length-22]
         stop "OTP window is not having data" if otp_data==nil        
        b=otp_data.to_s.split("\n")      
        todays_transaction=[]   
        b.each do |str|                  
          if str.include? DateTime.now.strftime("%Y-%m-%d")                     
              if str.include? $user[$framework["region"]][$current_user_instance]["CID"]              
                if str.include?(amount) || str.include?(beny_name)                                   
                  todays_transaction<<str if str.include? payee_type                    
                end
             end          
         end 
        end             
          stop "Error..!! OTP is not generated"  if todays_transaction==[]
          last_tran_data=todays_transaction[todays_transaction.length-1].split(" ")                    
          otp=last_tran_data[(last_tran_data.index('is')).to_i+1]
          show otp.delete! '.'
          @opt.driver.browser.close
          return otp
    end

def add_inft_beni
  value = Time.now.strftime("%d%Y%H%L")
  text = value*2
  $iban_Number = "#{$framework['region']}"+text[0...text.length-1]   
  return $iban_Number
end  


end

