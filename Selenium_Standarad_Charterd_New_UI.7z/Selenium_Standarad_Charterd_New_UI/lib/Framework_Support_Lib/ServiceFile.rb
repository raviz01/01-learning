module ServiceFile

# require 'HTTParty' 

# def header_request
#   a="uaas2id"=>$user[$framework["region"]][user]["EBID"]
#   super
#   @header_request= {  
#    "user"=>{  
#       "uaas2id"=>#{$user[$framework["region"]][user]["EBID"]},
#       "relId"=>#{$user[$framework["region"]][user]["CID"]},
#       "country"=>#{$user[$framework["region"]][user]["CTRY"]},
#       "language"=>#{$user[$framework["region"]][user]["LANG"]},
#       "segCd"=>#{$user[$framework["region"]][user]["Segment"]}
#    },
#    "client":{  
#       "clientRequestId"=>"ccmbr-req-20170125173729234",
#       "trueClientIP"=>"219.76.10.77;59.189.232.132, 59.189.232.132",
#       "sessionId"=>"JOlAYX3o6D3pVz12kyiv9Y1",
#       "userAgent"=>"Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML,like Gecko) Chrome/47.0.2526.106",
#       "channel"=>"IBNK",
#        "deviceTy"=>"IPAD"
#              }
# }
#  end

# # @header_request = "AID=1|UID=#{$user[$framework["region"]][user]["UID"]}|CID=#{$user[$framework["region"]][user]["CID"]}|EBID=#{$user[$framework["region"]][user]["EBID"]}|NAME=TestName|CTRY=#{$user[$framework["region"]][user]["CTRY"]}|LANG=#{$user[$framework["region"]][user]["LANG"]}|APP=OFX|is2FAAuthenticated=true|Segment=#{$user[$framework["region"]][user]["Segment"]}"              

end