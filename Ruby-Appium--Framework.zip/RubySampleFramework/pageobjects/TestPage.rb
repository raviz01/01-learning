require './support/env'
class TestPage
    include PageObject

    page_url "http://www.google.com"

    element         :search,            :id=>"lst-ib"
    element         :sear_btn,          :id=>"_fZl"
end