Given(/^I am on google page$/) do
  visit_page(TestPage)
end

When(/^I tap on google$/) do
  @current_page.search_element.click
  @current_page.search_element.send_keys "56"
end

Then(/^i succeed$/) do

end