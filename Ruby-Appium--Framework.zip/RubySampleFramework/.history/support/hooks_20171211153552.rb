$LOAD_PATH << './pageobjects'
$LOAD_PATH << './library'
$LOAD_PATH << './library/utils'
$LOAD_PATH << './support'

require 'selenium-webdriver'
require 'rspec/expectations'

Before do |scenario|
  @log = Log.instance.start_new
  @log.instance_variable_set(:@cucumber_world, self)
  @browser = ''
  case ENV['PLATFORM'].upcase
    when 'MOBILE_WEBSITE'
      @device = YAML.load_file('config/devices.yml')["#{ENV['DEVICE']}"]
      p "Test Started:: Invoking #{@device['platformName']}  #{ENV['DEVICE']}  Chrome $browser..!"
      $extent_test.assign_category("UIAutomation - #{ENV['DEVICE']} Emulator/Simulator Mobile Website")
      if @device['platformName'] == "iOS"
        opts =
          {
            caps:
              {
                :browserName => "#{@device['browser']}",
                :platformName => "#{@device['platformName']}",
                :platformVersion => "#{@device['platformVersion']}",
                :newCommandTimeout => "#{@device['newCommandTimeout']}",
                :deviceName => "#{@device['deviceName']}",
                :udid => "#{@device['udid']}",
                :bootstrapPath => "/usr/local/lib/node_modules/appium/node_modules/appium-xcuitest-driver/WebDriverAgent",
                :agentPath => "/usr/local/lib/node_modules/appium/node_modules/appium-xcuitest-driver/WebDriverAgent/WebDriverAgent.xcodeproj"
              },
            appium_lib: { server_url: "http://127.0.0.1:4723/wd/hub", :port => "4723"}
          }
        else
          opts =
            {
            caps:
              {
                :browserName => "#{@device['browser']}",
                :platformName => "#{@device['platformName']}",
                :platformVersion => "#{@device['platformVersion']}",
                :newCommandTimeout => "#{@device['newCommandTimeout']}",
                :deviceName => "#{@device['deviceName']}"
              },
            appium_lib: { server_url: "http://127.0.0.1:4723/wd/hub", :port => "4723"}
            }
        end
      ENV['HTTP_PROXY'] = ENV['http_proxy'] = nil
      $browser = Appium::Driver.new(opts).start_driver
    when 'FIREFOX'
      p "*********************************************************"
      p "Test Started:: Invoking Firefox browser..!"
      @browser = Selenium::WebDriver.for :firefox
      p "Browser Version:: #{@browser.capabilities.version}"
      p "*********************************************************"
    when 'SAFARI'
      p "*********************************************************"
      p "Test Started:: Invoking Safari browser..!"
      @browser = Selenium::WebDriver.for :safari
      p "Browser Version:: #{@browser.capabilities.version}"
      p "*********************************************************"
  end
  @browser.manage.window.maximize
  @browser.manage.delete_all_cookies
end

def self.load_mobile_mew(os)
  @device = YAML.load_file('config/devices.yml')["#{ENV['DEVICE']}"]
  p "Test Started:: Invoking #{@device['platformName']}  #{ENV['DEVICE']}  Chrome $browser..!"
  $extent_test.assign_category("UIAutomation - #{ENV['DEVICE']} Emulator/Simulator Mobile Website")
  if @device['platformName'] == "iOS"
    opts =
      {
        caps:
          {
            :browserName => "#{@device['browser']}",
            :platformName => "#{@device['platformName']}",
            :platformVersion => "#{@device['platformVersion']}",
            :newCommandTimeout => "#{@device['newCommandTimeout']}",
            :deviceName => "#{@device['deviceName']}",
            :udid => "#{@device['udid']}",
            :bootstrapPath => "/usr/local/lib/node_modules/appium/node_modules/appium-xcuitest-driver/WebDriverAgent",
            :agentPath => "/usr/local/lib/node_modules/appium/node_modules/appium-xcuitest-driver/WebDriverAgent/WebDriverAgent.xcodeproj"
          },
        appium_lib: { server_url: "http://127.0.0.1:4723/wd/hub", :port => "4723"}
      }
    else
      opts =
        {
        caps:
          {
            :browserName => "#{@device['browser']}",
            :platformName => "#{@device['platformName']}",
            :platformVersion => "#{@device['platformVersion']}",
            :newCommandTimeout => "#{@device['newCommandTimeout']}",
            :deviceName => "#{@device['deviceName']}"
          },
        appium_lib: { server_url: "http://127.0.0.1:4723/wd/hub", :port => "4723"}
        }
    end
  ENV['HTTP_PROXY'] = ENV['http_proxy'] = nil
  $browser = Appium::Driver.new(opts).start_driver
end

def self.load_mobile_app(os)
  p "*********************************************************"
  @device = YAML.load_file('config/devices.yml')["#{ENV['DEVICE']}"]
  p "Test Started:: Invoking #{@device['platformName']}  #{ENV['DEVICE']} APP..!"
  $extent_test.assign_category('UIAutomation - Android Emulator app automation')
  opts =
  {
      caps:
      {
          :app => "#{$obj_yml['mobileapps']["#{@device['platformName']}"]}",
          :platformName => "#{@device['platformName']}",
          :platformVersion => "#{@device['platformVersion']}",
          :newCommandTimeout => "#{@device['newCommandTimeout']}",
          :deviceName => "#{@device['deviceName']}"
      },
      appium_lib: { server_url: "http://127.0.0.1:4723/wd/hub", :port => "4723"}
  }
  ENV['HTTP_PROXY'] = ENV['http_proxy'] = nil
  $browser = Appium::Driver.new(opts).start_driver
end


After do |scenario|
    if scenario.failed?
      begin
        @log.info("Exception: #{scenario.exception}")
        fullpath = "#{Dir.getwd}/testreport/reports/screenshots/screenshot#{Time.now.strftime('%Y_%m_%d-%HH_%MM_%SS')}.png"
        screenshotpath = fullpath.gsub("#{Dir.getwd}/testreport/reports",".")
        embed(screenshotpath, 'image/png', "Failure Screenshot")
      rescue Exception => e
        @log.info("Fatal Error: #{e.exception}")
      end
    end
    @browser.quit
end