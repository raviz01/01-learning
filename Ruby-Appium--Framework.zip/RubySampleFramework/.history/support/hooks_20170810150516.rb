$LOAD_PATH << './pageobjects'
$LOAD_PATH << './library'
$LOAD_PATH << './library/utils'
$LOAD_PATH << './support'

require 'selenium-webdriver'
require 'rspec/expectations'

Before do |scenario|
  @log = Log.instance.start_new
  @log.instance_variable_set(:@cucumber_world, self)
  @browser = ''
  case ENV['PLATFORM'].upcase
    when 'CHROME'
      p "*********************************************************"
      p "Test Started:: Invoking chrome browser..!"
      @browser = Selenium::WebDriver.for :chrome
      p "Browser Version:: #{@browser.capabilities.version}"
      p "*********************************************************"
    when 'FIREFOX'
      p "*********************************************************"
      p "Test Started:: Invoking Firefox browser..!"
      @browser = Selenium::WebDriver.for :firefox
      p "Browser Version:: #{@browser.capabilities.version}"
      p "*********************************************************"
    when 'SAFARI'
      p "*********************************************************"
      p "Test Started:: Invoking Safari browser..!"
      @browser = Selenium::WebDriver.for :safari
      p "Browser Version:: #{@browser.capabilities.version}"
      p "*********************************************************"
  end
  @browser.manage.window.maximize
  @browser.manage.delete_all_cookies
end

After do |scenario|
    if scenario.failed?
      begin
        @log.info("Exception: #{scenario.exception}")
        fullpath = "#{Dir.getwd}/testreport/reports/screenshots/screenshot#{Time.now.strftime('%Y_%m_%d-%HH_%MM_%SS')}.png"
        screenshotpath = fullpath.gsub("#{Dir.getwd}/testreport/reports",".")
        embed(screenshotpath, 'image/png', "Failure Screenshot")
      rescue Exception => e
        @log.info("Fatal Error: #{e.exception}")
      end
    end
    @browser.quit
end