require 'page-object'
require 'selenium-webdriver'
require 'yaml'
require 'httparty'
require 'page-object/page_factory'
require 'require_all'
require 'rubygems'
require 'rspec/expectations'
require 'cucumber'
require 'appium_lib'

require_all 'library'
require_all 'pageobjects'

World(PageObject::PageFactory)

PageObject.default_element_wait = 10
PageObject.default_page_wait = 60
