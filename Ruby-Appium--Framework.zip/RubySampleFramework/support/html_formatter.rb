require 'cucumber/formatter/html'

module Formatter
  class HtmlFormatter < Cucumber::Formatter::Html

    def embed(str_src, str_mime_type, str_label)
      case str_mime_type
        when /^image\/(png|gif|jpg|jpeg)/
          embed_image(str_src, str_label)
        when /^text\/plain/
          embed_file(str_src, str_label)
      end
    end

    def embed_link(str_src, str_label)
      @builder.span(:class => 'embed') do |pre|
        pre << %{<a href="#{str_src}" target="_blank">"#{str_label}"</a> }
      end
    end

    def embed_file(str_src, str_label = "Click to view embedded file")
      id = "object_#{Time.now.strftime("%y%m%d%H%M%S")}"
      @builder.span(:class => 'embed') do |pre|
        pre << %{<a href="" onclick="o=document.getElementById('#{id}'); o.style.display = (o.style.display == 'none' ? 'block' : 'none');return false">#{str_label}</a><br>&nbsp;
	        <object id="#{id}" data="#{str_src}" type="text/plain" width="100%" style="height: 10em;display: none"></object>}
      end
    end
  end
end
